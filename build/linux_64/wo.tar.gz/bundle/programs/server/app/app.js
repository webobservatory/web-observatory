var require = meteorInstall({"lib":{"collections":{"declarations":{"_utils.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/_utils.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 26/12/2015.                                                                                      //
 */ //Declare a newe EJSON type @typeName with only one instance @singular                                             //
toEJSONSingularType = function (singleton, typeName) {                                                                 // 6
    check(typeof singleton === "undefined" ? "undefined" : (0, _typeof3.default)(singleton), 'object'); //check(singular, Ojbect) may give expected plain object error
                                                                                                                       //
    check(singleton.typeName, undefined);                                                                              // 9
    check(singleton.toJSONValue, undefined);                                                                           // 10
    check(typeName, String);                                                                                           // 11
                                                                                                                       //
    singleton.typeName = function () {                                                                                 // 13
        return typeName;                                                                                               // 14
    }; //the return value doesn't matter since the custom type always return one value                                 // 15
                                                                                                                       //
                                                                                                                       //
    singleton.toJSONValue = function () {                                                                              // 18
        return typeName;                                                                                               // 19
    };                                                                                                                 // 20
                                                                                                                       //
    EJSON.addType(typeName, function () {                                                                              // 22
        return singleton;                                                                                              // 23
    });                                                                                                                // 24
};                                                                                                                     // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/apps.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 19/12/2015.                                                                                      //
 */Apps = new orion.collection('apps', {                                                                               //
    singularName: 'app',                                                                                               // 5
    // The name of one of these items                                                                                  // 5
    pluralName: 'apps',                                                                                                // 6
    // The name of more than one of these items                                                                        // 6
    link: {                                                                                                            // 7
        // *                                                                                                           // 8
        //  * The text that you want to show in the sidebar.                                                           // 9
        //  * The default value is the name of the collection, so                                                      // 10
        //  * in this case it is not necessary.                                                                        // 11
        title: 'Apps'                                                                                                  // 13
    },                                                                                                                 // 7
    /**                                                                                                                // 15
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 19
        // in the CMS panel                                                                                            // 20
        columns: [{                                                                                                    // 21
            data: "name",                                                                                              // 23
            title: "Name"                                                                                              // 24
        }, {                                                                                                           // 22
            data: "publisher",                                                                                         // 27
            render: function (val, type, doc) {                                                                        // 28
                var publisherId = val;                                                                                 // 29
                var publisherName = Meteor.users.findOne(publisherId).username;                                        // 30
                return publisherName;                                                                                  // 31
            },                                                                                                         // 32
            title: "Publisher"                                                                                         // 33
        }, {                                                                                                           // 26
            data: "github",                                                                                            // 36
            title: "Github"                                                                                            // 37
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 35
    }                                                                                                                  // 18
}); // Meteor.call requires parameters to be of EJSON, passing a collection as it is                                   // 4
// causes a Maximum call stack size exceeded error                                                                     // 45
                                                                                                                       //
toEJSONSingularType(Apps, Apps.pluralName); //Apps.allow({                                                             // 46
//    update: function (userId, entry, fieldNames) {                                                                   // 49
//        return ownsDocument(userId, entry) && _.difference(fieldNames, appWhitelist).length === 0;                   // 50
//    },                                                                                                               // 51
//    remove: function (userId, entry) {                                                                               // 52
//        return ownsDocument(userId, entry);                                                                          // 53
//    },                                                                                                               // 54
//});                                                                                                                  // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/clients.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/01/2016.                                                                                      //
 */Clients = new orion.collection('client', {                                                                          //
    singularName: 'client',                                                                                            // 5
    // The name of one of these items                                                                                  // 5
    pluralName: 'clients',                                                                                             // 6
    // The name of more than one of these items                                                                        // 6
    link: {                                                                                                            // 7
        // *                                                                                                           // 8
        //  * The text that you want to show in the sidebar.                                                           // 9
        //  * The default value is the name of the collection, so                                                      // 10
        //  * in this case it is not necessary.                                                                        // 11
        title: 'Clients'                                                                                               // 12
    },                                                                                                                 // 7
    /**                                                                                                                // 14
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 18
        // in the CMS panel                                                                                            // 19
        columns: [{                                                                                                    // 20
            data: "name",                                                                                              // 22
            title: "Name"                                                                                              // 23
        }, {                                                                                                           // 21
            data: "key",                                                                                               // 26
            title: "Client Key/ID"                                                                                     // 27
        }, {                                                                                                           // 25
            data: "secret",                                                                                            // 30
            title: "Client secret"                                                                                     // 31
        }, {                                                                                                           // 29
            data: "redirect_uris",                                                                                     // 34
            title: "Redirect/Callback URLs"                                                                            // 35
        }, {                                                                                                           // 33
            data: "user",                                                                                              // 38
            render: function (val, type, doc) {                                                                        // 39
                var publisherId = val;                                                                                 // 40
                var publisherName = Meteor.users.findOne(publisherId).username;                                        // 41
                return publisherName;                                                                                  // 42
            },                                                                                                         // 43
            title: "User"                                                                                              // 44
        }, orion.attributeColumn('createdAt', 'createdAt', 'Created')]                                                 // 37
    }                                                                                                                  // 17
}); // Meteor.call requires parameters to be of EJSON, passing a collection as it is                                   // 4
// causes a Maximum call stack size exceeded error                                                                     // 52
// toEJSONSingularType(Clients, Clients.singularName);                                                                 // 53
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/comments.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Comments = new orion.collection('comments', {                                                                          // 1
    singularName: 'comment',                                                                                           // 2
    // The name of one of these items                                                                                  // 2
    pluralName: 'comments',                                                                                            // 3
    // The name of more than one of these items                                                                        // 3
    link: {                                                                                                            // 4
        // *                                                                                                           // 5
        //  * The text that you want to show in the sidebar.                                                           // 6
        //  * The default value is the name of the collection, so                                                      // 7
        //  * in this case it is not necessary.                                                                        // 8
        title: 'Comments'                                                                                              // 10
    },                                                                                                                 // 4
    /**                                                                                                                // 12
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 16
        // in the CMS panel                                                                                            // 17
        columns: [{                                                                                                    // 18
            data: "publisher",                                                                                         // 20
            title: "Author",                                                                                           // 21
            render: function (val, type, doc) {                                                                        // 22
                var username = Meteor.users.findOne(val).username;                                                     // 23
                return username;                                                                                       // 24
            }                                                                                                          // 25
        }, {                                                                                                           // 19
            data: "entryId",                                                                                           // 27
            title: "Comment of",                                                                                       // 28
            render: function (val, type, doc) {                                                                        // 29
                var entryId = val; //A comment can be of either a dataset or an app                                    // 30
                                                                                                                       //
                var entryTitle = Datasets.findOne(entryId).name || Apps.findOne(entryId).name;                         // 33
                return entryTitle;                                                                                     // 34
            }                                                                                                          // 35
        }, {                                                                                                           // 26
            data: "body",                                                                                              // 37
            title: "Comment",                                                                                          // 38
            tmpl: Meteor.isClient && Template.commentsIndexBlurbCell                                                   // 39
        }, orion.attributeColumn('createdAt', 'submitted', 'Submitted')]                                               // 36
    }                                                                                                                  // 15
}); //TODO add allow & deny rules                                                                                      // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/datasets.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 17/12/2015.                                                                                      //
 */Datasets = new orion.collection('datasets', {                                                                       //
    singularName: 'dataset',                                                                                           // 6
    // The name of one of these items                                                                                  // 6
    pluralName: 'datasets',                                                                                            // 7
    // The name of more than one of these items                                                                        // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
        title: 'Datasets'                                                                                              // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 17
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 21
        // in the CMS panel                                                                                            // 22
        columns: [{                                                                                                    // 23
            data: "_id",                                                                                               // 25
            title: "ID"                                                                                                // 26
        }, {                                                                                                           // 24
            data: "name",                                                                                              // 29
            title: "Name"                                                                                              // 30
        }, {                                                                                                           // 28
            data: "publisher",                                                                                         // 33
            render: function (val, type, doc) {                                                                        // 34
                var publisherId = val;                                                                                 // 35
                var publisherName = Meteor.users.findOne(publisherId).username;                                        // 36
                return publisherName;                                                                                  // 37
            },                                                                                                         // 38
            title: "Publisher"                                                                                         // 39
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 32
    }                                                                                                                  // 20
}); // Meteor.call requires parameters to be of EJSON, passing a collection as it is                                   // 5
// causes a Maximum call stack size exceeded error                                                                     // 47
                                                                                                                       //
toEJSONSingularType(Datasets, Datasets.pluralName); //Datasets.allow({                                                 // 48
//    update: function (userId, entry, fieldNames) {                                                                   // 51
//        return ownsDocument(userId, entry);// && _.difference(fieldNames, datasetWhitelist).length === 0;            // 52
//    },                                                                                                               // 53
//    remove: function (userId, entry) {                                                                               // 54
//        return ownsDocument(userId, entry);                                                                          // 55
//    },                                                                                                               // 56
//});                                                                                                                  // 57
//Datasets.deny({                                                                                                      // 59
//    update: function (userId, entry, fieldNames) {                                                                   // 60
//        return _.difference(fieldNames, datasetWhitelist).length !== 0;                                              // 61
//    }                                                                                                                // 62
//});                                                                                                                  // 63
//Datasets.deny({                                                                                                      // 65
//    update: function (userId, entry, fieldNames, modifier) {                                                         // 66
//        let errors = validateDataset(modifier.$set);                                                                 // 67
//        return errors.name || errors.distribution;                                                                   // 68
//    }                                                                                                                // 69
//});                                                                                                                  // 70
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/group.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 24/12/2015.                                                                                      //
 */Groups = new orion.collection('groups', {                                                                           //
    singularName: 'group',                                                                                             // 6
    // The name of one of these items                                                                                  // 6
    pluralName: 'groups',                                                                                              // 7
    // The name of more than one of these items                                                                        // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
        title: 'Projects/Organisations'                                                                                // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 16
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 20
        // in the CMS panel                                                                                            // 21
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           // 23
            data: "publisher",                                                                                         // 28
            title: "Founder",                                                                                          // 29
            render: function (val, type, doc) {                                                                        // 30
                var publisherName = Meteor.users.findOne(val).username;                                                // 31
                return publisherName;                                                                                  // 32
            }                                                                                                          // 33
        }, {                                                                                                           // 27
            data: "members",                                                                                           // 36
            title: "Members",                                                                                          // 37
            render: function (val, type, doc) {                                                                        // 38
                if (!val) {                                                                                            // 39
                    return 'No member';                                                                                // 40
                }                                                                                                      // 41
                                                                                                                       //
                var memberIds = val,                                                                                   // 43
                    query = {                                                                                          // 43
                    $or: []                                                                                            // 44
                };                                                                                                     // 44
                memberIds.reduce(function (previous, id) {                                                             // 45
                    return query.$or.push({                                                                            // 46
                        _id: id                                                                                        // 46
                    });                                                                                                // 46
                }, query);                                                                                             // 47
                return Meteor.users.find(query).map(function (user) {                                                  // 49
                    return user.username;                                                                              // 50
                });                                                                                                    // 51
            }                                                                                                          // 52
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             // 35
    }                                                                                                                  // 19
}); // When there is a change to group name, update associated account name                                            // 5
// let query = Groups.find();                                                                                          // 60
// let handle = query.observeChanges({                                                                                 // 61
//     changed: function (groupId, changedField) {                                                                     // 62
//         if (changedField.name) {                                                                                    // 63
//             let groupAccountId = Groups.findOne(groupId).publisher;                                                 // 64
//             Meteor.users.update({_id: groupAccountId}, {$set: {name: changedField.name}});                          // 65
//         }                                                                                                           // 66
//         ;                                                                                                           // 67
//     }                                                                                                               // 68
// });                                                                                                                 // 69
//                                                                                                                     // 70
// Meteor.users.after.insert(function (userId, user) {                                                                 // 71
//     let profile = user.profile;                                                                                     // 72
//     if (profile && profile.isgroup) {                                                                               // 73
//         let group = Groups.insert({                                                                                 // 74
//             publisher: user._id,                                                                                    // 75
//             name: profile.name,                                                                                     // 76
//             description: profile.description,                                                                       // 77
//             url: profile.url                                                                                        // 78
//         });                                                                                                         // 79
//         Meteor.users.update(user._id, {$set: {isGroup: group}, $unset: {'profile.isgroup': ''}});                   // 80
//         Roles.removeUserFromRoles(user._id, ["individual"]);                                                        // 81
//         Roles.addUserToRoles(user._id, ["group"]);                                                                  // 82
//     }                                                                                                               // 83
// });                                                                                                                 // 84
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/licenses.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 22/01/2016.                                                                                      //
 */Licenses = new orion.collection('licenses', {                                                                       //
    singularName: 'license',                                                                                           // 6
    // The name of one of these items                                                                                  // 6
    pluralName: 'licenses',                                                                                            // 7
    // The name of more than one of these items                                                                        // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
        title: 'Licenses'                                                                                              // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 16
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 20
        // in the CMS panel                                                                                            // 21
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           // 23
            data: "url",                                                                                               // 28
            title: "URL"                                                                                               // 29
        }, {                                                                                                           // 27
            data: "text",                                                                                              // 32
            title: "Content"                                                                                           // 33
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             // 31
    }                                                                                                                  // 19
});                                                                                                                    // 5
defaultLicenses = new Set(["afl-3.0", "agpl-3.0", "apache-2.0", "artistic-2.0", "bsd-2-clause", "bsd-3-clause-clear", "bsd-3-clause", "cc0-1.0", "epl-1.0", "gpl-2.0", "gpl-3.0", "isc", "lgpl-2.1", "lgpl-3.0", "mit", "mpl-2.0", "ms-pl", "ms-rl", "no-license", "ofl-1.1", "osl-3.0", "unlicense", "wtfpl"]);
Licenses.allow({                                                                                                       // 47
    insert: function (userId, entry, fieldNames) {                                                                     // 48
        return true;                                                                                                   // 49
    },                                                                                                                 // 50
    update: function (userId, entry, fieldNames) {                                                                     // 51
        return ownsDocument(userId, entry);                                                                            // 52
    },                                                                                                                 // 53
    remove: function (userId, entry) {                                                                                 // 54
        return ownsDocument(userId, entry);                                                                            // 55
    }                                                                                                                  // 56
}); // Meteor.call requires parameters to be of EJSON, passing a collection as it is                                   // 47
// causes a Maximum call stack size exceeded error                                                                     // 60
                                                                                                                       //
toEJSONSingularType(Licenses, Licenses.singularName);                                                                  // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/notifications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Notifications = new Mongo.Collection('notifications');                                                                 // 1
Notifications.allow({                                                                                                  // 3
    update: function (userId, doc, fieldNames) {                                                                       // 4
        return doc.userId === userId && fieldNames.length === 1 && fieldNames[0] === 'read';                           // 5
    }                                                                                                                  // 7
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/remote.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 11/05/2016.                                                                                      //
 */RemoteDatasets = new orion.collection('remotedatasets', {                                                           //
    singularName: 'remotedataset',                                                                                     // 6
    // The name of one of these items                                                                                  // 6
    pluralName: 'remotedatasets',                                                                                      // 7
    // The name of more than one of these items                                                                        // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
        title: 'Remote Datasets'                                                                                       // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 17
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 21
        // in the CMS panel                                                                                            // 22
        columns: [{                                                                                                    // 23
            data: "name",                                                                                              // 25
            title: "Name"                                                                                              // 26
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 24
    }                                                                                                                  // 20
});                                                                                                                    // 5
RemoteApps = new orion.collection('remoteapps', {                                                                      // 33
    singularName: 'remoteapp',                                                                                         // 34
    // The name of one of these items                                                                                  // 34
    pluralName: 'remoteapps',                                                                                          // 35
    // The name of more than one of these items                                                                        // 35
    link: {                                                                                                            // 36
        // *                                                                                                           // 37
        //  * The text that you want to show in the sidebar.                                                           // 38
        //  * The default value is the name of the collection, so                                                      // 39
        //  * in this case it is not necessary.                                                                        // 40
        title: 'Remote Apps'                                                                                           // 42
    },                                                                                                                 // 36
    /**                                                                                                                // 44
     * Tabular settings for this collection                                                                            //
     */tabular: {                                                                                                      //
        // here we set which data columns we want to appear on the data table                                          // 48
        // in the CMS panel                                                                                            // 49
        columns: [{                                                                                                    // 50
            data: "name",                                                                                              // 52
            title: "Name"                                                                                              // 53
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 51
    }                                                                                                                  // 47
});                                                                                                                    // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"schemas":{"_creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/_creative_work.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 17/12/2015.                                                                                      //
 */ // SimpleSchema.debug = true;                                                                                      //
// SimpleSchema.extendOptions({                                                                                        // 5
//     //noneditable: Match.Optional(Boolean)                                                                          // 6
// });                                                                                                                 // 7
Thing = {                                                                                                              // 9
    name: {                                                                                                            // 10
        type: String,                                                                                                  // 11
        unique: true,                                                                                                  // 12
        label: 'Name'                                                                                                  // 13
    },                                                                                                                 // 10
    description: orion.attribute('summernote', {                                                                       // 16
        label: 'Description',                                                                                          // 17
        optional: true                                                                                                 // 18
    })                                                                                                                 // 16
};                                                                                                                     // 9
CreativeWork = {                                                                                                       // 22
    comments: orion.attribute('hasMany', {                                                                             // 23
        type: [String],                                                                                                // 24
        label: 'Comments',                                                                                             // 25
        // optional is true because you can have a post without comments                                               // 26
        optional: true //noneditable: true                                                                             // 27
                                                                                                                       //
    }, {                                                                                                               // 23
        collection: Comments,                                                                                          // 30
        titleField: 'body',                                                                                            // 31
        publicationName: 'rel_comments'                                                                                // 32
    }),                                                                                                                // 29
    commentsCount: {                                                                                                   // 35
        type: Number,                                                                                                  // 36
        autoValue: function () {                                                                                       // 37
            var comments = this.field("comments");                                                                     // 38
            return comments ? comments.length : 0;                                                                     // 39
        },                                                                                                             // 40
        optional: true,                                                                                                // 41
        autoform: {                                                                                                    // 42
            omit: true                                                                                                 // 43
        } //noneditable: true                                                                                          // 42
                                                                                                                       //
    },                                                                                                                 // 35
    creator: {                                                                                                         // 48
        type: String,                                                                                                  // 49
        label: 'Creator',                                                                                              // 50
        optional: true                                                                                                 // 51
    },                                                                                                                 // 48
    publisher: orion.attribute('createdBy'),                                                                           // 54
    publisherName: {                                                                                                   // 56
        type: String,                                                                                                  // 57
        optional: true,                                                                                                // 58
        autoform: {                                                                                                    // 59
            type: 'hidden' // omit: true                                                                               // 60
                                                                                                                       //
        },                                                                                                             // 59
        autoValue: function () {                                                                                       // 63
            var publisher = this.field('publisher');                                                                   // 64
                                                                                                                       //
            if (publisher.isSet) {                                                                                     // 65
                var pId = publisher.value;                                                                             // 66
                var user = Meteor.users.findOne(pId);                                                                  // 67
                                                                                                                       //
                if (user) {                                                                                            // 68
                    return user.username;                                                                              // 69
                } else {                                                                                               // 70
                    this.unset();                                                                                      // 71
                }                                                                                                      // 72
            } else {                                                                                                   // 73
                this.unset();                                                                                          // 74
            }                                                                                                          // 75
        }                                                                                                              // 76
    },                                                                                                                 // 56
    // Force value to be current date (on server) upon insert                                                          // 78
    // and prevent updates thereafter.                                                                                 // 79
    datePublished: orion.attribute('createdAt'),                                                                       // 80
    // Force value to be current date (on server) upon update                                                          // 82
    // and don't allow it to be set upon insert.                                                                       // 83
    dateModified: orion.attribute('updatedAt'),                                                                        // 84
    isBasedOnUrl: orion.attribute('hasMany', {                                                                         // 86
        type: [String],                                                                                                // 87
        label: 'Related datasets',                                                                                     // 88
        optional: true                                                                                                 // 89
    }, {                                                                                                               // 86
        collection: Datasets,                                                                                          // 91
        titleField: 'name',                                                                                            // 92
        publicationName: 'isbasedonurl'                                                                                // 93
    }),                                                                                                                // 90
    keywords: {                                                                                                        // 96
        type: [String],                                                                                                // 97
        label: 'Keywords',                                                                                             // 98
        optional: true                                                                                                 // 99
    },                                                                                                                 // 96
    license: {                                                                                                         // 102
        type: String,                                                                                                  // 103
        label: 'License',                                                                                              // 104
        autoform: {                                                                                                    // 105
            options: function () {                                                                                     // 106
                var addedLices = Licenses.find().fetch();                                                              // 107
                var options = [];                                                                                      // 109
                defaultLicenses.forEach(function (name) {                                                              // 110
                    options.push({                                                                                     // 111
                        label: name.toUpperCase(),                                                                     // 111
                        value: name                                                                                    // 111
                    });                                                                                                // 111
                });                                                                                                    // 112
                addedLices.forEach(function (lice) {                                                                   // 114
                    if (lice.name) {                                                                                   // 115
                        var name = lice.name;                                                                          // 116
                        options.push({                                                                                 // 117
                            label: name.toUpperCase(),                                                                 // 117
                            value: name                                                                                // 117
                        });                                                                                            // 117
                    }                                                                                                  // 118
                });                                                                                                    // 119
                return options;                                                                                        // 121
            }                                                                                                          // 122
        }                                                                                                              // 105
    }                                                                                                                  // 102
};                                                                                                                     // 22
Mis = {                                                                                                                // 127
    upvoters: {                                                                                                        // 128
        type: [String],                                                                                                // 129
        optional: true,                                                                                                // 130
        autoform: {                                                                                                    // 131
            omit: true                                                                                                 // 132
        }                                                                                                              // 131
    },                                                                                                                 // 128
    votes: {                                                                                                           // 136
        type: Number,                                                                                                  // 137
        autoform: {                                                                                                    // 138
            omit: true                                                                                                 // 139
        },                                                                                                             // 138
        optional: true,                                                                                                // 141
        autoValue: function () {                                                                                       // 142
            var voters = this.field('upvoters');                                                                       // 143
            return voters ? voters.length : 0;                                                                         // 144
        }                                                                                                              // 145
    },                                                                                                                 // 136
    downvoters: {                                                                                                      // 148
        type: [String],                                                                                                // 149
        optional: true,                                                                                                // 150
        autoform: {                                                                                                    // 151
            omit: true                                                                                                 // 152
        }                                                                                                              // 151
    },                                                                                                                 // 148
    downvotes: {                                                                                                       // 156
        type: Number,                                                                                                  // 157
        autoform: {                                                                                                    // 158
            omit: true                                                                                                 // 159
        },                                                                                                             // 158
        optional: true,                                                                                                // 161
        autoValue: function () {                                                                                       // 162
            var voters = this.field('downvoters');                                                                     // 163
            return voters ? voters.length : 0;                                                                         // 164
        }                                                                                                              // 165
    },                                                                                                                 // 156
    // whether this entry is online                                                                                    // 168
    // in case of a dataset, it's offline if any of its distribution is offline                                        // 169
    online: {                                                                                                          // 170
        type: Boolean,                                                                                                 // 171
        autoform: {                                                                                                    // 172
            readonly: true,                                                                                            // 173
            type: 'hidden'                                                                                             // 174
        },                                                                                                             // 172
        optional: true,                                                                                                // 176
        defaultValue: true                                                                                             // 177
    },                                                                                                                 // 170
    //metadata permission i.e. visibility                                                                              // 180
    aclMeta: {                                                                                                         // 181
        type: Boolean,                                                                                                 // 182
        label: "Visible to everyone",                                                                                  // 183
        defaultValue: true                                                                                             // 184
    },                                                                                                                 // 181
    //content permission i.e. queryability                                                                             // 187
    aclContent: {                                                                                                      // 188
        type: Boolean,                                                                                                 // 189
        label: "Accessible to everyone",                                                                               // 190
        defaultValue: true                                                                                             // 191
    },                                                                                                                 // 188
    //who can see this entry disregards acl settings                                                                   // 194
    metaWhiteList: orion.attribute('hasMany', {                                                                        // 195
        type: [String],                                                                                                // 196
        label: 'Permitted to see',                                                                                     // 197
        autoform: {                                                                                                    // 198
            omit: true                                                                                                 // 199
        },                                                                                                             // 198
        optional: true                                                                                                 // 201
    }, {                                                                                                               // 195
        collection: Meteor.users,                                                                                      // 203
        titleField: 'username',                                                                                        // 204
        publicationName: 'metawhitelist'                                                                               // 205
    }),                                                                                                                // 202
    //who can access this entry disregards acl settings                                                                // 208
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 209
        type: [String],                                                                                                // 210
        label: 'Share to',                                                                                             // 211
        optional: true                                                                                                 // 212
    }, {                                                                                                               // 209
        collection: Meteor.users,                                                                                      // 214
        titleField: 'username',                                                                                        // 215
        publicationName: 'contentwhitelist'                                                                            // 216
    })                                                                                                                 // 213
};                                                                                                                     // 127
                                                                                                                       //
_.extend(CreativeWork, Thing);                                                                                         // 220
                                                                                                                       //
_.extend(CreativeWork, Mis);                                                                                           // 221
                                                                                                                       //
omitFields = "publisher, comments, commentsCount, datePublished, dateModified, upvoters, downvoters, votes, downvotes, online, distribution.$._id".split(/\s*,\s*/);
                                                                                                                       //
setAtCreation = function (field, val) {                                                                                // 225
    if (val instanceof Function) {                                                                                     // 226
        val = val();                                                                                                   // 227
    }                                                                                                                  // 228
                                                                                                                       //
    if (field.isInsert) {                                                                                              // 229
        return val;                                                                                                    // 230
    } else if (field.isUpsert) {                                                                                       // 231
        return {                                                                                                       // 232
            $setOnInsert: val                                                                                          // 232
        };                                                                                                             // 232
    } else {                                                                                                           // 233
        field.unset();                                                                                                 // 234
    }                                                                                                                  // 235
};                                                                                                                     // 236
                                                                                                                       //
setAtUpdate = function (field, val) {                                                                                  // 238
    if (val instanceof Function) {                                                                                     // 239
        val = val();                                                                                                   // 240
    }                                                                                                                  // 241
                                                                                                                       //
    if (field.isUpdate || field.isInsert) {                                                                            // 242
        return val;                                                                                                    // 243
    } else if (field.isUpsert) {                                                                                       // 244
        return {                                                                                                       // 245
            $setOnInsert: val                                                                                          // 245
        };                                                                                                             // 245
    } else {                                                                                                           // 246
        //shouldn't reach here                                                                                         // 247
        field.unset();                                                                                                 // 248
    }                                                                                                                  // 249
};                                                                                                                     // 250
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/apps.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 19/12/2015.                                                                                      //
 */AppSchema = {                                                                                                       //
    url: {                                                                                                             // 6
        type: String,                                                                                                  // 7
        label: "URL",                                                                                                  // 8
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 9
        autoform: {                                                                                                    // 10
            type: 'url',                                                                                               // 11
            placeholder: "Provide the URL of your web app or upload the app source below"                              // 12
        }                                                                                                              // 10
    },                                                                                                                 // 6
    file: orion.attribute('file', {                                                                                    // 15
        label: 'Upload app source as a zip file. Only support apps written in client-side JS and HTML',                // 16
        optional: true                                                                                                 // 17
    }),                                                                                                                // 15
    github: {                                                                                                          // 19
        type: String,                                                                                                  // 20
        optional: true,                                                                                                // 21
        label: "Github",                                                                                               // 22
        regEx: SimpleSchema.RegEx.Url                                                                                  // 23
    }                                                                                                                  // 19
}; ////_.extend(App, CreativeWork);                                                                                    // 5
//                                                                                                                     // 28
////important, generate whitelist before constructing simpleschema                                                     // 29
//appWhitelist = _.filter(_.keys(App), function (property) {                                                           // 30
//    return !App[property].noneditable;                                                                               // 31
//});                                                                                                                  // 32
//                                                                                                                     // 33
//_.extend(appWhitelist, Whitelist);                                                                                   // 34
//                                                                                                                     // 35
//appBlacklist = _.filter(_.keys(App), function (property) {                                                           // 36
//    return App[property].noneditable;                                                                                // 37
//});                                                                                                                  // 38
//                                                                                                                     // 39
//_.extend(appBlacklist, BlackList);                                                                                   // 40
                                                                                                                       //
Apps.attachSchema(new SimpleSchema([Thing, AppSchema, CreativeWork]));                                                 // 42
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/clients.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/01/2016.                                                                                      //
 */ // import crypto from 'crypto'                                                                                     //
function keyGen(str) {                                                                                                 // 6
    return CryptoJS.MD5(str + Math.random()).toString(CryptoJS.enc.Hex);                                               // 7
}                                                                                                                      // 8
                                                                                                                       //
var ClientSchema = new SimpleSchema({                                                                                  // 10
    name: {                                                                                                            // 12
        type: String,                                                                                                  // 13
        label: 'Name'                                                                                                  // 14
    },                                                                                                                 // 12
    user: orion.attribute('createdBy'),                                                                                // 17
    publisher: orion.attribute('createdBy'),                                                                           // 19
    key: {                                                                                                             // 21
        type: String,                                                                                                  // 22
        // denyUpdate: true,                                                                                           // 23
        autoValue: function () {                                                                                       // 24
            if (this.isInsert) {                                                                                       // 25
                var user = Meteor.userId();                                                                            // 26
                return keyGen(user + '-');                                                                             // 27
            } else {                                                                                                   // 28
                this.unset(); // Prevent user from supplying their own value                                           // 29
            }                                                                                                          // 30
        },                                                                                                             // 31
        autoform: {                                                                                                    // 32
            // omit: true,                                                                                             // 33
            readonly: true                                                                                             // 34
        }                                                                                                              // 32
    },                                                                                                                 // 21
    secret: {                                                                                                          // 38
        type: String,                                                                                                  // 39
        // denyUpdate: true,                                                                                           // 40
        autoValue: function () {                                                                                       // 41
            var key = this.field("key");                                                                               // 42
                                                                                                                       //
            if (key.isSet) {                                                                                           // 43
                var user = Meteor.userId();                                                                            // 44
                return keyGen(key.value + user);                                                                       // 45
            } else {                                                                                                   // 46
                this.unset();                                                                                          // 47
            }                                                                                                          // 48
        },                                                                                                             // 49
        autoform: {                                                                                                    // 50
            // omit: true,                                                                                             // 51
            readonly: true                                                                                             // 52
        }                                                                                                              // 50
    },                                                                                                                 // 38
    createdAt: orion.attribute('createdAt'),                                                                           // 56
    updatedAt: orion.attribute('updatedAt'),                                                                           // 57
    redirect_uris: {                                                                                                   // 59
        type: [String],                                                                                                // 60
        label: 'Callback URLs',                                                                                        // 61
        optional: true                                                                                                 // 62
    }                                                                                                                  // 59
});                                                                                                                    // 10
Clients.attachSchema(ClientSchema);                                                                                    // 66
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/comments.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Now we will attach the schema for that collection.                                                                  //
 * Orion will automatically create the corresponding form.                                                             //
 */Comments.attachSchema(new SimpleSchema({                                                                            //
    entryId: {                                                                                                         // 6
        type: String,                                                                                                  // 7
        // the label is the text that will show up on the Update form's label                                          // 8
        label: 'Comment of',                                                                                           // 9
        // optional is false because you shouldn't have a comment without a post                                       // 10
        // associated with it                                                                                          // 11
        autoform: {                                                                                                    // 12
            type: "hidden",                                                                                            // 13
            readonly: true                                                                                             // 14
        }                                                                                                              // 12
    },                                                                                                                 // 6
    // here is where we define `a comment has one user (author)`                                                       // 17
    // Each document in Comment has a userId                                                                           // 18
    publisher: {                                                                                                       // 19
        type: String,                                                                                                  // 20
        label: 'Author',                                                                                               // 21
        autoform: {                                                                                                    // 22
            type: "hidden",                                                                                            // 23
            readonly: true                                                                                             // 24
        }                                                                                                              // 22
    },                                                                                                                 // 19
    category: {                                                                                                        // 27
        type: String,                                                                                                  // 28
        optional: true                                                                                                 // 29
    },                                                                                                                 // 27
    submitted: {                                                                                                       // 31
        type: Date,                                                                                                    // 32
        autoform: {                                                                                                    // 33
            readonly: true                                                                                             // 34
        }                                                                                                              // 33
    },                                                                                                                 // 31
    body: orion.attribute('summernote', {                                                                              // 37
        label: 'Comment body'                                                                                          // 38
    }),                                                                                                                // 37
    image: orion.attribute('image', {                                                                                  // 40
        optional: true,                                                                                                // 41
        label: 'Comment Image'                                                                                         // 42
    })                                                                                                                 // 40
}));                                                                                                                   // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/datasets.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * http://schema.org/Dataset                                                                                           //
 * Created by xgfd on 17/12/2015.                                                                                      //
 */var DistributionSchema = new SimpleSchema({                                                                         //
    _id: {                                                                                                             // 9
        type: String,                                                                                                  // 10
        denyUpdate: true,                                                                                              // 11
        optional: true,                                                                                                // 12
        regEx: SimpleSchema.RegEx.Id,                                                                                  // 13
        autoValue: function () {                                                                                       // 14
            // console.log('subId', this);                                                                             // 15
            if (this.isInsert) {                                                                                       // 16
                return Random.id();                                                                                    // 17
            } else if (this.isUpsert) {                                                                                // 18
                return {                                                                                               // 19
                    $setOnInsert: Random.id()                                                                          // 19
                };                                                                                                     // 19
            } else {                                                                                                   // 20
                this.unset(); // Prevent user from supplying their own value                                           // 21
            }                                                                                                          // 22
        } // defaultValue: Random.id(),                                                                                // 23
        // autoform: {                                                                                                 // 25
        //     type: 'hidden',                                                                                         // 26
        //     // readonly: true                                                                                       // 27
        //     // omit: true                                                                                           // 28
        // }                                                                                                           // 29
                                                                                                                       //
    },                                                                                                                 // 9
    fileFormat: {                                                                                                      // 32
        type: String,                                                                                                  // 33
        label: 'Dataset type',                                                                                         // 34
        allowedValues: ['MongoDB', 'MySQL', 'AMQP', 'SPARQL', 'HTML', 'File', 'GeoData'],                              // 35
        autoform: {                                                                                                    // 36
            type: 'select' //TODO custom validate                                                                      // 36
                                                                                                                       //
        }                                                                                                              // 36
    },                                                                                                                 // 32
    url: {                                                                                                             // 40
        type: String,                                                                                                  // 41
        label: 'URL',                                                                                                  // 42
        autoform: {                                                                                                    // 43
            type: 'url',                                                                                               // 44
            placeholder: "Select a format"                                                                             // 45
        }                                                                                                              // 43
    },                                                                                                                 // 40
    file: orion.attribute('file', {                                                                                    // 49
        label: 'Upload dataset file.',                                                                                 // 50
        optional: true                                                                                                 // 51
    }),                                                                                                                // 49
    //dataset dependent information                                                                                    // 54
    profile: {                                                                                                         // 55
        type: Object,                                                                                                  // 56
        optional: true,                                                                                                // 57
        label: 'Dataset credential',                                                                                   // 58
        defaultValue: {}                                                                                               // 59
    },                                                                                                                 // 55
    //dataset username                                                                                                 // 61
    'profile.username': {                                                                                              // 62
        type: String,                                                                                                  // 63
        optional: true,                                                                                                // 64
        label: 'Dataset user name'                                                                                     // 65
    },                                                                                                                 // 62
    //dataset password                                                                                                 // 67
    'profile.pass': {                                                                                                  // 68
        type: String,                                                                                                  // 69
        optional: true,                                                                                                // 70
        label: 'Dataset password'                                                                                      // 71
    },                                                                                                                 // 68
    //geo data source id in case of geo data                                                                           // 73
    'profile.geodata': {                                                                                               // 74
        type: String,                                                                                                  // 75
        autoform: {                                                                                                    // 76
            type: 'hidden' // omit: true,                                                                              // 77
                                                                                                                       //
        },                                                                                                             // 76
        optional: true,                                                                                                // 80
        label: 'GeoData Id'                                                                                            // 81
    },                                                                                                                 // 74
    instruction: {                                                                                                     // 84
        type: String,                                                                                                  // 85
        optional: true,                                                                                                // 86
        label: 'How to access this dataset',                                                                           // 87
        autoform: {                                                                                                    // 88
            type: 'textarea'                                                                                           // 88
        }                                                                                                              // 88
    },                                                                                                                 // 84
    //whether this distribution is online                                                                              // 91
    online: {                                                                                                          // 92
        type: Boolean,                                                                                                 // 93
        autoform: {                                                                                                    // 94
            omit: true                                                                                                 // 95
        },                                                                                                             // 94
        optional: true,                                                                                                // 97
        defaultValue: true                                                                                             // 98
    }                                                                                                                  // 92
});                                                                                                                    // 7
DatasetSchema = {                                                                                                      // 102
    url: {                                                                                                             // 104
        type: String,                                                                                                  // 105
        label: "URL",                                                                                                  // 106
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 107
        autoform: {                                                                                                    // 108
            type: 'hidden'                                                                                             // 109
        },                                                                                                             // 108
        optional: true,                                                                                                // 111
        autoValue: function () {                                                                                       // 112
            if (!this.isSet) {                                                                                         // 113
                var distribution = this.field('distribution').value;                                                   // 114
                                                                                                                       //
                if (distribution && distribution.length === 1 && distribution[0].fileFormat === 'HTML') {              // 115
                    return distribution[0].url;                                                                        // 116
                }                                                                                                      // 117
            }                                                                                                          // 118
        }                                                                                                              // 119
    },                                                                                                                 // 104
    distribution: {                                                                                                    // 122
        type: [DistributionSchema],                                                                                    // 123
        autoValue: function () {                                                                                       // 124
            if (this.isUpdate) {                                                                                       // 125
                this.unset();                                                                                          // 126
            } // return setAtCreation(this, undefined);                                                                // 127
                                                                                                                       //
        },                                                                                                             // 129
        label: "Dataset"                                                                                               // 130
    },                                                                                                                 // 122
    datasetTimeInterval: {                                                                                             // 133
        type: Object,                                                                                                  // 134
        label: "Time span",                                                                                            // 135
        optional: true                                                                                                 // 136
    },                                                                                                                 // 133
    "datasetTimeInterval.startTime": {                                                                                 // 139
        type: Date,                                                                                                    // 140
        label: "Start",                                                                                                // 141
        autoform: {                                                                                                    // 142
            type: "bootstrap-datepicker" // set to bootstrap-datepicker to work with materilize, check out https://github.com/djhi/meteor-autoform-materialize/
                                                                                                                       //
        }                                                                                                              // 142
    },                                                                                                                 // 139
    "datasetTimeInterval.endTime": {                                                                                   // 147
        type: Date,                                                                                                    // 148
        label: "End",                                                                                                  // 149
        autoform: {                                                                                                    // 150
            type: "bootstrap-datepicker"                                                                               // 151
        }                                                                                                              // 150
    },                                                                                                                 // 147
    spatial: {                                                                                                         // 155
        type: String,                                                                                                  // 156
        label: "Spatial coverage",                                                                                     // 157
        optional: true                                                                                                 // 158
    }                                                                                                                  // 155
}; //_.extend(Dataset, CreativeWork);                                                                                  // 102
//important, generate whitelist before constructing simpleschema                                                       // 163
//datasetWhitelist = _.filter(_.keys(Dataset), function (property) {                                                   // 164
//    return !Dataset[property].noneditable;                                                                           // 165
//});                                                                                                                  // 166
//                                                                                                                     // 167
//_.extend(datasetWhitelist, Whitelist);                                                                               // 168
//                                                                                                                     // 169
//datasetBlackList = _.filter(_.keys(Dataset), function (property) {                                                   // 170
//    return Dataset[property].noneditable;                                                                            // 171
//});                                                                                                                  // 172
//                                                                                                                     // 173
//_.extend(datasetBlackList, BlackList);                                                                               // 174
/* the following will cause errors;                                                                                    // 176
 * new SimpleSchema(Dataset)) modifies Dataset and therefore modifies CreativeWork                                     //
 _.extend(Dataset, CreativeWork);                                                                                      //
 Datasets.attachSchema(new SimpleSchema(Dataset));                                                                     //
 */                                                                                                                    //
Datasets.attachSchema(new SimpleSchema([Thing, DatasetSchema, CreativeWork]));                                         // 181
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/groups.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 24/12/2015.                                                                                      //
 */var Group = {                                                                                                       //
    name: {                                                                                                            // 6
        type: String                                                                                                   // 6
    },                                                                                                                 // 6
    description: {                                                                                                     // 8
        type: String,                                                                                                  // 8
        optional: true                                                                                                 // 8
    },                                                                                                                 // 8
    // url: {type: String, label: 'Home page', regEx: SimpleSchema.RegEx.Url, optional: true, autoform: {type: 'url'}},
    // youtube: {type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: {type: 'url'}},                // 12
    // github: {type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: {type: 'url'}},                 // 14
    publisher: orion.attribute('createdBy'),                                                                           // 16
    publisherName: {                                                                                                   // 18
        type: String,                                                                                                  // 19
        optional: true,                                                                                                // 20
        autoform: {                                                                                                    // 21
            type: 'hidden' // omit: true                                                                               // 22
                                                                                                                       //
        },                                                                                                             // 21
        autoValue: function () {                                                                                       // 25
            var publisher = this.field('publisher');                                                                   // 26
                                                                                                                       //
            if (publisher.isSet) {                                                                                     // 27
                var pId = publisher.value;                                                                             // 28
                var user = Meteor.users.findOne(pId);                                                                  // 29
                                                                                                                       //
                if (user) {                                                                                            // 30
                    return user.username;                                                                              // 31
                } else {                                                                                               // 32
                    this.unset();                                                                                      // 33
                }                                                                                                      // 34
            } else {                                                                                                   // 35
                this.unset();                                                                                          // 36
            }                                                                                                          // 37
        }                                                                                                              // 38
    },                                                                                                                 // 18
    //who can access this entry disregards acl settings                                                                // 41
    //used as Members field to reuse existing functions                                                                // 42
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 43
        type: [String],                                                                                                // 44
        label: 'Members',                                                                                              // 45
        // optional is true because you can have a post without comments                                               // 46
        optional: true                                                                                                 // 47
    }, {                                                                                                               // 43
        collection: Meteor.users,                                                                                      // 49
        titleField: 'username',                                                                                        // 50
        publicationName: 'groupmembers'                                                                                // 51
    }),                                                                                                                // 48
    datasets: orion.attribute('hasMany', {                                                                             // 54
        type: [String],                                                                                                // 55
        label: 'Datasets',                                                                                             // 56
        // optional is true because you can have a post without comments                                               // 57
        optional: true                                                                                                 // 58
    }, {                                                                                                               // 54
        collection: Datasets,                                                                                          // 60
        titleField: 'name',                                                                                            // 61
        publicationName: 'groupdatasets'                                                                               // 62
    }),                                                                                                                // 59
    apps: orion.attribute('hasMany', {                                                                                 // 65
        type: [String],                                                                                                // 66
        label: 'Apps',                                                                                                 // 67
        // optional is true because you can have a post without comments                                               // 68
        optional: true                                                                                                 // 69
    }, {                                                                                                               // 65
        collection: Apps,                                                                                              // 71
        titleField: 'name',                                                                                            // 72
        publicationName: 'groupapps'                                                                                   // 73
    }),                                                                                                                // 70
    //publications: {type: [Object], label: "Publications", optional: true},                                           // 76
    "publications.$.name": {                                                                                           // 77
        type: String,                                                                                                  // 77
        optional: true                                                                                                 // 77
    },                                                                                                                 // 77
    "publications.$.url": {                                                                                            // 78
        type: String,                                                                                                  // 78
        optional: true,                                                                                                // 78
        autoform: {                                                                                                    // 78
            type: 'url'                                                                                                // 78
        }                                                                                                              // 78
    },                                                                                                                 // 78
    datePublished: orion.attribute('createdAt'),                                                                       // 80
    dateModified: orion.attribute('updatedAt'),                                                                        // 81
    upvoters: {                                                                                                        // 82
        type: [String],                                                                                                // 83
        optional: true,                                                                                                // 84
        autoform: {                                                                                                    // 85
            readonly: true                                                                                             // 86
        }                                                                                                              // 85
    },                                                                                                                 // 82
    votes: {                                                                                                           // 90
        type: Number,                                                                                                  // 91
        autoform: {                                                                                                    // 92
            readonly: true                                                                                             // 93
        },                                                                                                             // 92
        optional: true                                                                                                 // 95
    },                                                                                                                 // 90
    // whether this entry is online                                                                                    // 98
    // in case of a dataset, it's offline if any of its distribution is offline                                        // 99
    online: {                                                                                                          // 100
        type: Boolean,                                                                                                 // 101
        autoform: {                                                                                                    // 102
            type: 'hidden',                                                                                            // 103
            readonly: true                                                                                             // 104
        },                                                                                                             // 102
        defaultValue: true                                                                                             // 106
    },                                                                                                                 // 100
    //metadata permission i.e. visibility                                                                              // 109
    aclMeta: {                                                                                                         // 110
        type: Boolean,                                                                                                 // 111
        label: "Visible to everyone",                                                                                  // 112
        defaultValue: true                                                                                             // 113
    },                                                                                                                 // 110
    aclContent: {                                                                                                      // 116
        type: Boolean,                                                                                                 // 117
        label: "Everyone can join",                                                                                    // 118
        defaultValue: true                                                                                             // 119
    }                                                                                                                  // 116
};                                                                                                                     // 5
Groups.attachSchema(new SimpleSchema([Group]));                                                                        // 123
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/licenses.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 22/01/2016.                                                                                      //
 */var LicenseSchema = new SimpleSchema({                                                                              //
    name: {                                                                                                            // 6
        type: String,                                                                                                  // 7
        label: 'License name'                                                                                          // 8
    },                                                                                                                 // 6
    url: {                                                                                                             // 10
        type: String,                                                                                                  // 11
        label: 'License URL',                                                                                          // 12
        autoform: {                                                                                                    // 13
            type: 'url'                                                                                                // 14
        },                                                                                                             // 13
        optional: true                                                                                                 // 16
    },                                                                                                                 // 10
    publisher: orion.attribute('hasOne', {                                                                             // 18
        type: String,                                                                                                  // 19
        label: 'publisher',                                                                                            // 20
        denyUpdate: true,                                                                                              // 21
        autoValue: function () {                                                                                       // 22
            if (this.isInsert || this.isUpsert) {                                                                      // 23
                return Meteor.userId();                                                                                // 24
            } else {                                                                                                   // 25
                this.unset();                                                                                          // 26
            }                                                                                                          // 27
        },                                                                                                             // 28
        autoform: {                                                                                                    // 29
            type: 'select',                                                                                            // 30
            readonly: true,                                                                                            // 31
            omit: true                                                                                                 // 32
        } //noneditable: true                                                                                          // 29
                                                                                                                       //
    }, {                                                                                                               // 18
        collection: Meteor.users,                                                                                      // 36
        // the key whose value you want to show for each post document on the update form                              // 37
        titleField: 'username',                                                                                        // 38
        publicationName: 'licepublisher'                                                                               // 39
    }),                                                                                                                // 35
    text: {                                                                                                            // 41
        type: String,                                                                                                  // 42
        label: 'License content',                                                                                      // 43
        autoform: {                                                                                                    // 44
            type: 'textarea'                                                                                           // 45
        },                                                                                                             // 44
        optional: true                                                                                                 // 47
    },                                                                                                                 // 41
    datePublished: {                                                                                                   // 49
        type: Date,                                                                                                    // 50
        denyUpdate: true,                                                                                              // 51
        autoform: {                                                                                                    // 52
            readonly: true,                                                                                            // 53
            omit: true,                                                                                                // 54
            type: "bootstrap-datepicker"                                                                               // 55
        },                                                                                                             // 52
        autoValue: function () {                                                                                       // 57
            if (this.isInsert || this.isUpsert) {                                                                      // 58
                return new Date();                                                                                     // 59
            } else {                                                                                                   // 60
                this.unset(); // Prevent user from supplying their own value                                           // 61
            }                                                                                                          // 62
        }                                                                                                              // 63
    }                                                                                                                  // 49
});                                                                                                                    // 5
Licenses.attachSchema(LicenseSchema);                                                                                  // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/remote.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 12/05/2016.                                                                                      //
 */var remoteMeta = {                                                                                                  //
    origin: {                                                                                                          // 5
        type: String,                                                                                                  // 6
        label: 'Origin',                                                                                               // 7
        optional: true                                                                                                 // 8
    }                                                                                                                  // 5
};                                                                                                                     // 4
                                                                                                                       //
var ReleasedCreativeWork = _.clone(CreativeWork);                                                                      // 12
                                                                                                                       //
ReleasedCreativeWork.publisher = {                                                                                     // 14
    type: String,                                                                                                      // 15
    label: 'Publisher',                                                                                                // 16
    optional: true,                                                                                                    // 17
    autoform: {                                                                                                        // 18
        type: 'hidden'                                                                                                 // 18
    }                                                                                                                  // 18
};                                                                                                                     // 14
ReleasedCreativeWork.description = {                                                                                   // 21
    type: String,                                                                                                      // 22
    label: 'Description',                                                                                              // 23
    optional: true,                                                                                                    // 24
    autoform: {                                                                                                        // 25
        type: 'textarea'                                                                                               // 25
    }                                                                                                                  // 25
};                                                                                                                     // 21
ReleasedCreativeWork.metaWhiteList = {                                                                                 // 28
    type: [String],                                                                                                    // 29
    label: 'Permitted to see',                                                                                         // 30
    optional: true                                                                                                     // 31
};                                                                                                                     // 28
ReleasedCreativeWork.contentWhiteList = {                                                                              // 34
    type: [String],                                                                                                    // 35
    label: 'Permitted to access',                                                                                      // 36
    optional: true                                                                                                     // 37
};                                                                                                                     // 34
RemoteApps.attachSchema(new SimpleSchema([remoteMeta, AppSchema, ReleasedCreativeWork]));                              // 40
RemoteDatasets.attachSchema(new SimpleSchema([remoteMeta, DatasetSchema, ReleasedCreativeWork]));                      // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"config":{"at_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/config/at_config.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function ldapOrUserPass(error, state) {                                                                                // 1
    // console.log({error,state});                                                                                     // 2
    if (error && state === 'signIn' //user/pass login failed                                                           // 3
    && orion.dictionary.get('ldap.ldap') && orion.dictionary.get('ldap.ldap').length !== 0) {                          // 3
        var username = document.getElementById("at-field-username_and_email").value;                                   // 7
        pass = document.getElementById("at-field-password").value;                                                     // 8
        Meteor.loginWithLdap(username, pass, function (err) {                                                          // 10
            if (err) {                                                                                                 // 11
                var errSpan = $('.at-form .at-error span');                                                            // 12
                errSpan.html("<i class=\"mdi-alert-warning\"></i> " + err.reason);                                     // 13
            }                                                                                                          // 14
        });                                                                                                            // 15
    }                                                                                                                  // 16
} // Options                                                                                                           // 17
                                                                                                                       //
                                                                                                                       //
AccountsTemplates.configure({                                                                                          // 19
    // defaultLayout: 'emptyLayout',                                                                                   // 20
    showForgotPasswordLink: true,                                                                                      // 21
    overrideLoginErrors: false,                                                                                        // 22
    enablePasswordChange: true,                                                                                        // 23
    sendVerificationEmail: false,                                                                                      // 25
    // enforceEmailVerification: true,                                                                                 // 26
    confirmPassword: true,                                                                                             // 27
    //continuousValidation: false,                                                                                     // 28
    //displayFormLabels: true,                                                                                         // 29
    forbidClientAccountCreation: false,                                                                                // 30
    //formValidationFeedback: true,                                                                                    // 31
    homeRoutePath: '/',                                                                                                // 32
    //showAddRemoveServices: false,                                                                                    // 33
    showPlaceholders: true,                                                                                            // 34
    lowercaseUsername: true,                                                                                           // 35
    onSubmitHook: ldapOrUserPass,                                                                                      // 36
    continuousValidation: true,                                                                                        // 37
    negativeValidation: true,                                                                                          // 38
    positiveValidation: true,                                                                                          // 39
    negativeFeedback: false,                                                                                           // 40
    positiveFeedback: true // Privacy Policy and Terms of Use                                                          // 41
    //privacyUrl: 'privacy',                                                                                           // 44
    //termsUrl: 'terms-of-use',                                                                                        // 45
                                                                                                                       //
});                                                                                                                    // 19
var pwd = AccountsTemplates.removeField('password');                                                                   // 48
AccountsTemplates.removeField('email');                                                                                // 49
AccountsTemplates.addFields([{                                                                                         // 50
    _id: "username",                                                                                                   // 52
    type: "text",                                                                                                      // 53
    displayName: "username",                                                                                           // 54
    required: true,                                                                                                    // 55
    minLength: 4                                                                                                       // 56
}, {                                                                                                                   // 51
    _id: 'email',                                                                                                      // 59
    type: 'email',                                                                                                     // 60
    required: true,                                                                                                    // 61
    displayName: "email",                                                                                              // 62
    re: /.+@(.+){2,}\.(.+){2,}/,                                                                                       // 63
    errStr: 'Invalid email'                                                                                            // 64
}, {                                                                                                                   // 58
    _id: 'username_and_email',                                                                                         // 67
    type: 'text',                                                                                                      // 68
    required: true,                                                                                                    // 69
    displayName: "Login"                                                                                               // 70
}, pwd]); // AccountsTemplates.addField({                                                                              // 66
//     _id: "isgroup",                                                                                                 // 76
//     type: "checkbox",                                                                                               // 77
//     displayName: "This is a group/organisational account",                                                          // 78
// });                                                                                                                 // 79
//                                                                                                                     // 80
// AccountsTemplates.addFields([{                                                                                      // 81
//     _id: "url",                                                                                                     // 82
//     type: "text",                                                                                                   // 83
//     displayName: "Home page"                                                                                        // 84
// }, {                                                                                                                // 85
//     _id: "description",                                                                                             // 86
//     type: "text",                                                                                                   // 87
//     displayName: "A brief description of this account"                                                              // 88
// }]);                                                                                                                // 89
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"roles":{"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/_utils.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//register actions                                                                                                     // 1
Roles.registerAction("collections.entries.access", true);                                                              // 2
Roles.debug = true; // check that the userId specified owns the documents                                              // 4
                                                                                                                       //
ownsDocument = function (userId, doc) {                                                                                // 7
    return doc && doc.publisher === userId || Roles.userHasRole(userId, "admin");                                      // 8
};                                                                                                                     // 9
                                                                                                                       //
ownsDocumentQuery = function () {                                                                                      // 11
    return {                                                                                                           // 12
        publisher: this.userId                                                                                         // 12
    };                                                                                                                 // 12
};                                                                                                                     // 13
                                                                                                                       //
viewsDocument = function (userId, doc) {                                                                               // 15
    if (!doc) {                                                                                                        // 16
        return false;                                                                                                  // 17
    }                                                                                                                  // 18
                                                                                                                       //
    if (!userId) {                                                                                                     // 20
        return doc.aclMeta;                                                                                            // 21
    }                                                                                                                  // 22
                                                                                                                       //
    if (doc) {                                                                                                         // 24
        return doc.aclMeta // publicly listed entries                                                                  // 25
        || ownsDocument(userId, doc // own entries                                                                     // 25
        ) || doc.metaWhiteList && _.contains(doc.metaWhiteList, userId); // white-listed user                          // 26
        // || Groups.find({contentWhiteList: userId}).fetch().some(group => viewsDocument(group.publisher, doc)); // member of white-listed groups, for null userId returning true if group doesn't have contentWhhiteList property
    } else {                                                                                                           // 29
        return false;                                                                                                  // 30
    }                                                                                                                  // 31
};                                                                                                                     // 32
                                                                                                                       //
accessesDocument = function (userId, doc) {                                                                            // 34
    if (!doc) {                                                                                                        // 35
        return false;                                                                                                  // 36
    }                                                                                                                  // 37
                                                                                                                       //
    if (!userId) {                                                                                                     // 39
        return doc.aclContent;                                                                                         // 40
    }                                                                                                                  // 41
                                                                                                                       //
    if (doc) {                                                                                                         // 43
        return doc.aclContent || ownsDocument(userId, doc) || doc.contentWhiteList && _.contains(doc.contentWhiteList, userId); // || Groups.find({contentWhiteList: userId}).fetch().some(group => accessesDocument(group.publisher, doc)); // member of white-listed groups
    } else {                                                                                                           // 48
        return false;                                                                                                  // 49
    }                                                                                                                  // 50
};                                                                                                                     // 51
                                                                                                                       //
viewsDocumentQuery = function (userId) {                                                                               // 53
    //anonymous user default                                                                                           // 55
    var query = {                                                                                                      // 56
        $or: [{                                                                                                        // 56
            aclMeta: true                                                                                              // 56
        }]                                                                                                             // 56
    }; //logged in user                                                                                                // 56
                                                                                                                       //
    if (userId) {                                                                                                      // 59
        //admin user                                                                                                   // 60
        if (Roles.userHasRole(userId, "admin")) {                                                                      // 61
            query = {                                                                                                  // 62
                $or: [{}]                                                                                              // 62
            };                                                                                                         // 62
        } else {                                                                                                       // 63
            //individual or group user                                                                                 // 64
            query = {                                                                                                  // 65
                $or: [{                                                                                                // 65
                    aclMeta: true                                                                                      // 65
                }, {                                                                                                   // 65
                    metaWhiteList: userId                                                                              // 65
                }, {                                                                                                   // 65
                    publisher: userId                                                                                  // 65
                }, {                                                                                                   // 65
                    contentWhiteList: userId                                                                           // 65
                }]                                                                                                     // 65
            }; //individual permission                                                                                 // 65
            // let groups = Groups.find({contentWhiteList: userId});                                                   // 66
            // //group permission                                                                                      // 67
            // groups.forEach(function (group) {                                                                       // 68
            //     query.$or.push({metaWhiteList: group.publisher});                                                   // 69
            // });                                                                                                     // 70
        }                                                                                                              // 71
    }                                                                                                                  // 72
                                                                                                                       //
    return query;                                                                                                      // 74
};                                                                                                                     // 75
                                                                                                                       //
isMemberQuery = function () {                                                                                          // 77
    return {                                                                                                           // 78
        contentWhiteList: this.userId                                                                                  // 78
    };                                                                                                                 // 78
}; //set @Role's permission according to @colRules                                                                     // 79
//@colRules is of the form {collection_name: [allowed_field]}                                                          // 82
//if allowed_field is a string set permission to true                                                                  // 83
//if allowed_field is a function, compute permission using the function                                                // 84
                                                                                                                       //
                                                                                                                       //
setCollectionGrants = function (Role, colRules) {                                                                      // 85
    for (var colName in meteorBabelHelpers.sanitizeForInObject(colRules)) {                                            // 86
        if (colRules.hasOwnProperty(colName)) {                                                                        // 87
            setRuleArray(Role, colName, colRules[colName]);                                                            // 88
        }                                                                                                              // 89
    }                                                                                                                  // 90
};                                                                                                                     // 91
                                                                                                                       //
function setRuleArray(Role, colName, fields) {                                                                         // 93
    for (var action in meteorBabelHelpers.sanitizeForInObject(fields)) {                                               // 95
        if (fields.hasOwnProperty(action)) {                                                                           // 96
            var field = fields[action];                                                                                // 97
                                                                                                                       //
            if (typeof field === 'string') {                                                                           // 99
                Role.allow('collections.' + colName + '.' + field, true);                                              // 100
            }                                                                                                          // 101
                                                                                                                       //
            if (typeof field === 'function') {                                                                         // 103
                Role.allow('collections.' + colName + '.' + action, field);                                            // 104
            }                                                                                                          // 105
        }                                                                                                              // 106
    }                                                                                                                  // 107
}                                                                                                                      // 108
                                                                                                                       //
;                                                                                                                      // 108
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"individual.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/individual.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Options.set('defaultRoles', ['individual']); /*                                                                        // 1
                                              * First you must define the role                                         //
                                              */                                                                       //
var Atom = new Roles.Role('individual'),                                                                               // 5
    grants = {                                                                                                         // 5
    entries: {                                                                                                         // 7
        access: function (entry) {                                                                                     // 8
            return accessesDocument(this.userId, entry);                                                               // 9
        }                                                                                                              // 10
    },                                                                                                                 // 7
    datasets: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                     // 12
    apps: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                         // 13
    client: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                         // 14
    licenses: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                       // 15
    comments: ['index'],                                                                                               // 16
    groups: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove']                          // 17
};                                                                                                                     // 6
setCollectionGrants(Atom, grants);                                                                                     // 20
Atom.helper('collections.datasets.indexFilter', ownsDocumentQuery);                                                    // 22
Atom.helper('collections.apps.indexFilter', ownsDocumentQuery);                                                        // 23
Atom.helper('collections.client.indexFilter', ownsDocumentQuery);                                                      // 24
Atom.helper('collections.licenses.indexFilter', ownsDocumentQuery);                                                    // 25
Atom.helper('collections.comments.indexFilter', ownsDocumentQuery);                                                    // 26
Atom.helper('collections.groups.indexFilter', isMemberQuery); //forbidden fields                                       // 27
//will cause access denied issue when creating new entries                                                             // 30
// Atom.helper('collections.datasets.forbiddenFields', omitFields);                                                    // 31
// Atom.helper('collections.apps.forbiddenFields', omitFields);                                                        // 32
//Atom.helper('collections.licenses.forbiddenFields', ['publisher', 'datePublished']);                                 // 33
//Atom.helper('collections.client.forbiddenFields', ['clientSecret', 'publisher', 'datePublished']);                   // 34
//Atom.helper('collections.comments.forbiddenFields', ['publisher', 'entryId', 'submitted']);                          // 35
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/_utils.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 15/01/2016.                                                                                      //
 */ /*                                                                                                                 //
     * Extends @query with @or clause                                                                                  //
     * If @query.$or exists, replace it with $and:[{$or:query.$or}, or]                                                //
     */extendOr = function (query, or) {                                                                               //
    check(query, Object);                                                                                              // 10
    check(or, {                                                                                                        // 11
        $or: Array                                                                                                     // 11
    });                                                                                                                // 11
                                                                                                                       //
    if (query.$or) {                                                                                                   // 13
        query.$and = [{                                                                                                // 14
            $or: query.$or                                                                                             // 14
        }, or];                                                                                                        // 14
        delete query.$or;                                                                                              // 15
    } else {                                                                                                           // 16
        _.extend(query, or);                                                                                           // 17
    }                                                                                                                  // 18
};                                                                                                                     // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_config.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/05/2016.                                                                                      //
 */orion.config.add('wo_urls', 'WO', {                                                                                 //
  type: [String],                                                                                                      // 5
  label: 'WO URLs'                                                                                                     // 5
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_dictionary.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_dictionary.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// orion.dictionary.addDefinition('image', 'comment',                                                                  // 1
//   orion.attribute('image', {                                                                                        // 2
//       label: 'Comment Image',                                                                                       // 3
//       optional: true                                                                                                // 4
//   })                                                                                                                // 5
// );                                                                                                                  // 6
orion.dictionary.addDefinition('title', 'mainPage', {                                                                  // 8
    type: String,                                                                                                      // 9
    label: 'Site Title',                                                                                               // 10
    optional: false,                                                                                                   // 11
    min: 1,                                                                                                            // 12
    max: 40                                                                                                            // 13
});                                                                                                                    // 8
orion.dictionary.addDefinition('description', 'mainPage', {                                                            // 16
    type: String,                                                                                                      // 17
    label: 'Site Description',                                                                                         // 18
    optional: true                                                                                                     // 19
});                                                                                                                    // 16
orion.dictionary.addDefinition('termsAndConditions', 'submitPostPage', {                                               // 23
    type: String,                                                                                                      // 24
    label: 'Terms and Conditions',                                                                                     // 25
    optional: true                                                                                                     // 26
}); //ldap                                                                                                             // 23
                                                                                                                       //
var ldapSchema = new SimpleSchema({                                                                                    // 31
    domain: {                                                                                                          // 32
        type: String                                                                                                   // 32
    },                                                                                                                 // 32
    serverDn: {                                                                                                        // 33
        type: String,                                                                                                  // 33
        label: 'Server DN'                                                                                             // 33
    },                                                                                                                 // 33
    serverUrl: {                                                                                                       // 34
        type: String,                                                                                                  // 34
        label: 'Server Url'                                                                                            // 34
    },                                                                                                                 // 34
    whiteListedFields: {                                                                                               // 35
        type: String,                                                                                                  // 35
        label: 'Included fields'                                                                                       // 35
    }                                                                                                                  // 35
});                                                                                                                    // 31
orion.dictionary.addDefinition('ldap', 'ldap', {                                                                       // 38
    type: [ldapSchema]                                                                                                 // 38
});                                                                                                                    // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_filesystem.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_filesystem.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
///**                                                                                                                  // 1
// * Official S3 Upload Provider                                                                                       // 2
// *                                                                                                                   // 3
// * Please replace this function with the                                                                             // 4
// * provider you prefer.                                                                                              // 5
// *                                                                                                                   // 6
// * If success, call success(publicUrl);                                                                              // 7
// * you can pass data and it will be saved in file.meta                                                               // 8
// * Ej: success(publicUrl, {local_path: '/user/path/to/file'})                                                        // 9
// *                                                                                                                   // 10
// * If it fails, call failure(error).                                                                                 // 11
// *                                                                                                                   // 12
// * When the progress change, call progress(newProgress)                                                              // 13
// */                                                                                                                  // 14
//orion.filesystem.providerUpload = function(options, success, failure, progress) {                                    // 15
//  S3.upload({                                                                                                        // 16
//    files: options.fileList,                                                                                         // 17
//    path: 'orionjs',                                                                                                 // 18
//  }, function(error, result) {                                                                                       // 19
//    debugger                                                                                                         // 20
//    if (error) {                                                                                                     // 21
//      failure(error);                                                                                                // 22
//    } else {                                                                                                         // 23
//      success(result.secure_url, { s3Path: result.relative_url });                                                   // 24
//      result;                                                                                                        // 25
//      debugger                                                                                                       // 26
//    }                                                                                                                // 27
//    S3.collection.remove({})                                                                                         // 28
//  });                                                                                                                // 29
//  Tracker.autorun(function () {                                                                                      // 30
//    let file = S3.collection.findOne();                                                                              // 31
//    if (file) {                                                                                                      // 32
//      progress(file.percent_uploaded);                                                                               // 33
//    }                                                                                                                // 34
//  });                                                                                                                // 35
//};                                                                                                                   // 36
//                                                                                                                     // 37
///**                                                                                                                  // 38
// * Official S3 Remove Provider                                                                                       // 39
// *                                                                                                                   // 40
// * Please replace this function with the                                                                             // 41
// * provider you prefer.                                                                                              // 42
// *                                                                                                                   // 43
// * If success, call success();                                                                                       // 44
// * If it fails, call failure(error).                                                                                 // 45
// */                                                                                                                  // 46
//orion.filesystem.providerRemove = function(file, success, failure)  {                                                // 47
//  S3.delete(file.meta.s3Path, function(error, result) {                                                              // 48
//    if (error) {                                                                                                     // 49
//      failure(error);                                                                                                // 50
//    } else {                                                                                                         // 51
//      success();                                                                                                     // 52
//    }                                                                                                                // 53
//  })                                                                                                                 // 54
//};                                                                                                                   // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/router.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                          //
                                                                                                                       //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                                 //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
Router.configure({                                                                                                     // 1
    layoutTemplate: 'layout',                                                                                          // 2
    loadingTemplate: 'loading',                                                                                        // 3
    notFoundTemplate: 'notFound',                                                                                      // 4
    subscriptions: function () {                                                                                       // 5
        //using waitOn will cause entry_list to reload every time load-more is clicked                                 // 5
        return [Meteor.subscribe(Notifications.pluralName), Meteor.subscribe(Groups.pluralName), Meteor.subscribe(Meteor.users.pluralName), Meteor.subscribe(Licenses.pluralName)];
    }                                                                                                                  // 12
});                                                                                                                    // 1
ListController = RouteController.extend({                                                                              // 15
    template: 'entryList',                                                                                             // 16
    increment: 12,                                                                                                     // 17
    //query modifier generation helper                                                                                 // 18
    entriesLimit: function () {                                                                                        // 19
        return parseInt(this.params.entriesLimit) || this.increment;                                                   // 20
    },                                                                                                                 // 21
    //query modifier generator                                                                                         // 22
    findOptions: function () {                                                                                         // 23
        return {                                                                                                       // 24
            sort: this.sort,                                                                                           // 24
            limit: this.entriesLimit()                                                                                 // 24
        };                                                                                                             // 24
    },                                                                                                                 // 25
    //query generator                                                                                                  // 26
    findSelector: function () {                                                                                        // 27
        var textFilter = search(Session.get('search'));                                                                // 28
        var query = {},                                                                                                // 29
            _query = this.params.query;                                                                                // 29
                                                                                                                       //
        _.keys(_query).forEach(function (key) {                                                                        // 31
            switch (key) {                                                                                             // 32
                case 'online':                                                                                         // 33
                case 'aclMeta':                                                                                        // 34
                case 'aclContent':                                                                                     // 35
                    query[key] = _query[key].toLowerCase() === 'true';                                                 // 36
                    break;                                                                                             // 37
                                                                                                                       //
                default:                                                                                               // 38
                    query[key] = _query[key];                                                                          // 39
            }                                                                                                          // 32
        });                                                                                                            // 41
                                                                                                                       //
        _.extend(query, textFilter); ////this function runs twice due to reactivity (subscriptions)                    // 43
        ////set findSelector to return the computed query straight away                                                // 46
        ////in the second run                                                                                          // 47
        //this.findSelector = function () {                                                                            // 48
        //    return query;                                                                                            // 49
        //}                                                                                                            // 50
                                                                                                                       //
                                                                                                                       //
        return query;                                                                                                  // 51
    },                                                                                                                 // 52
    //collection of entries (e.g. Apps, Datasets)                                                                      // 53
    category: null,                                                                                                    // 54
    //overrided in sub controllers                                                                                     // 54
    //displayed entries                                                                                                // 55
    entries: function () {                                                                                             // 56
        return this.category.find({}, {                                                                                // 57
            sort: this.findOptions.sort                                                                                // 57
        });                                                                                                            // 57
    },                                                                                                                 // 58
    // helper to generate route names of a given category;                                                             // 59
    // a workaround since cannot dynamically concatenate variables in templates                                        // 60
    routes: function () {                                                                                              // 61
        var cat = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.category.singularName;      // 61
        return ['latest', 'page', 'submit', 'edit'].reduce(function (routes, action) {                                 // 62
            routes[action] = cat + '.' + action;                                                                       // 63
            return routes;                                                                                             // 64
        }, {});                                                                                                        // 65
    },                                                                                                                 // 66
    data: function () {                                                                                                // 67
        var self = this;                                                                                               // 68
        return {                                                                                                       // 69
            category: self.category,                                                                                   // 70
            entries: self.entries(),                                                                                   // 71
            //show search bar in top nav on entry list page                                                            // 72
            showSearch: true,                                                                                          // 73
            //show Add button if logged in                                                                             // 74
            showAdd: true,                                                                                             // 75
            ready: self.ready.bind(self),                                                                              // 76
            routes: self.routes(),                                                                                     // 77
            //generate path to load next page of entries                                                               // 78
            nextPath: function () {                                                                                    // 79
                if (self.category.find().count() === self.entriesLimit()) {                                            // 80
                    return self.nextPath();                                                                            // 81
                }                                                                                                      // 82
            }                                                                                                          // 83
        };                                                                                                             // 69
    }                                                                                                                  // 85
});                                                                                                                    // 15
                                                                                                                       //
RegExp.prototype.toJSONValue = function () {                                                                           // 88
    var flags = '';                                                                                                    // 89
                                                                                                                       //
    if (this.global) {                                                                                                 // 90
        flags += 'g';                                                                                                  // 91
    }                                                                                                                  // 92
                                                                                                                       //
    if (this.ignoreCase) {                                                                                             // 93
        flags += 'i';                                                                                                  // 94
    }                                                                                                                  // 95
                                                                                                                       //
    if (this.multiline) {                                                                                              // 96
        flags += 'm';                                                                                                  // 97
    }                                                                                                                  // 98
                                                                                                                       //
    return [this.source, flags];                                                                                       // 99
};                                                                                                                     // 100
                                                                                                                       //
RegExp.prototype.typeName = function () {                                                                              // 102
    return "regex";                                                                                                    // 103
};                                                                                                                     // 104
                                                                                                                       //
EJSON.addType("regex", function (str) {                                                                                // 106
    return new (Function.prototype.bind.apply(RegExp, [null].concat((0, _toConsumableArray3.default)(str))))();        // 107
});                                                                                                                    // 108
                                                                                                                       //
function search(searchText) {                                                                                          // 110
    var selector = void 0;                                                                                             // 111
                                                                                                                       //
    if (searchText) {                                                                                                  // 112
        var regExp = buildRegExp(searchText);                                                                          // 113
        selector = {                                                                                                   // 114
            $or: [{                                                                                                    // 115
                name: regExp                                                                                           // 116
            }, {                                                                                                       // 116
                description: regExp                                                                                    // 117
            }, {                                                                                                       // 117
                'distribution.fileFormat': regExp                                                                      // 118
            }]                                                                                                         // 118
        };                                                                                                             // 114
    } else {                                                                                                           // 121
        selector = {};                                                                                                 // 122
    }                                                                                                                  // 123
                                                                                                                       //
    return selector;                                                                                                   // 125
} //any position                                                                                                       // 126
                                                                                                                       //
                                                                                                                       //
function buildRegExp(searchText) {                                                                                     // 129
    var parts = searchText.trim().split(/[ \-\:]+/);                                                                   // 130
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 131
} //type ahead                                                                                                         // 132
//function buildRegExp(searchText) {                                                                                   // 135
//    let words = searchText.trim().split(/[ \-\:]+/);                                                                 // 136
//    let exps = _.map(words, function (word) {                                                                        // 137
//        return "(?=.*" + word + ")";                                                                                 // 138
//    });                                                                                                              // 139
//    let fullExp = exps.join('') + ".+";                                                                              // 140
//    return new RegExp(fullExp, "i");                                                                                 // 141
//}                                                                                                                    // 142
/***************************                                                                                           // 143
 * entry list                                                                                                          //
 **************************/                                                                                           //
                                                                                                                       //
LatestController = ListController.extend({                                                                             // 146
    subscriptions: function () {                                                                                       // 147
        return Meteor.subscribe(this.category.pluralName, this.findOptions(), this.findSelector());                    // 148
    },                                                                                                                 // 149
    sort: {                                                                                                            // 150
        datePublished: -1,                                                                                             // 150
        votes: -1,                                                                                                     // 150
        downvotes: 1,                                                                                                  // 150
        _id: -1                                                                                                        // 150
    },                                                                                                                 // 150
    nextPath: function () {                                                                                            // 151
        return Router.routes[this.category.singularName + '.latest'].path({                                            // 152
            entriesLimit: this.entriesLimit() + this.increment                                                         // 152
        });                                                                                                            // 152
    }                                                                                                                  // 153
});                                                                                                                    // 146
DatasetLatestController = LatestController.extend({                                                                    // 156
    category: Datasets                                                                                                 // 157
});                                                                                                                    // 156
RemotedatasetLatestController = LatestController.extend({                                                              // 160
    category: RemoteDatasets                                                                                           // 161
});                                                                                                                    // 160
AppLatestController = LatestController.extend({                                                                        // 164
    category: Apps                                                                                                     // 165
});                                                                                                                    // 164
RemoteappLatestController = LatestController.extend({                                                                  // 168
    category: RemoteApps                                                                                               // 169
});                                                                                                                    // 168
GroupLatestController = LatestController.extend({                                                                      // 172
    category: Groups                                                                                                   // 173
}); /***************************                                                                                       // 172
     * entry page                                                                                                      //
     **************************/                                                                                       //
PageController = ListController.extend({                                                                               // 178
    template: 'entryPage',                                                                                             // 179
    subscriptions: function () {                                                                                       // 180
        return [Meteor.subscribe('comments', this.params._id), Meteor.subscribe(this.category.singularName, this.params._id)];
    },                                                                                                                 // 183
    data: function () {                                                                                                // 184
        return {                                                                                                       // 185
            comments: Comments.find({                                                                                  // 186
                entryId: this.params._id                                                                               // 186
            }),                                                                                                        // 186
            category: this.category,                                                                                   // 187
            entry: this.category.findOne(this.params._id),                                                             // 188
            routes: this.routes(this.category.singularName) //_isTemplated:true,                                       // 189
                                                                                                                       //
        };                                                                                                             // 185
    }                                                                                                                  // 192
});                                                                                                                    // 178
DatasetPageController = PageController.extend({                                                                        // 195
    category: Datasets                                                                                                 // 196
});                                                                                                                    // 195
RemotedatasetPageController = PageController.extend({                                                                  // 199
    category: RemoteDatasets                                                                                           // 200
});                                                                                                                    // 199
AppPageController = PageController.extend({                                                                            // 203
    category: Apps                                                                                                     // 204
});                                                                                                                    // 203
RemoteappPageController = PageController.extend({                                                                      // 207
    category: RemoteApps                                                                                               // 208
});                                                                                                                    // 207
GroupPageController = PageController.extend({                                                                          // 211
    category: Groups                                                                                                   // 212
});                                                                                                                    // 211
GroupPageByNameController = ListController.extend({                                                                    // 215
    template: 'entryPage',                                                                                             // 216
    category: Groups,                                                                                                  // 217
    subscriptions: function () {                                                                                       // 218
        return Meteor.subscribe(this.category.pluralName, {                                                            // 219
            limit: 1                                                                                                   // 219
        }, {                                                                                                           // 219
            name: this.params.name                                                                                     // 219
        });                                                                                                            // 219
    },                                                                                                                 // 220
    data: function () {                                                                                                // 221
        return {                                                                                                       // 222
            // comments: Comments.find({entryId: this.params._id}),                                                    // 223
            category: this.category,                                                                                   // 224
            entry: this.category.findOne({                                                                             // 225
                name: this.params.name                                                                                 // 225
            }),                                                                                                        // 225
            routes: this.routes(this.category.singularName)                                                            // 226
        };                                                                                                             // 222
    }                                                                                                                  // 228
});                                                                                                                    // 215
                                                                                                                       //
function templateData(router, col, option) {                                                                           // 231
    return {                                                                                                           // 232
        category: col,                                                                                                 // 233
        routes: router.routes(col.singularName),                                                                       // 234
        entries: router.getEntries(option, col),                                                                       // 235
        ready: router.ready.bind(router)                                                                               // 236
    };                                                                                                                 // 232
}                                                                                                                      // 238
                                                                                                                       //
HomeController = ListController.extend({                                                                               // 240
    template: 'home',                                                                                                  // 241
    increment: 8,                                                                                                      // 242
    sort: {                                                                                                            // 243
        votes: -1,                                                                                                     // 243
        downvotes: 1,                                                                                                  // 243
        datePublished: -1,                                                                                             // 243
        _id: -1                                                                                                        // 243
    },                                                                                                                 // 243
    subscriptions: function () {                                                                                       // 244
        var _this = this;                                                                                              // 244
                                                                                                                       //
        return [Datasets, Apps, RemoteDatasets, RemoteApps].map(function (col) {                                       // 245
            return Meteor.subscribe(col.pluralName, _this.findOptions());                                              // 246
        });                                                                                                            // 246
    },                                                                                                                 // 247
    getEntries: function (options, col) {                                                                              // 248
        if (!options) options = this.findOptions();                                                                    // 249
        return col.find({}, options);                                                                                  // 251
    },                                                                                                                 // 252
    nextPath: function () {                                                                                            // 253
        return Router.routes['datasets.latest'].path({                                                                 // 254
            entriesLimit: this.entriesLimit() + this.increment                                                         // 254
        });                                                                                                            // 254
    },                                                                                                                 // 255
    data: function () {                                                                                                // 256
        var homeTempData = templateData.bind(null, this);                                                              // 257
        var byPubData = {                                                                                              // 258
            sort: {                                                                                                    // 258
                datePublished: -1                                                                                      // 258
            },                                                                                                         // 258
            limit: 8                                                                                                   // 258
        },                                                                                                             // 258
            byVote = {                                                                                                 // 258
            sort: {                                                                                                    // 259
                votes: -1                                                                                              // 259
            },                                                                                                         // 259
            limit: 8                                                                                                   // 259
        }; // let self = this;                                                                                         // 259
                                                                                                                       //
        return {                                                                                                       // 261
            recentDataset: homeTempData(Datasets, byPubData),                                                          // 262
            recentApp: homeTempData(Apps, byPubData),                                                                  // 263
            dataset: homeTempData(Datasets, byVote),                                                                   // 264
            app: homeTempData(Apps, byVote),                                                                           // 265
            remoteApp: homeTempData(RemoteApps, byPubData),                                                            // 266
            remoteDataset: homeTempData(RemoteDatasets, byPubData),                                                    // 267
            _isHome: true,                                                                                             // 268
            _isTemplated: true                                                                                         // 269
        };                                                                                                             // 261
    }                                                                                                                  // 271
}); /****************************************************************                                                  // 240
     * Routes                                                                                                          //
     * Route naming schema {{coll.pluralName}}.{{action}}                                                              //
     *****************************************************************/ /*                                             //
                                                                         * Home                                        //
                                                                         */                                            //
Router.route('/', {                                                                                                    // 283
    name: 'home'                                                                                                       // 283
}); /*                                                                                                                 // 283
     * Geo API                                                                                                         //
     */                                                                                                                //
Router.route("/geodata", {                                                                                             // 289
    template: "geoapi",                                                                                                // 290
    name: "geoapi",                                                                                                    // 291
    subscriptions: function () {                                                                                       // 292
        // returning a subscription handle or an array of subscription handles                                         // 293
        // adds them to the wait list.                                                                                 // 294
        return Meteor.subscribe('datasets', {});                                                                       // 295
    },                                                                                                                 // 296
    data: function () {                                                                                                // 297
        return {                                                                                                       // 298
            category: Datasets,                                                                                        // 299
            col: 'Datasets',                                                                                           // 300
            entries: function () {                                                                                     // 301
                return this.category.find({                                                                            // 302
                    'distribution.profile.geodata': {                                                                  // 302
                        $exists: true                                                                                  // 302
                    }                                                                                                  // 302
                });                                                                                                    // 302
            }                                                                                                          // 303
        };                                                                                                             // 298
    },                                                                                                                 // 305
    //default action                                                                                                   // 306
    action: function () {                                                                                              // 307
        this.render();                                                                                                 // 308
    }                                                                                                                  // 309
});                                                                                                                    // 289
                                                                                                                       //
function setUpRoutes(col) {                                                                                            // 313
    var hasRemote = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;                         // 313
    var sn = col.singularName,                                                                                         // 314
        pn = col.pluralName;                                                                                           // 314
    Router.route("/new/" + pn + "/:entriesLimit?", {                                                                   // 316
        name: sn + ".latest"                                                                                           // 316
    });                                                                                                                // 316
    Router.route("/" + pn + "/submit", {                                                                               // 318
        template: "entrySubmit",                                                                                       // 319
        name: sn + ".submit",                                                                                          // 320
        data: function () {                                                                                            // 321
            return {                                                                                                   // 322
                category: col,                                                                                         // 322
                col: pn.substr(0, 1).toUpperCase() + pn.substr(1)                                                      // 322
            };                                                                                                         // 322
        }                                                                                                              // 323
    });                                                                                                                // 318
    Router.route("/" + pn + "/:_id", {                                                                                 // 326
        name: sn + ".page"                                                                                             // 326
    });                                                                                                                // 326
    Router.route("/" + pn + "/:_id/edit", {                                                                            // 328
        name: sn + ".edit",                                                                                            // 329
        template: "entryEdit",                                                                                         // 330
        subscriptions: function () {                                                                                   // 331
            return Meteor.subscribe(sn, this.params._id);                                                              // 332
        },                                                                                                             // 333
        data: function () {                                                                                            // 334
            return {                                                                                                   // 335
                category: col,                                                                                         // 336
                entry: col.findOne(this.params._id)                                                                    // 337
            };                                                                                                         // 335
        }                                                                                                              // 339
    });                                                                                                                // 328
                                                                                                                       //
    if (hasRemote) {                                                                                                   // 342
        Router.route("/new/remote_" + pn + "/:entriesLimit?", {                                                        // 343
            name: "remote" + sn + ".latest"                                                                            // 343
        });                                                                                                            // 343
        Router.route("/remote_" + pn + "/:_id", {                                                                      // 344
            name: "remote" + sn + ".page"                                                                              // 344
        });                                                                                                            // 344
    }                                                                                                                  // 345
} /*                                                                                                                   // 346
   * Datasets routes                                                                                                   //
   */                                                                                                                  //
                                                                                                                       //
setUpRoutes(Datasets, true); /*                                                                                        // 351
                              * Apps routes                                                                            //
                              */                                                                                       //
setUpRoutes(Apps, true); /*                                                                                            // 356
                          * Groups                                                                                     //
                          */                                                                                           //
setUpRoutes(Groups); // Router.route(`/project/:name`, {name: `${Groups.singularName}.PageByName`});                   // 362
/*                                                                                                                     // 367
 * Accounts                                                                                                            //
 */                                                                                                                    //
AccountsTemplates.configureRoute('changePwd');                                                                         // 371
AccountsTemplates.configureRoute('enrollAccount');                                                                     // 372
AccountsTemplates.configureRoute('forgotPwd');                                                                         // 373
AccountsTemplates.configureRoute('resetPwd');                                                                          // 374
AccountsTemplates.configureRoute('signIn', {                                                                           // 375
    redirect: function () {                                                                                            // 376
        var ref = RouterLayer.getQueryParam('return_url'),                                                             // 377
            userId = Meteor.userId();                                                                                  // 377
                                                                                                                       //
        if (ref && userId) {                                                                                           // 379
            Cookie.set("meteor_user_id", userId);                                                                      // 380
            Cookie.set("meteor_token", localStorage.getItem("Meteor.loginToken"));                                     // 381
            window.location.replace(ref);                                                                              // 382
        }                                                                                                              // 383
    }                                                                                                                  // 384
});                                                                                                                    // 375
AccountsTemplates.configureRoute('signUp');                                                                            // 386
AccountsTemplates.configureRoute('verifyEmail'); /*                                                                    // 387
                                                  * Helpers                                                            //
                                                  */                                                                   //
                                                                                                                       //
function requireLogin() {                                                                                              // 392
    if (!Meteor.user()) {                                                                                              // 393
        if (Meteor.loggingIn()) {                                                                                      // 394
            this.render(this.loadingTemplate);                                                                         // 395
        } else {                                                                                                       // 396
            this.render('accessDenied', {                                                                              // 397
                data: 'Please sign in.'                                                                                // 397
            });                                                                                                        // 397
        }                                                                                                              // 398
    } else {                                                                                                           // 399
        this.next();                                                                                                   // 400
    }                                                                                                                  // 401
} //Router.onBeforeAction('dataNotFound', {only: 'dataset.page'});                                                     // 402
                                                                                                                       //
                                                                                                                       //
Router.onBeforeAction(requireLogin, {                                                                                  // 405
    only: ['dataset.submit', 'dataset.edit', 'app.submit', 'app.edit']                                                 // 405
});                                                                                                                    // 405
Router.onBeforeAction(function () {                                                                                    // 407
    var _data = this.data(),                                                                                           // 407
        entry = _data.entry,                                                                                           // 407
        category = _data.category;                                                                                     // 407
                                                                                                                       //
    if (Meteor.userId() && entry //should not be necessary                                                             // 409
    && ownsDocument(Meteor.userId(), entry)) {                                                                         // 409
        this.next();                                                                                                   // 411
    } else {                                                                                                           // 412
        this.render('accessDenied', {                                                                                  // 413
            data: "You cannot edit others' " + category.singularName                                                   // 413
        });                                                                                                            // 413
    }                                                                                                                  // 414
}, {                                                                                                                   // 415
    only: ['dataset.edit', 'app.edit']                                                                                 // 415
});                                                                                                                    // 415
Router.onBeforeAction(function () {                                                                                    // 417
    //using named function causes an error                                                                             // 417
    var _data2 = this.data(),                                                                                          // 417
        entry = _data2.entry,                                                                                          // 417
        category = _data2.category;                                                                                    // 417
                                                                                                                       //
    if (!entry) {                                                                                                      // 419
        this.render('loading');                                                                                        // 420
    } else {                                                                                                           // 421
        if (viewsDocument(Meteor.userId(), entry)) {                                                                   // 422
            this.next();                                                                                               // 423
        } else {                                                                                                       // 424
            this.render('accessDenied', {                                                                              // 425
                data: "You cannot view this " + category.singularName                                                  // 425
            });                                                                                                        // 425
        }                                                                                                              // 426
    }                                                                                                                  // 427
}, {                                                                                                                   // 428
    only: ['dataset.page', 'app.page']                                                                                 // 428
});                                                                                                                    // 428
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"api":{"resource_server":{"middlewares":{"content.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/content.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    "default": function () {                                                                                           // 1
        return accessData;                                                                                             // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
                                                                                                                       //
function accessData(req, res) {                                                                                        // 5
    var id = req.params.id,                                                                                            // 6
        _req$query = req.query,                                                                                        // 6
        query = _req$query.query,                                                                                      // 6
        collection = _req$query.collection,                                                                            // 6
        options = _req$query.options;                                                                                  // 6
                                                                                                                       //
    if (query === undefined) {                                                                                         // 9
        res.json(new Meteor.Error(400, 'Require a valid query.'));                                                     // 10
    }                                                                                                                  // 11
                                                                                                                       //
    var dist = Datasets.findOne({                                                                                      // 13
        'distribution._id': id                                                                                         // 13
    }, {                                                                                                               // 13
        fields: {                                                                                                      // 13
            distribution: {                                                                                            // 13
                $elemMatch: {                                                                                          // 13
                    _id: id                                                                                            // 13
                }                                                                                                      // 13
            }                                                                                                          // 13
        }                                                                                                              // 13
    }).distribution[0];                                                                                                // 13
                                                                                                                       //
    if (dist) {                                                                                                        // 15
        var type = dist.fileFormat;                                                                                    // 16
                                                                                                                       //
        if (['MongoDB', 'MySQL', 'SPARQL'].indexOf(type) !== -1) {                                                     // 17
            type = type.toLowerCase();                                                                                 // 18
            query = parseQuery(query, type);                                                                           // 19
            var args = [id];                                                                                           // 20
                                                                                                                       //
            if (collection) {                                                                                          // 22
                args.push(collection);                                                                                 // 23
            }                                                                                                          // 24
                                                                                                                       //
            args.push(query);                                                                                          // 26
                                                                                                                       //
            if (options) {                                                                                             // 28
                args.push(options);                                                                                    // 29
            }                                                                                                          // 30
                                                                                                                       //
            Meteor.apply(type + "Query", args, function (err, result) {                                                // 32
                res.json(err || result);                                                                               // 33
            });                                                                                                        // 34
        } else {                                                                                                       // 35
            res.json(new Meteor.Error(500, 'Distribution type not supported'));                                        // 36
        }                                                                                                              // 37
    } else {                                                                                                           // 39
        res.json(new Meteor.Error(404, 'Invalid distribution id. Record not found.'));                                 // 40
    }                                                                                                                  // 41
}                                                                                                                      // 42
                                                                                                                       //
function parseQuery(q, type) {                                                                                         // 44
    if (type === 'mongodb') {                                                                                          // 45
        return JSON.parse(q);                                                                                          // 46
    } else {                                                                                                           // 47
        return q;                                                                                                      // 48
    }                                                                                                                  // 49
}                                                                                                                      // 50
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metadata.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/metadata.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    getEntryLst: function () {                                                                                         // 1
        return getEntryLst;                                                                                            // 1
    },                                                                                                                 // 1
    getEntry: function () {                                                                                            // 1
        return getEntry;                                                                                               // 1
    },                                                                                                                 // 1
    getEntryProvenance: function () {                                                                                  // 1
        return getEntryProvenance;                                                                                     // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
var RESTCompose = void 0,                                                                                              // 1
    absPath = void 0;                                                                                                  // 1
module.watch(require("./utils"), {                                                                                     // 1
    RESTCompose: function (v) {                                                                                        // 1
        RESTCompose = v;                                                                                               // 1
    },                                                                                                                 // 1
    absPath: function (v) {                                                                                            // 1
        absPath = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
                                                                                                                       //
function toREST(url, entry) {                                                                                          // 7
    return {                                                                                                           // 8
        href: url + "/" + entry._id,                                                                                   // 9
        rel: 'item',                                                                                                   // 10
        method: 'GET',                                                                                                 // 11
        name: entry.name                                                                                               // 12
    };                                                                                                                 // 8
}                                                                                                                      // 14
                                                                                                                       //
function lstHeaders(req) {                                                                                             // 16
    var headers = {                                                                                                    // 17
        title: req.path.split('/')[1],                                                                                 // 18
        opensearch: absPath(req) + "?query={queryString}"                                                              // 19
    };                                                                                                                 // 17
    return headers;                                                                                                    // 21
}                                                                                                                      // 22
                                                                                                                       //
function lstLinks(req) {                                                                                               // 24
    var collName = req.path.split('/')[1],                                                                             // 25
        coll = Mongo.Collection.get(collName);                                                                         // 25
    var selector = {};                                                                                                 // 27
                                                                                                                       //
    try {                                                                                                              // 29
        var queryString = req.query.query || '{}';                                                                     // 30
        selector = JSON.parse(queryString);                                                                            // 31
    } catch (err) {                                                                                                    // 32
        throw new Meteor.Error(500, 'Invalid query syntax', err);                                                      // 34
    }                                                                                                                  // 35
                                                                                                                       //
    var entries = [];                                                                                                  // 37
                                                                                                                       //
    if (coll) {                                                                                                        // 39
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 40
        entries = coll.find(selector).map(toREST.bind(null, absPath(req)));                                            // 41
    }                                                                                                                  // 42
                                                                                                                       //
    return entries;                                                                                                    // 43
}                                                                                                                      // 44
                                                                                                                       //
function entryHeaders(req) {                                                                                           // 46
    var collName = req.path.split('/')[1],                                                                             // 47
        coll = Mongo.Collection.get(collName);                                                                         // 47
    var id = req.params.id;                                                                                            // 49
    var headers = {};                                                                                                  // 51
                                                                                                                       //
    if (coll && id) {                                                                                                  // 53
        var selector = {                                                                                               // 54
            _id: id                                                                                                    // 54
        };                                                                                                             // 54
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 55
        var entry = coll.findOne(selector);                                                                            // 56
        var pubProperties = ['name', 'description', 'license', 'creator', 'publisherName', 'datePublished', 'dateModified', 'keywords', 'votes', 'downbvotes', 'datasetTimeInterval', 'spatial', 'github', 'url'];
        pubProperties.forEach(function (p) {                                                                           // 59
            if (entry[p]) {                                                                                            // 60
                headers[p] = entry[p];                                                                                 // 61
            }                                                                                                          // 62
        });                                                                                                            // 63
        var distributions = entry.distribution;                                                                        // 66
                                                                                                                       //
        if (distributions) {                                                                                           // 67
            headers.distribution = distributions.map(function (d) {                                                    // 68
                delete d.file;                                                                                         // 69
                delete d.profile;                                                                                      // 70
                delete d.url;                                                                                          // 71
                return d;                                                                                              // 72
            });                                                                                                        // 73
        }                                                                                                              // 74
    }                                                                                                                  // 75
                                                                                                                       //
    return headers;                                                                                                    // 77
}                                                                                                                      // 78
                                                                                                                       //
function entryLinks(req) {                                                                                             // 80
    var collName = req.path.split('/')[1],                                                                             // 81
        coll = Mongo.Collection.get(collName);                                                                         // 81
    var id = req.params.id;                                                                                            // 83
    var thisUrl = absPath(req);                                                                                        // 84
    var links = [{                                                                                                     // 86
        href: thisUrl.substring(0, thisUrl.lastIndexOf('/')),                                                          // 87
        rel: 'collection',                                                                                             // 87
        method: 'GET'                                                                                                  // 87
    }, {                                                                                                               // 87
        href: thisUrl + "/provenance",                                                                                 // 88
        rel: "http://www.w3.org/ns/prov#has_provenance",                                                               // 88
        method: 'GET',                                                                                                 // 88
        anchor: thisUrl                                                                                                // 88
    }];                                                                                                                // 88
                                                                                                                       //
    if (coll && id) {                                                                                                  // 91
        var selector = {                                                                                               // 92
            _id: id                                                                                                    // 92
        };                                                                                                             // 92
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 93
        var entry = coll.findOne(selector);                                                                            // 94
                                                                                                                       //
        if (entry && entry.distribution) {                                                                             // 95
            var distributions = entry.distribution;                                                                    // 96
            links = links.concat(distributions.map(function (d) {                                                      // 97
                return {                                                                                               // 97
                    href: thisUrl + "/" + d._id + "?query={queryString}&collection={MongoDBCollection}&options{MongoDBQueryOptions}",
                    rel: 'distribution',                                                                               // 99
                    method: 'GET',                                                                                     // 100
                    fileFormat: d.fileFormat                                                                           // 101
                };                                                                                                     // 97
            }));                                                                                                       // 97
        }                                                                                                              // 103
    }                                                                                                                  // 104
                                                                                                                       //
    return links;                                                                                                      // 106
}                                                                                                                      // 107
                                                                                                                       //
function entryProvHeaders(req) {                                                                                       // 109
    var prov = require('./prov');                                                                                      // 110
                                                                                                                       //
    var doc = prov.document(); // prefixes                                                                             // 111
                                                                                                                       //
    var schema = doc.addNamespace('schema', 'http://schema.org/');                                                     // 114
    var foaf = doc.addNamespace('foaf', 'http://xmlns.com/foaf/0.1/');                                                 // 115
    var wo = doc.addNamespace('wo', 'http://webobvervatory.org/ns');                                                   // 116
    var wos = doc.addNamespace('wo-soton', 'https://webobservatory.soton.ac.uk/'); // retrieving the collection        // 117
                                                                                                                       //
    var collName = req.path.split('/')[1],                                                                             // 120
        coll = Mongo.Collection.get(collName);                                                                         // 120
    var id = req.params.id;                                                                                            // 122
                                                                                                                       //
    if (coll && id) {                                                                                                  // 124
        var selector = {                                                                                               // 125
            _id: id                                                                                                    // 125
        };                                                                                                             // 125
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 126
        var entry = coll.findOne(selector);                                                                            // 127
        var schemaTypes = {                                                                                            // 128
            datasets: 'Dataset',                                                                                       // 128
            apps: 'WebApplication'                                                                                     // 128
        };                                                                                                             // 128
        var entry_properties = ['prov:type', "schema:" + schemaTypes[collName]];                                       // 129
        var pubProperties = ['name', 'description', 'datePublished', 'dateModified'];                                  // 130
        pubProperties.forEach(function (p) {                                                                           // 131
            if (entry[p]) {                                                                                            // 132
                entry_properties.push.apply(entry_properties, ["schema:" + p, entry[p]]);                              // 133
            }                                                                                                          // 134
        });                                                                                                            // 135
        var entry_id = "wo-soton:" + collName + "/" + id;                                                              // 136
        doc.entity(entry_id, entry_properties);                                                                        // 137
        var agent_id = "wo-soton:accounts/" + entry['publisher'];                                                      // 139
        doc.agent(agent_id, ['prov:type', 'foaf:OnlineAccount', 'prov:label', entry['publisherName']]);                // 140
        doc.wasAttributedTo(entry_id, agent_id);                                                                       // 141
    }                                                                                                                  // 142
                                                                                                                       //
    return doc.scope.getProvJSON();                                                                                    // 144
}                                                                                                                      // 145
                                                                                                                       //
var getEntryLst = RESTCompose(lstHeaders, lstLinks),                                                                   // 148
    getEntry = RESTCompose(entryHeaders, entryLinks),                                                                  // 148
    getEntryProvenance = function (req, res) {                                                                         // 148
    try {                                                                                                              // 151
        var provenance = entryProvHeaders(req);                                                                        // 152
        res.json(provenance);                                                                                          // 153
    } catch (err) {                                                                                                    // 154
        res.json(err);                                                                                                 // 156
    }                                                                                                                  // 157
};                                                                                                                     // 158
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"prov.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/prov.js                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
/**                                                                                                                    // 1
 * JavaScript library for PROV.                                                                                        //
 *                                                                                                                     //
 * Copyright 2013 University of Southampton - All rights reserved.                                                     //
 * Licence: To be determined                                                                                           //
 */ /*jshint strict: true */(function (window, undefined) {                                                            //
    "use strict"; /* Simple classes of the PROV data model                                                             // 11
                  */ // URI                                                                                            //
                                                                                                                       //
    function URI(uri) {                                                                                                // 17
        this.uri = uri;                                                                                                // 18
    }                                                                                                                  // 19
                                                                                                                       //
    URI.prototype.getURI = function () {                                                                               // 20
        return this.uri;                                                                                               // 21
    }; // PROV Qualified Name                                                                                          // 22
                                                                                                                       //
                                                                                                                       //
    function QualifiedName(prefix, localPart, namespaceURI) {                                                          // 26
        this.prefix = prefix;                                                                                          // 27
        this.localPart = localPart;                                                                                    // 28
        this.namespaceURI = namespaceURI;                                                                              // 29
        URI.call(this, namespaceURI + localPart);                                                                      // 30
    }                                                                                                                  // 31
                                                                                                                       //
    QualifiedName.prototype = Object.create(URI.prototype);                                                            // 32
    QualifiedName.prototype.constructor = QualifiedName;                                                               // 33
                                                                                                                       //
    QualifiedName.prototype.toString = function () {                                                                   // 34
        var ret;                                                                                                       // 35
                                                                                                                       //
        if (this.prefix == "default") {                                                                                // 36
            ret = this.localPart;                                                                                      // 37
        } else {                                                                                                       // 38
            ret = this.prefix + ":" + this.localPart;                                                                  // 39
        }                                                                                                              // 40
                                                                                                                       //
        return ret;                                                                                                    // 41
    };                                                                                                                 // 42
                                                                                                                       //
    QualifiedName.prototype.equals = function (other) {                                                                // 43
        return other instanceof QualifiedName && this.namespaceURI === other.namespaceURI && this.localPart === other.localPart;
    }; // Namespace                                                                                                    // 48
                                                                                                                       //
                                                                                                                       //
    function Namespace(prefix, namespaceURI, predefined) {                                                             // 52
        var i, l;                                                                                                      // 53
        this.prefix = prefix;                                                                                          // 54
        this.namespaceURI = namespaceURI;                                                                              // 55
                                                                                                                       //
        if (predefined !== undefined) {                                                                                // 56
            for (i = 0, l = predefined.length; i < l; i++) {                                                           // 57
                this.qn(predefined[i]);                                                                                // 58
            }                                                                                                          // 59
        }                                                                                                              // 60
    }                                                                                                                  // 61
                                                                                                                       //
    Namespace.prototype.qn = function (localPart) {                                                                    // 62
        if (!this.hasOwnProperty(localPart)) {                                                                         // 63
            this[localPart] = new QualifiedName(this.prefix, localPart, this.namespaceURI);                            // 64
        }                                                                                                              // 65
                                                                                                                       //
        return this[localPart];                                                                                        // 66
    }; // Literal and data types                                                                                       // 67
                                                                                                                       //
                                                                                                                       //
    function Literal(value, datatype, langtag) {                                                                       // 70
        this.value = value;                                                                                            // 71
        this.datatype = datatype;                                                                                      // 72
        this.langtag = langtag;                                                                                        // 73
    }                                                                                                                  // 74
                                                                                                                       //
    Literal.prototype.constructor = Literal;                                                                           // 75
                                                                                                                       //
    Literal.prototype.toString = function () {                                                                         // 76
        // TODO: Support for multi-line strings (triple-quoted)                                                        // 77
        // TODO: Check for special notation for some data types in PROV-N (e.g. QName)                                 // 78
        return '"' + this.value + '"' + (this.langtag !== undefined ? '@' + this.langtag : ' %% ' + this.datatype);    // 79
    };                                                                                                                 // 81
                                                                                                                       //
    Literal.prototype.equals = function (other) {                                                                      // 82
        // TODO check whether this is correct or is too strict                                                         // 83
        return other instanceof Literal && this.value === other.value && this.datatype === other.datatype && this.langtag === other.langtag;
    }; // Validation functions                                                                                         // 88
    // TODO These validation function currently does not allow for reporting which value is offending the rules        // 91
                                                                                                                       //
                                                                                                                       //
    function requireQualifiedName(value) {                                                                             // 92
        if (!(value instanceof QualifiedName)) {                                                                       // 93
            throw new Error("Expected a prov.QualifiedName value");                                                    // 94
        }                                                                                                              // 95
    }                                                                                                                  // 96
                                                                                                                       //
    function requireDate(value) {                                                                                      // 98
        if (!(value instanceof Date)) {                                                                                // 99
            throw new Error("Expected a Date value");                                                                  // 100
        }                                                                                                              // 101
    } // PROV Record                                                                                                   // 102
                                                                                                                       //
                                                                                                                       //
    function Record() {                                                                                                // 105
        var i, l; // Parsing the optional attribute-value pairs if the last argument is a list                         // 106
                                                                                                                       //
        this.attributes = [];                                                                                          // 108
        var len = arguments.length;                                                                                    // 109
                                                                                                                       //
        if (len > 1 && arguments[len - 1] instanceof Array) {                                                          // 110
            // Requiring at least 3 arguments (record-specific first term, an array)                                   // 111
            var attrPairs = arguments[len - 1];                                                                        // 112
                                                                                                                       //
            for (i = 0, l = attrPairs.length; i < l; i += 2) {                                                         // 113
                requireQualifiedName(attrPairs[i]);                                                                    // 114
                this.setAttr(attrPairs[i], attrPairs[i + 1]);                                                          // 115
            }                                                                                                          // 116
        }                                                                                                              // 117
    }                                                                                                                  // 118
                                                                                                                       //
    Record.prototype = {                                                                                               // 119
        /* GETTERS & SETTERS */ // Identifier                                                                          // 120
        id: function (identifier) {                                                                                    // 122
            this.identifier = identifier;                                                                              // 123
            return this;                                                                                               // 124
        },                                                                                                             // 125
        getId: function () {                                                                                           // 126
            return this.identifier;                                                                                    // 127
        },                                                                                                             // 128
        setAttr: function (k, v) {                                                                                     // 129
            var i;                                                                                                     // 130
            var existing = false;                                                                                      // 131
            var values = this.getAttr(k);                                                                              // 132
                                                                                                                       //
            for (i = 0; i < values.length; i++) {                                                                      // 133
                if (v.equals(values[i])) {                                                                             // 134
                    existing = true;                                                                                   // 135
                    break;                                                                                             // 136
                }                                                                                                      // 137
            }                                                                                                          // 138
                                                                                                                       //
            if (!existing) {                                                                                           // 139
                this.attributes.push([k, v]);                                                                          // 140
            }                                                                                                          // 141
        },                                                                                                             // 142
        // Arbitrary attributes                                                                                        // 144
        getAttr: function (attr_name) {                                                                                // 145
            var i;                                                                                                     // 146
            var results = [];                                                                                          // 147
                                                                                                                       //
            for (i = 0; i < this.attributes.length; i++) {                                                             // 148
                if (attr_name.equals(this.attributes[i][0])) {                                                         // 149
                    results.push(this.attributes[i][1]);                                                               // 150
                }                                                                                                      // 151
            }                                                                                                          // 152
                                                                                                                       //
            return results;                                                                                            // 153
        }                                                                                                              // 154
    }; // Element                                                                                                      // 119
                                                                                                                       //
    function Element(identifier) {                                                                                     // 158
        Record.apply(this, arguments);                                                                                 // 159
        this.identifier = identifier;                                                                                  // 160
    }                                                                                                                  // 161
                                                                                                                       //
    Element.prototype = Object.create(Record.prototype);                                                               // 162
    Element.prototype.constructor = Element; // Entity                                                                 // 163
                                                                                                                       //
    function Entity(identifier) {                                                                                      // 166
        Element.apply(this, arguments);                                                                                // 167
    }                                                                                                                  // 168
                                                                                                                       //
    Entity.prototype = Object.create(Element.prototype);                                                               // 169
    Entity.prototype.constructor = Entity;                                                                             // 170
    Entity.prototype.provn_name = "entity";                                                                            // 171
                                                                                                                       //
    Entity.prototype.toString = function () {                                                                          // 172
        var output = [];                                                                                               // 173
        output.push(String(this.identifier));                                                                          // 174
        var attr = this.attributes.map(function (x) {                                                                  // 175
            return x.join("=");                                                                                        // 176
        }).join(", ");                                                                                                 // 177
                                                                                                                       //
        if (attr !== "") {                                                                                             // 178
            output.push("[" + attr + "]");                                                                             // 179
        }                                                                                                              // 180
                                                                                                                       //
        return Entity.prototype.provn_name + "(" + output.join(", ") + ")";                                            // 181
    }; // An activity is something that occurs over a period of time and acts upon or with entities;                   // 182
    // it may include consuming, processing, transforming, modifying, relocating, using, or generating entities.       // 185
    // activity(id, st, et, [attr1=val1, ...]) , has:                                                                  // 186
    //     id: an identifier for an activity;                                                                          // 187
    //     startTime: an optional time (st) for the start of the activity;                                             // 188
    //     endTime: an optional time (et) for the end of the activity;                                                 // 189
    //     attributes: an optional set of attribute-value pairs ((attr1, val1), ...) representing additional information about this activity.
                                                                                                                       //
                                                                                                                       //
    function Activity(identifier, startTime, endTime) {                                                                // 191
        Element.apply(this, arguments);                                                                                // 192
        this.startTime = startTime;                                                                                    // 193
        this.endTime = endTime;                                                                                        // 194
    }                                                                                                                  // 195
                                                                                                                       //
    Activity.prototype = Object.create(Element.prototype);                                                             // 196
    Activity.prototype.constructor = Activity;                                                                         // 197
    Activity.prototype.provn_name = "activity";                                                                        // 198
                                                                                                                       //
    Activity.prototype.toString = function () {                                                                        // 199
        var output = [];                                                                                               // 200
        output.push(String(this.identifier));                                                                          // 201
        output.push(this.startTime.toISOString());                                                                     // 202
        output.push(this.endTime.toISOString());                                                                       // 203
        var attr = this.attributes.map(function (x) {                                                                  // 204
            return x.join("=");                                                                                        // 205
        }).join(", ");                                                                                                 // 206
                                                                                                                       //
        if (attr !== "") {                                                                                             // 207
            output.push("[" + attr + "]");                                                                             // 208
        }                                                                                                              // 209
                                                                                                                       //
        return Activity.prototype.provn_name + "(" + output.join(", ") + ")";                                          // 210
    }; // An agent is something that bears some form of responsibility for an activity taking place, for the existence of an entity, or for another agent's activity.
    // An agent may be a particular type of entity or activity.                                                        // 214
    // agent(id, [attr1=val1, ...]), has:                                                                              // 215
    //     id: an identifier for an agent;                                                                             // 216
    //     attributes: a set of attribute-value pairs ((attr1, val1), ...) representing additional information about this agent.
                                                                                                                       //
                                                                                                                       //
    function Agent(identifier) {                                                                                       // 218
        Element.apply(this, arguments);                                                                                // 219
    }                                                                                                                  // 220
                                                                                                                       //
    Agent.prototype = Object.create(Element.prototype);                                                                // 222
    Agent.prototype.constructor = Agent;                                                                               // 223
    Agent.prototype.provn_name = "agent";                                                                              // 224
                                                                                                                       //
    Agent.prototype.toString = function () {                                                                           // 225
        var output = [];                                                                                               // 226
        output.push(String(this.identifier));                                                                          // 227
        var attr = this.attributes.map(function (x) {                                                                  // 228
            return x.join("=");                                                                                        // 229
        }).join(", ");                                                                                                 // 230
                                                                                                                       //
        if (attr !== "") {                                                                                             // 231
            output.push("[" + attr + "]");                                                                             // 232
        }                                                                                                              // 233
                                                                                                                       //
        return Agent.prototype.provn_name + "(" + output.join(", ") + ")";                                             // 234
    }; // TODO: decide on whether to support Person, Organization, SoftwareAgent                                       // 235
    // Relation                                                                                                        // 238
                                                                                                                       //
                                                                                                                       //
    function Relation() {                                                                                              // 239
        var i;                                                                                                         // 240
        var len = arguments.length;                                                                                    // 241
        this.properties = {};                                                                                          // 242
                                                                                                                       //
        if (len > 0) {                                                                                                 // 243
            // Processing relation terms                                                                               // 244
            if (arguments[len - 1] instanceof Array) {                                                                 // 245
                // Assuming this is the array of attribute-value pairs, ignore it                                      // 246
                len--;                                                                                                 // 247
            }                                                                                                          // 248
                                                                                                                       //
            var terms = this.getPROVTerms();                                                                           // 249
                                                                                                                       //
            for (i = 0; i < len; i++) {                                                                                // 250
                this[terms[i]] = arguments[i];                                                                         // 251
            }                                                                                                          // 252
        }                                                                                                              // 253
                                                                                                                       //
        Record.apply(this, arguments);                                                                                 // 254
    }                                                                                                                  // 255
                                                                                                                       //
    Relation.prototype = Object.create(Record.prototype);                                                              // 256
    Relation.prototype.constructor = Relation;                                                                         // 257
                                                                                                                       //
    Relation.prototype.toString = function () {                                                                        // 258
        var that = this;                                                                                               // 259
        var output = [];                                                                                               // 260
        var provTerms = this.getPROVTerms();                                                                           // 261
        var term0 = this[provTerms[0]]; // The first term should always available                                      // 262
                                                                                                                       //
        if (this.identifier) {                                                                                         // 263
            output.push(String(this.identifier) + "; " + term0);                                                       // 264
        } else {                                                                                                       // 265
            output.push(term0);                                                                                        // 266
        }                                                                                                              // 267
                                                                                                                       //
        var rel = provTerms.slice(1).map(function (x) {                                                                // 268
            return that[x] || "-";                                                                                     // 269
        }).join(", ");                                                                                                 // 270
        output.push(rel);                                                                                              // 271
        var attr = this.attributes.map(function (x) {                                                                  // 273
            return x.join("=");                                                                                        // 274
        }).join(", ");                                                                                                 // 275
                                                                                                                       //
        if (attr !== "") {                                                                                             // 276
            output.push("[" + attr + "]");                                                                             // 277
        }                                                                                                              // 278
                                                                                                                       //
        return this.provn_name + "(" + output.join(", ") + ")";                                                        // 279
    }; // Add a property with getter and setter to a class along with a validator function                             // 280
                                                                                                                       //
                                                                                                                       //
    function defineProp(obj, propName, validator) {                                                                    // 283
        Object.defineProperty(obj, propName, {                                                                         // 284
            get: function () {                                                                                         // 285
                if (propName in this.properties) {                                                                     // 286
                    return this.properties[propName];                                                                  // 287
                }                                                                                                      // 288
                                                                                                                       //
                return undefined;                                                                                      // 289
            },                                                                                                         // 290
            set: function (newValue) {                                                                                 // 291
                validator(newValue);                                                                                   // 292
                this.properties[propName] = newValue;                                                                  // 293
            }                                                                                                          // 294
        });                                                                                                            // 284
    } // Define a PROV relation from the arguments                                                                     // 296
                                                                                                                       //
                                                                                                                       //
    function definePROVRelationClass(cls, provn_name, from, to, extras) {                                              // 299
        var i, term;                                                                                                   // 300
        var proto = Object.create(Relation.prototype);                                                                 // 301
        proto.constructor = cls;                                                                                       // 302
        proto.provn_name = provn_name;                                                                                 // 303
        var provTerms = [from, to]; // The first two terms are always required to be QualifiedName                     // 304
                                                                                                                       //
        cls.from = from;                                                                                               // 306
        cls.to = to;                                                                                                   // 307
        cls.extras = extras !== undefined ? extras : [];                                                               // 308
        defineProp(proto, from, requireQualifiedName);                                                                 // 309
        defineProp(proto, to, requireQualifiedName);                                                                   // 310
                                                                                                                       //
        if (extras !== undefined) {                                                                                    // 311
            for (i = 0; i < extras.length; i++) {                                                                      // 312
                term = extras[i];                                                                                      // 313
                provTerms.push(term[0]);                                                                               // 314
                defineProp(proto, term[0], term[1]);                                                                   // 315
            }                                                                                                          // 316
        }                                                                                                              // 317
                                                                                                                       //
        Object.freeze(provTerms); // Prevent this array from being modified                                            // 318
                                                                                                                       //
        proto.getPROVTerms = function () {                                                                             // 319
            return provTerms; // returning the array above to avoid the same array being duplicated in every relation of the same type
        };                                                                                                             // 321
                                                                                                                       //
        cls.prototype = proto;                                                                                         // 322
        return cls;                                                                                                    // 323
    } // Generation is the completion of production of a new entity by an activity.                                    // 324
    // This entity did not exist before generation and becomes available for usage after this generation.              // 327
    // Given that a generation is the completion of production of an entity, it is instantaneous.                      // 328
    // wasGeneratedBy(id; e, a, t, attrs) , has:                                                                       // 329
    //     id: an optional identifier for a generation;                                                                // 330
    //     entity: an identifier (e) for a created entity;                                                             // 331
    //     activity: an optional identifier (a) for the activity that creates the entity;                              // 332
    //     time: an optional "generation time" (t), the time at which the entity was completely created;               // 333
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this generation.
    // While each of id, activity, time, and attributes is optional, at least one of them must be present.             // 335
                                                                                                                       //
                                                                                                                       //
    function Generation(entity, activity) {                                                                            // 336
        Relation.apply(this, arguments);                                                                               // 337
    }                                                                                                                  // 338
                                                                                                                       //
    definePROVRelationClass(Generation, "wasGeneratedBy", "entity", "activity", [["time", requireDate]]); // Usage is the beginning of utilizing an entity by an activity.
    // Before usage, the activity had not begun to utilize this entity and could not have been affected by the entity.
    // Given that a usage is the beginning of utilizing an entity, it is instantaneous.                                // 347
    // used(id; a, e, t, attrs), has:                                                                                  // 348
    //     id: an optional identifier for a usage;                                                                     // 349
    //     activity: an identifier (a) for the activity that used an entity;                                           // 350
    //     entity: an optional identifier (e) for the entity being used;                                               // 351
    //     time: an optional "usage time" (t), the time at which the entity started to be used;                        // 352
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this usage.
    // While each of id, entity, time, and attributes is optional, at least one of them must be present.               // 354
                                                                                                                       //
    function Usage(activity, entity) {                                                                                 // 355
        Relation.apply(this, arguments);                                                                               // 356
    } // TODO: entity is optional in the standard but mandatory here                                                   // 357
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Usage, "used", "activity", "entity", [["time", requireDate]]); // Communication is the exchange of some unspecified entity by two activities, one activity using some entity generated by the other.
    // A communication implies that activity a2 is dependent on another a1, by way of some unspecified entity that is generated by a1 and used by a2.
    // wasInformedBy(id; a2, a1, attrs), has:                                                                          // 367
    //     id: an optional identifier identifying the relation;                                                        // 368
    //     informed: the identifier (a2) of the informed activity;                                                     // 369
    //     informant: the identifier (a1) of the informant activity;                                                   // 370
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this communication.
                                                                                                                       //
    function Communication(informed, informant) {                                                                      // 372
        Relation.apply(this, arguments);                                                                               // 373
    }                                                                                                                  // 374
                                                                                                                       //
    definePROVRelationClass(Communication, "wasInformedBy", "informed", "informant"); // Start is when an activity is deemed to have been started by an entity, known as trigger.
    // The activity did not exist before its start.                                                                    // 380
    // Any usage, generation, or invalidation involving an activity follows the activity's start.                      // 381
    // A start may refer to a trigger entity that set off the activity, or to an activity, known as starter, that generated the trigger.
    // Given that a start is when an activity is deemed to have started, it is instantaneous.                          // 383
    // wasStartedBy(id; a2, e, a1, t, attrs), has:                                                                     // 384
    //     id: an optional identifier for the activity start;                                                          // 385
    //     activity: an identifier (a2) for the started activity;                                                      // 386
    //     trigger: an optional identifier (e) for the entity triggering the activity;                                 // 387
    //     starter: an optional identifier (a1) for the activity that generated the (possibly unspecified) entity (e);
    //     time: the optional time (t) at which the activity was started;                                              // 389
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this activity start.
    // While each of id, trigger, starter, time, and attributes is optional, at least one of them must be present.     // 391
                                                                                                                       //
    function Start(activity, trigger) {                                                                                // 392
        Relation.apply(this, arguments);                                                                               // 393
    } // TODO: triggerEntity and starterActivity are both optional as long as one of them is present                   // 394
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Start, "wasStartedBy", "activity", "trigger", [["starter", requireQualifiedName], ["time", requireDate]]); // End is when an activity is deemed to have been ended by an entity, known as trigger.
    // The activity no longer exists after its end.                                                                    // 404
    // Any usage, generation, or invalidation involving an activity precedes the activity's end.                       // 405
    // An end may refer to a trigger entity that terminated the activity, or to an activity, known as ender that generated the trigger.
    // Given that an end is when an activity is deemed to have ended, it is instantaneous.                             // 407
    // wasEndedBy(id; a2, e, a1, t, attrs), has:                                                                       // 408
    //     id: an optional identifier for the activity end;                                                            // 409
    //     activity: an identifier (a2) for the ended activity;                                                        // 410
    //     trigger: an optional identifier (e) for the entity triggering the activity ending;                          // 411
    //     ender: an optional identifier (a1) for the activity that generated the (possibly unspecified) entity (e);   // 412
    //     time: the optional time (t) at which the activity was ended;                                                // 413
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this activity end.
    // While each of id, trigger, ender, time, and attributes is optional, at least one of them must be present.       // 415
                                                                                                                       //
    function End(activity, trigger) {                                                                                  // 416
        Relation.apply(this, arguments);                                                                               // 417
    } // TODO: triggerEntity and enderActivity are both optional as long as one of them is present                     // 418
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(End, "wasEndedBy", "activity", "trigger", [["ender", requireQualifiedName], ["time", requireDate]]); // Invalidation is the start of the destruction, cessation, or expiry of an existing entity by an activity.
    // The entity is no longer available for use (or further invalidation) after invalidation.                         // 428
    // Any generation or usage of an entity precedes its invalidation.                                                 // 429
    // Given that an invalidation is the start of destruction, cessation, or expiry, it is instantaneous.              // 430
    // wasInvalidatedBy(id; e, a, t, attrs), has:                                                                      // 431
    //     id: an optional identifier for a invalidation;                                                              // 432
    //     entity: an identifier for the invalidated entity;                                                           // 433
    //     activity: an optional identifier for the activity that invalidated the entity;                              // 434
    //     time: an optional "invalidation time", the time at which the entity began to be invalidated;                // 435
    //     attributes: an optional set of attribute-value pairs representing additional information about this invalidation.
    // While each of id, activity, time, and attributes is optional, at least one of them must be present.             // 437
                                                                                                                       //
    function Invalidation(entity, activity) {                                                                          // 438
        Relation.apply(this, arguments);                                                                               // 439
    } // TODO: activity is optional in the spec but mandatory here                                                     // 440
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Invalidation, "wasInvalidatedBy", "entity", "activity", [["time", requireDate]]);          // 442
                                                                                                                       //
    function Derivation(generatedEntity, usedEntity) {                                                                 // 448
        Relation.apply(this, arguments);                                                                               // 449
    }                                                                                                                  // 450
                                                                                                                       //
    definePROVRelationClass(Derivation, "wasDerivedFrom", "generatedEntity", "usedEntity", [["activity", requireQualifiedName], ["generation", requireQualifiedName], ["usage", requireQualifiedName]]); // TODO: Revision, Quotation, PrimarySource
    // A revision is a derivation for which the resulting entity is a revised version of some original.                // 461
    // The implication here is that the resulting entity contains substantial content from the original.               // 462
    // A revision relation is a kind of derivation relation from a revised entity to a preceding entity.               // 463
    // The type of a revision relation is denoted by: prov:Revision. PROV defines no revision-specific attributes.     // 464
    // wasDerivedFrom(e1, e2, [ prov:type='prov:Revision' ])                                                           // 465
    // A quotation is the repeat of (some or all of) an entity, such as text or image, by someone who may or may not be its original author.
    // A quotation relation is a kind of derivation relation, for which an entity was derived from a preceding entity by copying, or "quoting", some or all of it.
    // The type of a quotation relation is denoted by: prov:Quotation. PROV defines no quotation-specific attributes.  // 469
    // wasDerivedFrom(e1, e2, [ prov:type='prov:Quotation' ])                                                          // 470
    // A primary source for a topic refers to something produced by some agent with direct experience and knowledge about the topic, at the time of the topic's study, without benefit from hindsight.
    // A primary source relation is a kind of a derivation relation from secondary materials to their primary sources.
    // It is recognized that the determination of primary sources can be up to interpretation, and should be done according to conventions accepted within the application's domain.
    // The type of a primary source relation is denoted by: prov:PrimarySource. PROV defines no attributes specific to primary source.
    // wasDerivedFrom(e1, e2, [ prov:type='prov:PrimarySource' ])                                                      // 476
                                                                                                                       //
    function Attribution(entity, agent) {                                                                              // 478
        Relation.apply(this, arguments);                                                                               // 479
    }                                                                                                                  // 480
                                                                                                                       //
    definePROVRelationClass(Attribution, "wasAttributedTo", "entity", "agent"); // An activity association is an assignment of responsibility to an agent for an activity, indicating that the agent had a role in the activity.
    // wasAssociatedWith(id; a, ag, pl, attrs), has:                                                                   // 486
    //     id: an optional identifier for the association between an activity and an agent;                            // 487
    //     activity: an identifier (a) for the activity;                                                               // 488
    //     agent: an optional identifier (ag) for the agent associated with the activity;                              // 489
    //     plan: an optional identifier (pl) for the plan the agent relied on in the context of this activity;         // 490
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this association of this activity with this agent.
    // While each of id, agent, plan, and attributes is optional, at least one of them must be present.                // 492
                                                                                                                       //
    function Association(activity, agent) {                                                                            // 493
        Relation.apply(this, arguments);                                                                               // 494
    }                                                                                                                  // 495
                                                                                                                       //
    definePROVRelationClass(Association, "wasAssociatedWith", "activity", "agent", [["plan", requireQualifiedName]]); // Delegation is the assignment of authority and responsibility to an agent (by itself or by another agent) to carry out a specific activity as a delegate or representative, while the agent it acts on behalf of retains some responsibility for the outcome of the delegated work.
    // actedOnBehalfOf(id; ag2, ag1, a, attrs), has:                                                                   // 503
    //     id: an optional identifier for the delegation link between delegate and responsible;                        // 504
    //     delegate: an identifier (ag2) for the agent associated with an activity, acting on behalf of the responsible agent;
    //     responsible: an identifier (ag1) for the agent, on behalf of which the delegate agent acted;                // 506
    //     activity: an optional identifier (a) of an activity for which the delegation link holds;                    // 507
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this delegation link.
                                                                                                                       //
    function Delegation(delegate, responsible) {                                                                       // 509
        Relation.apply(this, arguments);                                                                               // 510
    }                                                                                                                  // 511
                                                                                                                       //
    definePROVRelationClass(Delegation, "actedOnBehalfOf", "delegate", "responsible", [["activity", requireQualifiedName]]); // Influence is the capacity of an entity, activity, or agent to have an effect on the character, development, or behavior of another by means of usage, start, end, generation, invalidation, communication, derivation, attribution, association, or delegation.
    // An influence relation between two objects o2 and o1 is a generic dependency of o2 on o1 that signifies some form of influence of o1 on o2.
    // wasInfluencedBy(id; o2, o1, attrs), has:                                                                        // 520
    //     id: an optional identifier identifying the relation;                                                        // 521
    //     influencee: an identifier (o2) for an entity, activity, or agent;                                           // 522
    //     influencer: an identifier (o1) for an ancestor entity, activity, or agent that the former depends on;       // 523
    //     attributes: an optional set (attrs) of attribute-value pairs representing additional information about this relation.
                                                                                                                       //
    function Influence(influencee, influencer) {                                                                       // 525
        Relation.apply(this, arguments);                                                                               // 526
    }                                                                                                                  // 527
                                                                                                                       //
    definePROVRelationClass(Influence, "wasInfluencedBy", "influencee", "influencer"); // An entity that is a specialization of another shares all aspects of the latter, and additionally presents more specific aspects of the same thing as the latter.
    // In particular, the lifetime of the entity being specialized contains that of any specialization.                // 533
    // specializationOf(infra, supra), has:                                                                            // 534
    //     specificEntity: an identifier (infra) of the entity that is a specialization of the general entity (supra);
    //     generalEntity: an identifier (supra) of the entity that is being specialized.                               // 536
    // A specialization is not, as defined here, also an influence, and therefore does not have an id and attributes.  // 537
                                                                                                                       //
    function Specialization(specificEntity, generalEntity) {                                                           // 538
        Relation.apply(this, arguments);                                                                               // 539
    } // TODO: delete the identifier and the attributes                                                                // 540
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Specialization, "specializationOf", "specificEntity", "generalEntity"); // Two alternate entities present aspects of the same thing. These aspects may be the same or different, and the alternate entities may or may not overlap in time.
    // alternateOf(e1, e2), has:                                                                                       // 547
    //     alternate1: an identifier (e1) of the first of the two entities;                                            // 548
    //     alternate2: an identifier (e2) of the second of the two entities.                                           // 549
    // An alternate is not, as defined here, also an influence, and therefore does not have an id and attributes.      // 550
                                                                                                                       //
    function Alternate(alternate1, alternate2) {                                                                       // 551
        Relation.apply(this, arguments);                                                                               // 552
    } // TODO: delete the identifier and the attributes                                                                // 553
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Alternate, "alternateOf", "alternate1", "alternate2"); // TODO: Collection and EmptyCollection - do we define special classes for them?
    // A membership relation is defined for stating the members of a Collection.                                       // 561
    // Membership is the belonging of an entity to a collection.                                                       // 562
    // hadMember(c, e), has:                                                                                           // 563
    //     collection: an identifier (c) for the collection whose member is asserted;                                  // 564
    //     entity: the identifier e of an entity that is member of the collection.                                     // 565
    // Membership is not, as defined here, also an influence, and therefore does not have an id and attributes.        // 566
                                                                                                                       //
    function Membership(collection, entity) {                                                                          // 567
        Relation.apply(this, arguments);                                                                               // 568
    } // TODO: delete the identifier and the attributes                                                                // 569
                                                                                                                       //
                                                                                                                       //
    definePROVRelationClass(Membership, "hadMember", "collection", "entity"); // TODO: Documentation for Document here
                                                                                                                       //
    function Document() {                                                                                              // 576
        this.statements = []; // TODO Collect all namespaces used in various QualifiedName to define in the prefix block
        // This can also be done in when a document is exported to PROV-N or PROV-JSON                                 // 579
    }                                                                                                                  // 580
                                                                                                                       //
    Document.prototype = {                                                                                             // 581
        constructor: Document,                                                                                         // 582
        addStatement: function (statement) {                                                                           // 583
            this.statements.push(statement);                                                                           // 584
        }                                                                                                              // 585
    }; // TODO: Documentation for Bundle here                                                                          // 581
                                                                                                                       //
    function Bundle(identifier) {                                                                                      // 589
        Document.apply(this, arguments);                                                                               // 590
        this.identifier = identifier;                                                                                  // 591
    }                                                                                                                  // 592
                                                                                                                       //
    Bundle.prototype = Object.create(Document.prototype);                                                              // 593
    Bundle.prototype.constructor = Bundle; /*                                                                          // 594
                                           * Factory and Utility classes                                               //
                                           * */                                                                        //
    var provNS = new Namespace("prov", "http://www.w3.org/ns/prov#", ["Entity", "Activity", "Agent", "Collection", "EmptyCollection", "Bundle", "Person", "SoftwareAgent", "Organization", "Location", "Influence", "EntityInfluence", "Usage", "Start", "End", "Derivation", "PrimarySource", "Quotation", "Revision", "ActivityInfluence", "Generation", "Communication", "Invalidation", "AgentInfluence", "Attribution", "Association", "Plan", "Delegation", "InstantaneousEvent", "Role"]);
    var xsdNS = new Namespace("xsd", "http://www.w3.org/2000/10/XMLSchema#", ["QName", "dateTime"]); // ProvJS is the main interface class of the library
                                                                                                                       //
    function ProvJS(scope, parent) {                                                                                   // 622
        // The factory class                                                                                           // 623
        this.scope = scope !== undefined ? scope : new Document();                                                     // 624
                                                                                                                       //
        if (this.scope instanceof Document) {                                                                          // 625
            // TODO Remove this hack with proper namespace management                                                  // 626
            this.scope.namespaces = this.namespaces;                                                                   // 627
        }                                                                                                              // 628
                                                                                                                       //
        this.parent = parent;                                                                                          // 629
    }                                                                                                                  // 630
                                                                                                                       //
    function defineRelationFunction(cls) {                                                                             // 632
        var fn = function () {                                                                                         // 633
            var statement, parameters;                                                                                 // 634
            var usable_args = arguments.length;                                                                        // 635
            var pos, attributes;                                                                                       // 636
                                                                                                                       //
            if (usable_args < 2) {                                                                                     // 637
                return undefined;                                                                                      // 638
            }                                                                                                          // 639
                                                                                                                       //
            if (Array.isArray(arguments[usable_args - 1])) {                                                           // 640
                usable_args = usable_args - 1;                                                                         // 641
            }                                                                                                          // 642
                                                                                                                       //
            parameters = [this.getValidQualifiedName(arguments[0]), this.getValidQualifiedName(arguments[1])];         // 643
                                                                                                                       //
            for (pos = 0; pos < cls.extras.length && pos + 2 < usable_args; pos++) {                                   // 644
                if (cls.extras[pos][1] === requireQualifiedName) {                                                     // 645
                    parameters.push(this.getValidQualifiedName(arguments[pos + 2]));                                   // 646
                } else if (cls.extras[pos][1] === requireDate) {                                                       // 647
                    parameters.push(this.getValidDate(arguments[pos + 2]));                                            // 648
                }                                                                                                      // 649
            }                                                                                                          // 650
                                                                                                                       //
            statement = Object.create(cls.prototype);                                                                  // 651
            statement = cls.apply(statement, parameters) || statement;                                                 // 652
                                                                                                                       //
            if (Array.isArray(arguments[arguments.length - 1])) {                                                      // 653
                attributes = arguments[arguments.length - 1];                                                          // 654
                                                                                                                       //
                for (pos = 1; pos < arguments.length; pos += 2) {                                                      // 655
                    statement.setAttr(this.getValidQualifiedName(attributes[pos - 1]), this.getValidLiteral(attributes[pos]));
                }                                                                                                      // 657
            }                                                                                                          // 658
                                                                                                                       //
            this.addStatement(statement);                                                                              // 659
            var newProvJS = new ProvJS(statement, this);                                                               // 660
            return newProvJS;                                                                                          // 661
        };                                                                                                             // 662
                                                                                                                       //
        return fn;                                                                                                     // 663
    }                                                                                                                  // 664
                                                                                                                       //
    ProvJS.prototype = {                                                                                               // 666
        // All registered namespaces                                                                                   // 667
        // TODO Check if this is copied into separate instances or shared!!!                                           // 668
        namespaces: {                                                                                                  // 669
            "prov": provNS,                                                                                            // 670
            "xsd": xsdNS                                                                                               // 671
        },                                                                                                             // 669
        // TODO: The above will be replicated in all ProvJS instances. We might want to limit them in the root one only.
        // The PROV namespace                                                                                          // 676
        ns: provNS,                                                                                                    // 677
        parent: undefined,                                                                                             // 678
        constructor: ProvJS,                                                                                           // 679
        addNamespace: function (ns_or_prefix, uri) {                                                                   // 681
            var ns;                                                                                                    // 682
                                                                                                                       //
            this._documentOnly();                                                                                      // 683
                                                                                                                       //
            if (ns_or_prefix instanceof Namespace) {                                                                   // 684
                ns = ns_or_prefix;                                                                                     // 685
            } else {                                                                                                   // 686
                ns = new Namespace(ns_or_prefix, uri);                                                                 // 687
            }                                                                                                          // 688
                                                                                                                       //
            var namespaces = this.scope instanceof Record ? this.parent.namespaces : this.namespaces;                  // 689
            namespaces[ns.prefix] = ns;                                                                                // 690
            return ns;                                                                                                 // 691
        },                                                                                                             // 692
        setDefaultNamespace: function (uri) {                                                                          // 693
            this._documentOnly();                                                                                      // 694
                                                                                                                       //
            var ns = new Namespace("default", uri);                                                                    // 695
            var namespaces = this.scope instanceof Record ? this.parent.namespaces : this.namespaces;                  // 696
            namespaces[ns.prefix] = ns;                                                                                // 697
            return ns;                                                                                                 // 698
        },                                                                                                             // 699
        getValidQualifiedName: function (identifier) {                                                                 // 700
            if (identifier instanceof QualifiedName) {                                                                 // 701
                return identifier;                                                                                     // 702
            }                                                                                                          // 703
                                                                                                                       //
            var namespaces = this.scope instanceof Record ? this.parent.namespaces : this.namespaces; // If id_str has a colon (:), check if the part before the colon is a registered prefix
                                                                                                                       //
            var components = identifier.split(":", 2);                                                                 // 708
                                                                                                                       //
            if (components.length === 2) {                                                                             // 709
                var prefix = components[0];                                                                            // 710
                                                                                                                       //
                if (prefix in namespaces) {                                                                            // 711
                    return namespaces[prefix].qn(components[1]);                                                       // 712
                } /* TODO: Try to resolve the prefix with the parent's namespaces                                      // 713
                  if (this.parent) {                                                                                   //
                  }                                                                                                    //
                  */                                                                                                   //
            } else if (components.length < 2) {                                                                        // 718
                var prefix = "default";                                                                                // 719
                                                                                                                       //
                if (prefix in namespaces) {                                                                            // 720
                    return namespaces[prefix].qn(identifier);                                                          // 721
                }                                                                                                      // 722
            } // TODO If a default namespace is registered, use it                                                     // 723
            // Give up at this point                                                                                   // 727
                                                                                                                       //
                                                                                                                       //
            throw new Error("Cannot validate identifier:", identifier);                                                // 728
        },                                                                                                             // 729
        literal: function (value, datatype, langtag) {                                                                 // 730
            // Determine the data type for common types                                                                // 731
            if (datatype === undefined && langtag === undefined) {                                                     // 732
                // Missing both datatype and langtag                                                                   // 733
                if (value instanceof Date) {                                                                           // 734
                    value = value.toISOString();                                                                       // 735
                    datatype = xsdNS.qn("dateTime");                                                                   // 736
                } else {                                                                                               // 737
                    switch (typeof value === "undefined" ? "undefined" : (0, _typeof3.default)(value)) {               // 739
                        case "string":                                                                                 // 740
                        case "boolean":                                                                                // 741
                            return value;                                                                              // 742
                        // Supported native types                                                                      // 742
                                                                                                                       //
                        case "number":                                                                                 // 743
                            if (Math.floor(value) === value) {                                                         // 744
                                datatype = xsdNS.qn("int");                                                            // 745
                            } else {                                                                                   // 746
                                datatype = xsdNS.qn("float");                                                          // 747
                            }                                                                                          // 748
                                                                                                                       //
                            break;                                                                                     // 749
                    }                                                                                                  // 739
                }                                                                                                      // 751
            } else {                                                                                                   // 752
                if (datatype !== undefined) {                                                                          // 753
                    datatype = this.getValidQualifiedName(datatype);                                                   // 754
                                                                                                                       //
                    if (datatype.equals(xsdNS.QName)) {                                                                // 756
                        // Try to ensure a QualifiedName value                                                         // 757
                        value = this.getValidQualifiedName(value);                                                     // 758
                    }                                                                                                  // 759
                } // TODO Handle with langtag and undefined datatype                                                   // 761
                                                                                                                       //
            }                                                                                                          // 763
                                                                                                                       //
            var ret = new Literal(value, datatype, langtag);                                                           // 764
            return ret;                                                                                                // 765
        },                                                                                                             // 766
        getValidLiteral: function (literal) {                                                                          // 767
            if (literal instanceof Literal) {                                                                          // 768
                return literal;                                                                                        // 769
            }                                                                                                          // 770
                                                                                                                       //
            if (literal instanceof QualifiedName) {                                                                    // 771
                // A QualifiedName is considered a literal                                                             // 772
                return literal;                                                                                        // 773
            }                                                                                                          // 774
                                                                                                                       //
            var ret;                                                                                                   // 775
                                                                                                                       //
            if (Array.isArray(literal)) {                                                                              // 776
                // Accepting literal as an array of [value, datatype, lang]                                            // 777
                ret = this.literal.apply(this, literal);                                                               // 778
            } else {                                                                                                   // 779
                // Accepting literal as a simple-type value                                                            // 781
                ret = this.literal(literal);                                                                           // 782
            }                                                                                                          // 783
                                                                                                                       //
            return ret;                                                                                                // 784
        },                                                                                                             // 785
        getValidDate: function (dt) {                                                                                  // 786
            var ret;                                                                                                   // 787
                                                                                                                       //
            if (dt instanceof Date) {                                                                                  // 788
                ret = new Date(dt);                                                                                    // 789
            } else if (typeof dt === "string") {                                                                       // 790
                ret = new Date(Date.parse(dt));                                                                        // 791
            } else if (typeof dt === "number") {                                                                       // 792
                ret = new Date(dt);                                                                                    // 793
            }                                                                                                          // 794
                                                                                                                       //
            return ret;                                                                                                // 795
        },                                                                                                             // 796
        getValidAttributeList: function (attrs) {                                                                      // 797
            var pos, l;                                                                                                // 798
            var attributes;                                                                                            // 799
                                                                                                                       //
            if (Array.isArray(attrs)) {                                                                                // 800
                attributes = [];                                                                                       // 801
                                                                                                                       //
                for (pos = 0, l = attrs.length; pos < l; pos += 2) {                                                   // 802
                    attributes.push(this.getValidQualifiedName(attrs[pos]));                                           // 803
                    attributes.push(this.getValidLiteral(attrs[pos + 1]));                                             // 804
                }                                                                                                      // 805
                                                                                                                       //
                return attributes;                                                                                     // 806
            }                                                                                                          // 807
                                                                                                                       //
            throw new Error("The provided attribute list is not an array.");                                           // 808
        },                                                                                                             // 809
        // PROV statements                                                                                             // 811
        addStatement: function (statement) {                                                                           // 812
            // Add the statement to the current bundle                                                                 // 813
            var bundle = this.scope instanceof Record ? this.parent.scope : this.scope;                                // 814
            bundle.addStatement(statement);                                                                            // 815
        },                                                                                                             // 816
        document: function () {                                                                                        // 818
            // Allow prov.document()                                                                                   // 819
            if (!(this.scope instanceof Document)) {                                                                   // 820
                throw new Error("Unable to call this method here.");                                                   // 821
            }                                                                                                          // 822
                                                                                                                       //
            return new ProvJS(new Document(), this);                                                                   // 823
        },                                                                                                             // 824
        bundle: function (identifier) {                                                                                // 826
            // Allow prov.bundle() or prov.document().bundle()                                                         // 827
            this._documentOnly();                                                                                      // 828
                                                                                                                       //
            if (this.scope instanceof Bundle) {                                                                        // 829
                throw new Error("Unable to call this method on a bundle.");                                            // 830
            }                                                                                                          // 831
                                                                                                                       //
            var eID = this.getValidQualifiedName(identifier);                                                          // 832
            var newBundle = new Bundle(eID);                                                                           // 833
            var newProvJS = new ProvJS(newBundle, this);                                                               // 834
            return newProvJS;                                                                                          // 835
        },                                                                                                             // 836
        entity: function (identifier, attrs) {                                                                         // 838
            var attributes;                                                                                            // 839
                                                                                                                       //
            if (this.scope instanceof Record) {                                                                        // 840
                return this._accessProp('entity', identifier);                                                         // 841
            }                                                                                                          // 842
                                                                                                                       //
            this._documentOnly();                                                                                      // 843
                                                                                                                       //
            var eID = this.getValidQualifiedName(identifier);                                                          // 844
                                                                                                                       //
            if (attrs !== undefined) {                                                                                 // 845
                attributes = this.getValidAttributeList(attrs);                                                        // 846
            }                                                                                                          // 847
                                                                                                                       //
            var newEntity = new Entity(eID, attributes);                                                               // 848
            this.addStatement(newEntity);                                                                              // 849
            var newProvJS = new ProvJS(newEntity, this);                                                               // 850
            return newProvJS;                                                                                          // 851
        },                                                                                                             // 852
        agent: function (identifier, attrs) {                                                                          // 853
            var attributes;                                                                                            // 854
                                                                                                                       //
            if (this.scope instanceof Record) {                                                                        // 855
                return this._accessProp('agent', identifier);                                                          // 856
            }                                                                                                          // 857
                                                                                                                       //
            this._documentOnly();                                                                                      // 858
                                                                                                                       //
            var aID = this.getValidQualifiedName(identifier);                                                          // 859
                                                                                                                       //
            if (attrs !== undefined) {                                                                                 // 860
                attributes = this.getValidAttributeList(attrs);                                                        // 861
            }                                                                                                          // 862
                                                                                                                       //
            var newAgent = new Agent(aID, attributes);                                                                 // 863
            this.addStatement(newAgent);                                                                               // 864
            var newProvJS = new ProvJS(newAgent, this);                                                                // 865
            return newProvJS;                                                                                          // 866
        },                                                                                                             // 867
        activity: function (identifier, startTime, endTime, attrs) {                                                   // 868
            var attributes;                                                                                            // 869
                                                                                                                       //
            if (this.scope instanceof Record) {                                                                        // 870
                return this._accessProp('activity', identifier);                                                       // 871
            }                                                                                                          // 872
                                                                                                                       //
            this._documentOnly();                                                                                      // 873
                                                                                                                       //
            var aID = this.getValidQualifiedName(identifier); // TODO: get the start time and end time from the list of arguments
                                                                                                                       //
            if (startTime !== undefined) {                                                                             // 876
                startTime = this.getValidDate(startTime);                                                              // 877
            }                                                                                                          // 878
                                                                                                                       //
            if (endTime !== undefined) {                                                                               // 879
                endTime = this.getValidDate(endTime);                                                                  // 880
            }                                                                                                          // 881
                                                                                                                       //
            if (attrs !== undefined) {                                                                                 // 882
                attributes = this.getValidAttributeList(attrs);                                                        // 883
            }                                                                                                          // 884
                                                                                                                       //
            var newActivity = new Activity(aID, startTime, endTime, attributes);                                       // 885
            this.addStatement(newActivity);                                                                            // 886
            var newProvJS = new ProvJS(newActivity, this);                                                             // 887
            return newProvJS;                                                                                          // 888
        },                                                                                                             // 889
        wasGeneratedBy: defineRelationFunction(Generation),                                                            // 891
        used: defineRelationFunction(Usage),                                                                           // 892
        wasInformedBy: defineRelationFunction(Communication),                                                          // 893
        wasStartedBy: defineRelationFunction(Start),                                                                   // 894
        wasEndedBy: defineRelationFunction(End),                                                                       // 895
        wasInvalidatedBy: defineRelationFunction(Invalidation),                                                        // 896
        wasDerivedFrom: defineRelationFunction(Derivation),                                                            // 897
        wasAttributedTo: defineRelationFunction(Attribution),                                                          // 898
        wasAssociatedWith: defineRelationFunction(Association),                                                        // 899
        actedOnBehalfOf: defineRelationFunction(Delegation),                                                           // 900
        wasInfluencedBy: defineRelationFunction(Influence),                                                            // 901
        specializationOf: defineRelationFunction(Specialization),                                                      // 902
        alternateOf: defineRelationFunction(Alternate),                                                                // 903
        hadMember: defineRelationFunction(Membership),                                                                 // 904
        // Setting properties                                                                                          // 906
        _accessProp: function (property, newValue) {                                                                   // 907
            if (!(this.scope instanceof Record)) {                                                                     // 908
                throw new Error("Unable to access this property here.");                                               // 909
            } // Setting the entity attribute                                                                          // 910
                                                                                                                       //
                                                                                                                       //
            this._propertyGuard(property); // If the new value is not provided                                         // 912
                                                                                                                       //
                                                                                                                       //
            if (newValue === undefined) {                                                                              // 914
                // Returning the value of the property                                                                 // 915
                return this.scope[property];                                                                           // 916
            } // Setting the property                                                                                  // 917
                                                                                                                       //
                                                                                                                       //
            this.scope[property] = this.getValidQualifiedName(newValue);                                               // 919
            return this;                                                                                               // 920
        },                                                                                                             // 921
        _propertyGuard: function (property) {                                                                          // 923
            if (!(property in this.scope)) {                                                                           // 924
                throw new Error("Unable to access this property here.");                                               // 925
            }                                                                                                          // 926
        },                                                                                                             // 927
        _documentOnly: function () {                                                                                   // 929
            if (!(this.scope instanceof Document)) {                                                                   // 930
                throw new Error("This method can only be called on a Document or Bundle.");                            // 931
            }                                                                                                          // 932
        },                                                                                                             // 933
        attr: function (attr_name, attr_value) {                                                                       // 935
            var context = this.scope;                                                                                  // 936
                                                                                                                       //
            if (context === undefined) {                                                                               // 937
                return undefined;                                                                                      // 938
            }                                                                                                          // 939
                                                                                                                       //
            if (attr_value === undefined) {                                                                            // 940
                // Overloading this with getter behaviour                                                              // 941
                return context.getAttr(this.getValidQualifiedName(attr_name));                                         // 942
            }                                                                                                          // 943
                                                                                                                       //
            var name = this.getValidQualifiedName(attr_name);                                                          // 944
            var value = this.getValidLiteral(attr_value);                                                              // 945
            context.setAttr(name, value);                                                                              // 946
            return this;                                                                                               // 947
        },                                                                                                             // 948
        id: function () {                                                                                              // 949
            var context = this.scope;                                                                                  // 950
                                                                                                                       //
            if (context === undefined) {                                                                               // 951
                return undefined;                                                                                      // 952
            }                                                                                                          // 953
                                                                                                                       //
            if (arguments.length === 0) {                                                                              // 954
                return context.id();                                                                                   // 955
            }                                                                                                          // 956
                                                                                                                       //
            context.id(this.getValidQualifiedName(arguments[0]));                                                      // 957
            return this;                                                                                               // 958
        },                                                                                                             // 959
        // TODO prov:time, prov:startTime, prov:endTime                                                                // 961
        // TODO prov:label                                                                                             // 962
        // TODO prov:type                                                                                              // 963
        // TODO prov:value                                                                                             // 964
        // TODO prov:location                                                                                          // 965
        // TODO prov:role                                                                                              // 966
        toString: function () {                                                                                        // 968
            if (this.scope instanceof Record) {                                                                        // 969
                return 'ProvJS(' + this.scope + ')';                                                                   // 970
            }                                                                                                          // 971
                                                                                                                       //
            return 'ProvJS(' + this.scope.statements.join(", ") + ')';                                                 // 972
        }                                                                                                              // 973
    }; // List of all properties that expect a PROV QualifiedName                                                      // 666
                                                                                                                       //
    var allQualifiedNameProperties = ['delegate', 'responsible', 'informedActivity', 'informantActivity', 'starterActivity', 'endedActivity', 'enderActivity', 'invalidatingActivity', 'usedEntity', 'generatedEntity', 'triggerEntity', 'invalidatedEntity', 'specificEntity', 'generalEntity', 'alternate1', 'alternate2', 'collection', 'member', 'responsible']; // Adding setter functions for all the properties above
                                                                                                                       //
    function _createSetPropFunc(prop) {                                                                                // 1000
        return function (identifier) {                                                                                 // 1001
            return this._accessProp(prop, identifier);                                                                 // 1002
        };                                                                                                             // 1003
    }                                                                                                                  // 1004
                                                                                                                       //
    (function () {                                                                                                     // 1005
        var i, prop;                                                                                                   // 1006
                                                                                                                       //
        for (i = 0; i < allQualifiedNameProperties.length; i++) {                                                      // 1007
            prop = allQualifiedNameProperties[i];                                                                      // 1008
            ProvJS.prototype[prop] = _createSetPropFunc(prop);                                                         // 1009
        }                                                                                                              // 1010
    })(); /* PROV-JSON Export                                                                                          // 1011
           */                                                                                                          //
                                                                                                                       //
    URI.prototype.getProvJSON = function () {                                                                          // 1016
        return {                                                                                                       // 1017
            '$': this.getURI(),                                                                                        // 1017
            'type': 'xsd:anyURI'                                                                                       // 1017
        };                                                                                                             // 1017
    };                                                                                                                 // 1018
                                                                                                                       //
    QualifiedName.prototype.getProvJSON = function () {                                                                // 1019
        return {                                                                                                       // 1020
            '$': this.toString(),                                                                                      // 1020
            'type': 'prov:QUALIFIED_NAME'                                                                              // 1020
        };                                                                                                             // 1020
    };                                                                                                                 // 1021
                                                                                                                       //
    Literal.prototype.getProvJSON = function () {                                                                      // 1022
        var ret = {                                                                                                    // 1023
            '$': this.value                                                                                            // 1023
        };                                                                                                             // 1023
                                                                                                                       //
        if (this.datatype !== undefined) {                                                                             // 1024
            ret.type = this.datatype.toString();                                                                       // 1025
        }                                                                                                              // 1026
                                                                                                                       //
        if (this.langtag !== undefined) {                                                                              // 1027
            ret.lang = this.langtag;                                                                                   // 1028
        }                                                                                                              // 1029
                                                                                                                       //
        return ret;                                                                                                    // 1030
    };                                                                                                                 // 1031
                                                                                                                       //
    function _getProvJSON(value) {                                                                                     // 1032
        var i, l;                                                                                                      // 1033
                                                                                                                       //
        if (value && typeof value.getProvJSON === 'function') {                                                        // 1034
            return value.getProvJSON();                                                                                // 1035
        }                                                                                                              // 1036
                                                                                                                       //
        if (typeof value === 'array') {                                                                                // 1037
            var values = [];                                                                                           // 1038
                                                                                                                       //
            for (i = 0, l = value.length; i < l; i++) {                                                                // 1039
                values.push(_getProvJSON(value[i]));                                                                   // 1040
            }                                                                                                          // 1041
                                                                                                                       //
            return values;                                                                                             // 1042
        }                                                                                                              // 1043
                                                                                                                       //
        if (value instanceof Date) {                                                                                   // 1044
            return {                                                                                                   // 1045
                '$': value.toISOString(),                                                                              // 1045
                'type': 'xsd:dateTime'                                                                                 // 1045
            };                                                                                                         // 1045
        }                                                                                                              // 1046
                                                                                                                       //
        return value;                                                                                                  // 1047
    }                                                                                                                  // 1048
                                                                                                                       //
    var uniqueIDCount = 0;                                                                                             // 1050
                                                                                                                       //
    function _getUniqueID(obj) {                                                                                       // 1051
        // Generating unique identifiers for PROV-JSON export                                                          // 1052
        var ret;                                                                                                       // 1053
                                                                                                                       //
        if (obj.getId !== undefined && (ret = obj.getId()) !== undefined) {                                            // 1054
            // Return the existing identifier                                                                          // 1055
            return ret.toString();                                                                                     // 1056
        }                                                                                                              // 1057
                                                                                                                       //
        if (obj.__provjson_id === undefined) {                                                                         // 1058
            obj.__provjson_id = "_:id" + ++uniqueIDCount;                                                              // 1059
        }                                                                                                              // 1061
                                                                                                                       //
        return obj.__provjson_id;                                                                                      // 1062
    }                                                                                                                  // 1063
                                                                                                                       //
    Document.prototype.getProvJSON = function () {                                                                     // 1065
        // TODO Normalise all namespaces used in the document                                                          // 1066
        var container = {},                                                                                            // 1067
            i,                                                                                                         // 1067
            j,                                                                                                         // 1067
            k,                                                                                                         // 1067
            l,                                                                                                         // 1067
            n,                                                                                                         // 1067
            statement,                                                                                                 // 1067
            id,                                                                                                        // 1067
            provJSON,                                                                                                  // 1067
            terms,                                                                                                     // 1067
            attr_name,                                                                                                 // 1067
            attr_value,                                                                                                // 1067
            provAttrName,                                                                                              // 1067
            provAttrValue,                                                                                             // 1067
            prefix,                                                                                                    // 1067
            prefixBlock = {};                                                                                          // 1067
                                                                                                                       //
        if (this.namespaces) {                                                                                         // 1072
            for (prefix in meteorBabelHelpers.sanitizeForInObject(this.namespaces)) {                                  // 1073
                if (this.namespaces.hasOwnProperty(prefix)) {                                                          // 1074
                    prefixBlock[prefix] = this.namespaces[prefix].namespaceURI;                                        // 1075
                }                                                                                                      // 1076
            }                                                                                                          // 1077
                                                                                                                       //
            container.prefix = prefixBlock;                                                                            // 1078
        }                                                                                                              // 1079
                                                                                                                       //
        for (i = 0, l = this.statements.length; i < l; i++) {                                                          // 1080
            statement = this.statements[i];                                                                            // 1081
            id = _getUniqueID(statement);                                                                              // 1082
            provJSON = {}; // Exporting PROV-specific properties                                                       // 1083
                                                                                                                       //
            if (statement instanceof Relation) {                                                                       // 1086
                terms = statement.getPROVTerms();                                                                      // 1087
                                                                                                                       //
                for (j = 0; j < terms.length; j++) {                                                                   // 1088
                    provAttrName = terms[j];                                                                           // 1089
                    provAttrValue = statement[provAttrName];                                                           // 1090
                                                                                                                       //
                    if (provAttrValue !== undefined) {                                                                 // 1091
                        provJSON["prov:" + provAttrName] = provAttrValue instanceof Date ? provAttrValue.toISOString() : provAttrValue.toString();
                    }                                                                                                  // 1094
                }                                                                                                      // 1095
            } else if (statement instanceof Activity) {                                                                // 1096
                // Exporting startTime and endTime, if any                                                             // 1098
                if (statement.startTime) {                                                                             // 1099
                    provJSON["prov:startTime"] = statement.startTime.toISOString();                                    // 1100
                }                                                                                                      // 1101
                                                                                                                       //
                if (statement.endTime) {                                                                               // 1102
                    provJSON["prov:endTime"] = statement.endTime.toISOString();                                        // 1103
                }                                                                                                      // 1104
            } // Exporting additional attribute-value pairs, if any                                                    // 1105
                                                                                                                       //
                                                                                                                       //
            for (k = 0, n = statement.attributes.length; k < n; k++) {                                                 // 1107
                attr_name = statement.attributes[k][0];                                                                // 1108
                attr_value = statement.attributes[k][1];                                                               // 1109
                provJSON[attr_name.toString()] = _getProvJSON(attr_value);                                             // 1110
            }                                                                                                          // 1111
                                                                                                                       //
            if (container[statement.provn_name] === undefined) {                                                       // 1112
                container[statement.provn_name] = {};                                                                  // 1113
            }                                                                                                          // 1114
                                                                                                                       //
            container[statement.provn_name][id] = provJSON;                                                            // 1115
        } // TODO Exporting bundles                                                                                    // 1116
                                                                                                                       //
                                                                                                                       //
        return container;                                                                                              // 1118
    }; // This is the default ProvJS object                                                                            // 1119
                                                                                                                       //
                                                                                                                       //
    var rootProvJS = new ProvJS(); // Exposing the PROV-DM classes via the root ProvJS instance                        // 1122
                                                                                                                       //
    rootProvJS.URI = URI;                                                                                              // 1124
    rootProvJS.QualifiedName = QualifiedName;                                                                          // 1125
    rootProvJS.Literal = Literal;                                                                                      // 1126
    rootProvJS.Record = Record;                                                                                        // 1127
    rootProvJS.Element = Element;                                                                                      // 1128
    rootProvJS.Entity = Entity;                                                                                        // 1129
    rootProvJS.Activity = Activity;                                                                                    // 1130
    rootProvJS.Agent = Agent;                                                                                          // 1131
    rootProvJS.Relation = Relation;                                                                                    // 1132
    rootProvJS.Generation = Generation;                                                                                // 1133
    rootProvJS.Usage = Usage;                                                                                          // 1134
    rootProvJS.Communication = Communication;                                                                          // 1135
    rootProvJS.Start = Start;                                                                                          // 1136
    rootProvJS.End = End;                                                                                              // 1137
    rootProvJS.Invalidation = Invalidation;                                                                            // 1138
    rootProvJS.Derivation = Derivation;                                                                                // 1139
    rootProvJS.Attribution = Attribution;                                                                              // 1140
    rootProvJS.Association = Association;                                                                              // 1141
    rootProvJS.Delegation = Delegation;                                                                                // 1142
    rootProvJS.Influence = Influence;                                                                                  // 1143
    rootProvJS.Specialization = Specialization;                                                                        // 1144
    rootProvJS.Alternate = Alternate;                                                                                  // 1145
    rootProvJS.Membership = Membership;                                                                                // 1146
    rootProvJS.Document = Document;                                                                                    // 1147
    rootProvJS.Bundle = Bundle; // Registering the prov object with the environment                                    // 1148
                                                                                                                       //
    if ((typeof module === "undefined" ? "undefined" : (0, _typeof3.default)(module)) === "object" && module && (0, _typeof3.default)(module.exports) === "object") {
        // Common.JS environments (e.g. node.js, PhantomJS)                                                            // 1152
        module.exports = rootProvJS;                                                                                   // 1153
    } else {                                                                                                           // 1154
        // Asynchronous module definition (AMD)                                                                        // 1155
        if (typeof define === "function" && define.amd) {                                                              // 1156
            define("prov", [], function () {                                                                           // 1157
                return rootProvJS;                                                                                     // 1158
            });                                                                                                        // 1159
        }                                                                                                              // 1160
    }                                                                                                                  // 1161
                                                                                                                       //
    if ((typeof window === "undefined" ? "undefined" : (0, _typeof3.default)(window)) === "object" && (0, _typeof3.default)(window.document) === "object") {
        // Browser environments                                                                                        // 1164
        window.prov = rootProvJS;                                                                                      // 1165
    }                                                                                                                  // 1166
})(typeof window !== 'undefined' ? window : this);                                                                     // 1168
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"utils.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/utils.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({                                                                                                        // 1
    RESTCompose: function () {                                                                                         // 1
        return RESTCompose;                                                                                            // 1
    },                                                                                                                 // 1
    absPath: function () {                                                                                             // 1
        return absPath;                                                                                                // 1
    }                                                                                                                  // 1
});                                                                                                                    // 1
                                                                                                                       //
/**                                                                                                                    // 1
 *                                                                                                                     //
 * Created by xgfd on 08/06/2016.                                                                                      //
 */function relSelf(req) {                                                                                             //
    var href = absPath(req);                                                                                           // 7
    var method = req.method;                                                                                           // 8
    return {                                                                                                           // 10
        href: href,                                                                                                    // 11
        rel: 'self',                                                                                                   // 12
        method: method                                                                                                 // 13
    };                                                                                                                 // 10
}                                                                                                                      // 15
                                                                                                                       //
function RESTCompose(headers, links) {                                                                                 // 17
    return function (req, res) {                                                                                       // 18
        try {                                                                                                          // 19
            var apiRes = headers instanceof Function ? headers(req) : headers || {};                                   // 20
            var linksArr = links instanceof Function ? links(req) : links || [];                                       // 21
            linksArr.unshift(relSelf(req));                                                                            // 22
            apiRes.links = linksArr;                                                                                   // 23
            res.json(apiRes);                                                                                          // 24
        } catch (err) {                                                                                                // 25
            res.json(err);                                                                                             // 26
        }                                                                                                              // 27
    };                                                                                                                 // 28
}                                                                                                                      // 29
                                                                                                                       //
function absPath(req) {                                                                                                // 31
    var path = req.baseUrl + req.path;                                                                                 // 32
                                                                                                                       //
    if (path[0] === '/') {                                                                                             // 33
        path = path.substring(1);                                                                                      // 34
    }                                                                                                                  // 35
                                                                                                                       //
    return Meteor.absoluteUrl(path);                                                                                   // 36
}                                                                                                                      // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/routes.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express = void 0;                                                                                                  // 1
module.watch(require("express"), {                                                                                     // 1
  "default": function (v) {                                                                                            // 1
    express = v;                                                                                                       // 1
  }                                                                                                                    // 1
}, 0);                                                                                                                 // 1
var oidc = void 0;                                                                                                     // 1
module.watch(require("../gateway/oidc"), {                                                                             // 1
  "default": function (v) {                                                                                            // 1
    oidc = v;                                                                                                          // 1
  }                                                                                                                    // 1
}, 1);                                                                                                                 // 1
var RESTCompose = void 0;                                                                                              // 1
module.watch(require("./middlewares/utils"), {                                                                         // 1
  RESTCompose: function (v) {                                                                                          // 1
    RESTCompose = v;                                                                                                   // 1
  }                                                                                                                    // 1
}, 2);                                                                                                                 // 1
var getEntryLst = void 0,                                                                                              // 1
    getEntry = void 0,                                                                                                 // 1
    getEntryProvenance = void 0;                                                                                       // 1
module.watch(require("./middlewares/metadata"), {                                                                      // 1
  getEntryLst: function (v) {                                                                                          // 1
    getEntryLst = v;                                                                                                   // 1
  },                                                                                                                   // 1
  getEntry: function (v) {                                                                                             // 1
    getEntry = v;                                                                                                      // 1
  },                                                                                                                   // 1
  getEntryProvenance: function (v) {                                                                                   // 1
    getEntryProvenance = v;                                                                                            // 1
  }                                                                                                                    // 1
}, 3);                                                                                                                 // 1
var accessData = void 0;                                                                                               // 1
module.watch(require("./middlewares/content"), {                                                                       // 1
  "default": function (v) {                                                                                            // 1
    accessData = v;                                                                                                    // 1
  }                                                                                                                    // 1
}, 4);                                                                                                                 // 1
var router = express.Router(); /**                                                                                     // 12
                                * General API information                                                              //
                                */                                                                                     //
router.get('/', RESTCompose({                                                                                          // 17
  version: '0.1',                                                                                                      // 17
  auth: 'OAuth2.0'                                                                                                     // 17
})); /**                                                                                                               // 17
      * Datasets routes                                                                                                //
      */                                                                                                               //
router.get('/datasets', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryLst));                    // 22
router.get('/datasets/:id', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntry));                   // 24
router.get('/datasets/:id/provenance', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryProvenance));
router.get('/datasets/:_/:id', oidc.checkAndSetUser('content'), Meteor.bindEnvironment(accessData)); /**               // 28
                                                                                                      * Apps routes    //
                                                                                                      */               //
router.get('/apps', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryLst));                        // 33
router.get('/apps/:id', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntry));                       // 35
router.get('/apps/:id/provenance', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryProvenance)); /**
                                                                                                                       * User profile for OIDC
                                                                                                                       */
router.get('/userInfo', oidc.userInfo()); /**                                                                          // 42
                                           * Testing routes                                                            //
                                           */                                                                          //
router.get('/test/meta', oidc.checkAndSetUser(/meta|content/), function (req, res) {                                   // 47
  res.send("ok. " + req.user);                                                                                         // 48
});                                                                                                                    // 49
router.get('/test/content', oidc.check('content'), function (req, res) {                                               // 51
  res.send("ok. " + req.user);                                                                                         // 52
});                                                                                                                    // 53
module.exportDefault(router);                                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"gateway":{"client_routes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/client_routes.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express = void 0;                                                                                                  // 1
module.watch(require("express"), {                                                                                     // 1
    "default": function (v) {                                                                                          // 1
        express = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var oidc = void 0;                                                                                                     // 1
module.watch(require("./oidc"), {                                                                                      // 1
    "default": function (v) {                                                                                          // 1
        oidc = v;                                                                                                      // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var crypto = void 0;                                                                                                   // 1
module.watch(require("crypto"), {                                                                                      // 1
    "default": function (v) {                                                                                          // 1
        crypto = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var router = express.Router(); //Routes for testing only                                                               // 9
//Client register form                                                                                                 // 12
                                                                                                                       //
router.get('/register', oidc.use('client'), function (req, res, next) {                                                // 13
    var mkId = function () {                                                                                           // 15
        var key = crypto.createHash('md5').update(req.session.user + '-' + Math.random()).digest('hex');               // 16
        req.model.client.findOne({                                                                                     // 17
            key: key                                                                                                   // 17
        }, function (err, client) {                                                                                    // 17
            if (!err && !client) {                                                                                     // 18
                var secret = crypto.createHash('md5').update(key + req.session.user + Math.random()).digest('hex');    // 19
                req.session.register_client = {};                                                                      // 20
                req.session.register_client.key = key;                                                                 // 21
                req.session.register_client.secret = secret;                                                           // 22
                var head = '<head><title>Register Client</title></head>';                                              // 23
                var inputs = '';                                                                                       // 24
                var fields = {                                                                                         // 25
                    name: {                                                                                            // 26
                        label: 'Client Name',                                                                          // 27
                        html: '<input type="text" id="name" name="name" placeholder="Client Name"/>'                   // 28
                    },                                                                                                 // 26
                    redirect_uris: {                                                                                   // 30
                        label: 'Redirect Uri',                                                                         // 31
                        html: '<input type="text" id="redirect_uris" name="redirect_uris" placeholder="Redirect Uri"/>'
                    },                                                                                                 // 30
                    key: {                                                                                             // 34
                        label: 'Client Key',                                                                           // 35
                        html: '<span>' + key + '</span>'                                                               // 36
                    },                                                                                                 // 34
                    secret: {                                                                                          // 38
                        label: 'Client Secret',                                                                        // 39
                        html: '<span>' + secret + '</span>'                                                            // 40
                    }                                                                                                  // 38
                };                                                                                                     // 25
                                                                                                                       //
                for (var i in meteorBabelHelpers.sanitizeForInObject(fields)) {                                        // 43
                    inputs += '<div><label for="' + i + '">' + fields[i].label + '</label> ' + fields[i].html + '</div>';
                }                                                                                                      // 45
                                                                                                                       //
                var error = req.session.error ? '<div>' + req.session.error + '</div>' : '';                           // 46
                var body = '<body><h1>Register Client</h1><form method="POST">' + inputs + '<input type="submit"/></form>' + error;
                res.send('<html>' + head + body + '</html>');                                                          // 48
            } else if (!err) {                                                                                         // 49
                mkId();                                                                                                // 50
            } else {                                                                                                   // 51
                next(err);                                                                                             // 52
            }                                                                                                          // 53
        });                                                                                                            // 54
    };                                                                                                                 // 55
                                                                                                                       //
    mkId();                                                                                                            // 56
}); //process client register                                                                                          // 57
                                                                                                                       //
router.post('/register', oidc.use('client'), function (req, res, next) {                                               // 60
    delete req.session.error;                                                                                          // 61
    req.body.key = req.session.register_client.key;                                                                    // 62
    req.body.secret = req.session.register_client.secret;                                                              // 63
    req.body.user = req.session.user;                                                                                  // 64
    req.body.redirect_uris = req.body.redirect_uris.split(/[, ]+/);                                                    // 65
    req.model.client.create(req.body, function (err, client) {                                                         // 66
        if (!err && client) {                                                                                          // 67
            res.redirect('/client/' + client.id);                                                                      // 68
        } else {                                                                                                       // 69
            next(err);                                                                                                 // 70
        }                                                                                                              // 71
    });                                                                                                                // 72
});                                                                                                                    // 73
router.get('/', oidc.use('client'), function (req, res, next) {                                                        // 75
    var head = '<h1>Clients Page</h1><div><a href="/client/register"/>Register new client</a></div>';                  // 76
    req.model.client.find({                                                                                            // 77
        user: req.session.user                                                                                         // 77
    }, function (err, clients) {                                                                                       // 77
        var body = ["<ul>"];                                                                                           // 78
        clients.forEach(function (client) {                                                                            // 79
            body.push('<li><a href="/client/' + client.id + '">' + client.name + '</li>');                             // 80
        });                                                                                                            // 81
        body.push('</ul>');                                                                                            // 82
        res.send(head + body.join(''));                                                                                // 83
    });                                                                                                                // 84
});                                                                                                                    // 85
router.get('/:id', oidc.use('client'), function (req, res, next) {                                                     // 87
    req.model.client.findOne({                                                                                         // 88
        user: req.session.user,                                                                                        // 88
        id: req.params.id                                                                                              // 88
    }, function (err, client) {                                                                                        // 88
        if (err) {                                                                                                     // 89
            next(err);                                                                                                 // 90
        } else if (client) {                                                                                           // 91
            var html = '<h1>Client ' + client.name + ' Page</h1><div><a href="/client">Go back</a></div><ul><li>Key: ' + client.key + '</li><li>Secret: ' + client.secret + '</li><li>Redirect Uris: <ul>';
            client.redirect_uris.forEach(function (uri) {                                                              // 93
                html += '<li>' + uri + '</li>';                                                                        // 94
            });                                                                                                        // 95
            html += '</ul></li></ul>';                                                                                 // 96
            res.send(html);                                                                                            // 97
        } else {                                                                                                       // 98
            res.send('<h1>No Client Found!</h1><div><a href="/client">Go back</a></div>');                             // 99
        }                                                                                                              // 100
    });                                                                                                                // 101
});                                                                                                                    // 102
module.exportDefault(router);                                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"models.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/models.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 *                                                                                                                     //
 * Created by xgfd on 02/06/2016.                                                                                      //
 */var models = {                                                                                                      //
    user: {                                                                                                            // 7
        identity: 'user',                                                                                              // 8
        tableName: 'users',                                                                                            // 9
        connection: 'def',                                                                                             // 10
        schema: true,                                                                                                  // 11
        policies: 'loggedIn',                                                                                          // 12
        attributes: {                                                                                                  // 13
            username: {                                                                                                // 14
                type: 'string',                                                                                        // 15
                required: true                                                                                         // 16
            },                                                                                                         // 14
            emails: {                                                                                                  // 18
                type: 'array'                                                                                          // 19
            }                                                                                                          // 18
        }                                                                                                              // 13
    }                                                                                                                  // 7
};                                                                                                                     // 6
module.exportDefault(models);                                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oidc.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/oidc.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray2 = require("babel-runtime/helpers/toConsumableArray");                                          //
                                                                                                                       //
var _toConsumableArray3 = _interopRequireDefault(_toConsumableArray2);                                                 //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
var mongo = void 0;                                                                                                    // 1
module.watch(require("sails-mongo"), {                                                                                 // 1
    "default": function (v) {                                                                                          // 1
        mongo = v;                                                                                                     // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var OpenIDConnect = void 0;                                                                                            // 1
module.watch(require("openid-connect-wo"), {                                                                           // 1
    "default": function (v) {                                                                                          // 1
        OpenIDConnect = v;                                                                                             // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var models = void 0;                                                                                                   // 1
module.watch(require("./models"), {                                                                                    // 1
    "default": function (v) {                                                                                          // 1
        models = v;                                                                                                    // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var oidcOpts = {                                                                                                       // 10
    login_url: '/sign-in',                                                                                             // 11
    consent_url: '/oauth/decision',                                                                                    // 12
    iss: Meteor.absoluteUrl(),                                                                                         // 13
    scopes: {                                                                                                          // 14
        meta: 'Access to the metadata of your apps and datasets',                                                      // 15
        content: 'Access to  your apps and datasets'                                                                   // 16
    },                                                                                                                 // 14
    adapters: {                                                                                                        // 18
        mongo: mongo                                                                                                   // 19
    },                                                                                                                 // 18
    connections: {                                                                                                     // 21
        def: {                                                                                                         // 22
            adapter: 'mongo',                                                                                          // 23
            url: process.env.MONGO_URL || 'mongodb://127.0.0.1:3001/meteor'                                            // 24
        }                                                                                                              // 22
    },                                                                                                                 // 21
    defaults: {                                                                                                        // 27
        migrate: 'safe'                                                                                                // 28
    },                                                                                                                 // 27
    models: models                                                                                                     // 30
};                                                                                                                     // 10
var oidc = OpenIDConnect.oidc(oidcOpts);                                                                               // 33
                                                                                                                       //
oidc.userInfo = function () {                                                                                          // 35
    var self = this;                                                                                                   // 36
    return [self.check('openid', /profile|email/), self.use({                                                          // 37
        policies: {                                                                                                    // 39
            loggedIn: false                                                                                            // 39
        },                                                                                                             // 39
        models: ['access', 'user']                                                                                     // 39
    }), function (req, res) {                                                                                          // 39
        req.model.access.findOne({                                                                                     // 41
            token: req.parsedParams.access_token                                                                       // 41
        }).exec(function (err, access) {                                                                               // 41
            if (!err && access) {                                                                                      // 43
                req.model.user.findOne({                                                                               // 44
                    id: access.user                                                                                    // 44
                }, function (err, user) {                                                                              // 44
                    if (req.check.scopes.indexOf('profile') != -1) {                                                   // 45
                        user.sub = req.session.sub || req.session.user; // delete user.id;                             // 46
                                                                                                                       //
                        delete user.services;                                                                          // 48
                        res.json(user);                                                                                // 49
                    } else {                                                                                           // 50
                        //console.log(user);                                                                           // 51
                        res.json({                                                                                     // 52
                            email: user.emails && user.emails[0].address,                                              // 52
                            id: user.id                                                                                // 52
                        });                                                                                            // 52
                    }                                                                                                  // 53
                });                                                                                                    // 54
            } else {                                                                                                   // 55
                self.errorHandle(res, null, 'unauthorized_client', 'Access token is not valid.');                      // 56
            }                                                                                                          // 57
        });                                                                                                            // 58
    }];                                                                                                                // 59
};                                                                                                                     // 60
                                                                                                                       //
function hasATK(req) {                                                                                                 // 62
    var atk = req.query.access_token || req.body.access_token;                                                         // 63
    return !!atk;                                                                                                      // 64
} /**                                                                                                                  // 65
   * Return a middleware that acts differently depending on the value of a predicate                                   //
   * @param {function(req, res, next)} left - Called when the predicate evaluates to false.                            //
   * @param {function(req, res, next)} right - Called when the predicate                                               //
   * @param {function(req)} pred - A predicate function                                                                //
   * @returns {function()} - A middleware that acts as left if pred is false, or as right if pred is true;             //
   */                                                                                                                  //
                                                                                                                       //
function either(left, right) {                                                                                         // 73
    var pred = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : hasATK;                             // 73
    return function (req, res, next) {                                                                                 // 74
        if (pred(req)) {                                                                                               // 75
            right(req, res, next);                                                                                     // 76
        } else {                                                                                                       // 77
            left(req, res, next);                                                                                      // 78
        }                                                                                                              // 79
    };                                                                                                                 // 80
}                                                                                                                      // 81
                                                                                                                       //
;                                                                                                                      // 81
                                                                                                                       //
function doNothing(_, __, next) {                                                                                      // 83
    next();                                                                                                            // 84
}                                                                                                                      // 85
                                                                                                                       //
function setUser(req, res, next) {                                                                                     // 87
    var token = req.query.access_token || req.body.access_token;                                                       // 88
                                                                                                                       //
    if (token) {                                                                                                       // 90
        req.model.access.findOne({                                                                                     // 91
            token: token                                                                                               // 91
        }).exec(function (err, access) {                                                                               // 91
            if (!err && access) {                                                                                      // 93
                req.user = access.user;                                                                                // 94
                next();                                                                                                // 95
            } else {                                                                                                   // 96
                self.errorHandle(res, null, 'unauthorized_client', 'Invalid access token.');                           // 97
            }                                                                                                          // 98
        });                                                                                                            // 99
    } else {                                                                                                           // 100
        req.user = null;                                                                                               // 101
        next();                                                                                                        // 102
    }                                                                                                                  // 103
}                                                                                                                      // 104
                                                                                                                       //
oidc.checkAndSetUser = function () {                                                                                   // 106
    var self = this;                                                                                                   // 107
    var scopes = arguments;                                                                                            // 108
    return [either(doNothing, self.check.apply(self, (0, _toConsumableArray3.default)(scopes))), either(doNothing, self.use({
        policies: {                                                                                                    // 111
            loggedIn: false                                                                                            // 111
        },                                                                                                             // 111
        models: ['access']                                                                                             // 111
    })), setUser];                                                                                                     // 111
};                                                                                                                     // 114
                                                                                                                       //
module.exportDefault(Object.create(oidc));                                                                             // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"routes.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/routes.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express = void 0;                                                                                                  // 1
module.watch(require("express"), {                                                                                     // 1
    "default": function (v) {                                                                                          // 1
        express = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var oidc = void 0;                                                                                                     // 1
module.watch(require("./oidc"), {                                                                                      // 1
    "default": function (v) {                                                                                          // 1
        oidc = v;                                                                                                      // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var router = express.Router();                                                                                         // 8
router.get('/oauth/authorise', oidc.auth());                                                                           // 10
router.post('/oauth/token', oidc.token());                                                                             // 11
router.post('/oauth/decision', oidc.consent()); //user consent form                                                    // 12
                                                                                                                       //
router.get('/oauth/decision', function (req, res, next) {                                                              // 15
    var head = '<head><title>Consent</title></head>';                                                                  // 16
    var lis = [];                                                                                                      // 17
                                                                                                                       //
    for (var i in meteorBabelHelpers.sanitizeForInObject(req.session.scopes)) {                                        // 18
        lis.push('<li><b>' + i + '</b>: ' + req.session.scopes[i].explain + '</li>');                                  // 19
    }                                                                                                                  // 20
                                                                                                                       //
    var ul = '<ul>' + lis.join('') + '</ul>';                                                                          // 21
    var error = req.session.error ? '<div>' + req.session.error + '</div>' : '';                                       // 22
    var body = '<body><h1>Consent</h1><form method="POST">' + ul + '<input type="submit" name="accept" value="Accept"/><input type="submit" name="cancel" value="Cancel"/></form>' + error;
    res.send('<html>' + head + body + '</html>');                                                                      // 24
});                                                                                                                    // 25
module.exportDefault(router);                                                                                          // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"app.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/app.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express = void 0;                                                                                                  // 1
module.watch(require("express"), {                                                                                     // 1
    "default": function (v) {                                                                                          // 1
        express = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 0);                                                                                                                 // 1
var bodyParser = void 0;                                                                                               // 1
module.watch(require("body-parser"), {                                                                                 // 1
    "default": function (v) {                                                                                          // 1
        bodyParser = v;                                                                                                // 1
    }                                                                                                                  // 1
}, 1);                                                                                                                 // 1
var session = void 0;                                                                                                  // 1
module.watch(require("express-session"), {                                                                             // 1
    "default": function (v) {                                                                                          // 1
        session = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 2);                                                                                                                 // 1
var oauth_routes = void 0;                                                                                             // 1
module.watch(require("./gateway/routes"), {                                                                            // 1
    "default": function (v) {                                                                                          // 1
        oauth_routes = v;                                                                                              // 1
    }                                                                                                                  // 1
}, 3);                                                                                                                 // 1
var api_routes = void 0;                                                                                               // 1
module.watch(require("./resource_server/routes"), {                                                                    // 1
    "default": function (v) {                                                                                          // 1
        api_routes = v;                                                                                                // 1
    }                                                                                                                  // 1
}, 4);                                                                                                                 // 1
var client_routes = void 0;                                                                                            // 1
module.watch(require("./gateway/client_routes"), {                                                                     // 1
    "default": function (v) {                                                                                          // 1
        client_routes = v;                                                                                             // 1
    }                                                                                                                  // 1
}, 5);                                                                                                                 // 1
var Cookies = void 0;                                                                                                  // 1
module.watch(require("cookies"), {                                                                                     // 1
    "default": function (v) {                                                                                          // 1
        Cookies = v;                                                                                                   // 1
    }                                                                                                                  // 1
}, 6);                                                                                                                 // 1
var app = express();                                                                                                   // 13
WebApp.connectHandlers.use(Meteor.bindEnvironment(app));                                                               // 14
app.use(session({                                                                                                      // 16
    secret: 'webobservatory',                                                                                          // 16
    resave: false,                                                                                                     // 16
    saveUninitialized: false                                                                                           // 16
}));                                                                                                                   // 16
app.use(Meteor.bindEnvironment(function (req, res, next) {                                                             // 17
    //Check the values in the cookies                                                                                  // 18
    var cookies = new Cookies(req),                                                                                    // 19
        userId = cookies.get("meteor_user_id") || "",                                                                  // 19
        token = cookies.get("meteor_token") || ""; //Check a valid user with this token exists                         // 19
                                                                                                                       //
    var user = Meteor.users.findOne({                                                                                  // 24
        _id: userId,                                                                                                   // 25
        'services.resume.loginTokens.hashedToken': Accounts._hashLoginToken(token)                                     // 26
    });                                                                                                                // 24
    req.session.user = user && user._id;                                                                               // 28
    next();                                                                                                            // 29
}));                                                                                                                   // 30
app.use(bodyParser.json());                                                                                            // 31
app.use(bodyParser.urlencoded({                                                                                        // 32
    extended: true                                                                                                     // 32
})); //setting up routes                                                                                               // 32
                                                                                                                       //
app.use('/', oauth_routes);                                                                                            // 35
app.use('/api', api_routes); // client routes are for testing only                                                     // 36
// app.use('/client', client_routes);                                                                                  // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cronjobs":{"connectionTest.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/cronjobs/connectionTest.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 21/10/2016.                                                                                      //
 */checkCon = function () {                                                                                            //
    var apps = Apps.find().fetch(),                                                                                    // 6
        datasets = Datasets.find().fetch();                                                                            // 6
    var dists = datasets.map(function (ds) {                                                                           // 9
        return ds.distribution;                                                                                        // 9
    });                                                                                                                // 9
    dists = _.flatten(dists);                                                                                          // 10
    apps.forEach(function (app) {                                                                                      // 12
        return appConnTest(app._id);                                                                                   // 12
    });                                                                                                                // 12
    dists.forEach(function (dist) {                                                                                    // 13
        return dbConnTest(dist._id, dist.fileFormat);                                                                  // 13
    });                                                                                                                // 13
};                                                                                                                     // 14
                                                                                                                       //
function dbConnTest(id, format) {                                                                                      // 16
    var supported = ['MongoDB', 'MySQL', 'AMQP', 'SPARQL', 'HTML'];                                                    // 17
                                                                                                                       //
    if (_.contains(supported, format)) {                                                                               // 18
        var method = format.toLowerCase() + 'Connect';                                                                 // 19
        Meteor.call(method, id);                                                                                       // 20
    }                                                                                                                  // 21
}                                                                                                                      // 22
                                                                                                                       //
function appConnTest(id) {                                                                                             // 24
    Meteor.call('appConnect', id);                                                                                     // 25
}                                                                                                                      // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"get_remote_colls.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/cronjobs/get_remote_colls.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 10/05/2016.                                                                                      //
 */function normaliseUrl(url) {                                                                                        //
    //prepend http:// if abscent                                                                                       // 6
    if (url.indexOf('http') !== 0) {                                                                                   // 7
        url = 'http://' + url;                                                                                         // 8
    } //append / if abscent                                                                                            // 9
                                                                                                                       //
                                                                                                                       //
    if (url[url.length - 1] !== '/') {                                                                                 // 12
        url += '/';                                                                                                    // 13
    }                                                                                                                  // 14
                                                                                                                       //
    return url;                                                                                                        // 15
}                                                                                                                      // 16
                                                                                                                       //
function origin(url, name, doc) {                                                                                      // 18
    return "" + url + name + "/" + doc._id;                                                                            // 19
}                                                                                                                      // 20
                                                                                                                       //
function linkToRemote(url, name, local) {                                                                              // 22
    var remote = DDP.connect(url),                                                                                     // 23
        col = new Mongo.Collection(name, {                                                                             // 23
        connection: remote                                                                                             // 24
    });                                                                                                                // 24
    col.find().observe({                                                                                               // 26
        added: function (doc) {                                                                                        // 27
            doc.origin = origin(url, name, doc); //TODO rewrite id refs using url as prefix                            // 28
                                                                                                                       //
            delete doc._id;                                                                                            // 30
            delete doc.isBasedOnUrl;                                                                                   // 31
            delete doc.comments;                                                                                       // 32
            local.insert(doc);                                                                                         // 33
        },                                                                                                             // 34
        removed: function (doc) {                                                                                      // 35
            var origin = origin(url, name, doc);                                                                       // 36
            local.remove({                                                                                             // 37
                origin: origin                                                                                         // 37
            });                                                                                                        // 37
        },                                                                                                             // 38
        changed: function (doc, oldDoc) {                                                                              // 39
            var origin = origin(url, name, oldDoc);                                                                    // 40
            local.remove({                                                                                             // 41
                origin: origin                                                                                         // 41
            });                                                                                                        // 41
            doc.origin = origin(url, name, doc);                                                                       // 43
            delete doc._id;                                                                                            // 44
            delete doc.isBasedOnUrl;                                                                                   // 45
            local.insert(doc);                                                                                         // 46
        }                                                                                                              // 47
    });                                                                                                                // 26
    return col;                                                                                                        // 49
}                                                                                                                      // 50
                                                                                                                       //
function regRemoteColls(remote_name, urls, local) {                                                                    // 52
    return urls.reduce(function (map, url) {                                                                           // 53
        url = normaliseUrl(url);                                                                                       // 54
                                                                                                                       //
        if (!map[url]) {                                                                                               // 55
            map[url] = linkToRemote(url, remote_name, local);                                                          // 56
        }                                                                                                              // 57
                                                                                                                       //
        return map;                                                                                                    // 58
    }, {});                                                                                                            // 59
}                                                                                                                      // 60
                                                                                                                       //
function updateSub(remoteColls) {                                                                                      // 62
    if (remoteColls) {                                                                                                 // 63
        Object.keys(remoteColls).map(function (url) {                                                                  // 64
            return remoteColls[normaliseUrl(url)];                                                                     // 65
        }).forEach(function (col) {                                                                                    // 65
            if (col) {                                                                                                 // 67
                var name = col._name,                                                                                  // 68
                    remote = col._connection;                                                                          // 68
                remote.subscribe(name);                                                                                // 70
            }                                                                                                          // 71
        });                                                                                                            // 72
    }                                                                                                                  // 73
}                                                                                                                      // 74
                                                                                                                       //
var woUrls = orion.config.get('wo_urls');                                                                              // 76
var remoteColls = {};                                                                                                  // 77
                                                                                                                       //
if (woUrls) {                                                                                                          // 79
    RemoteApps.remove({});                                                                                             // 80
    RemoteDatasets.remove({});                                                                                         // 81
    remoteColls[RemoteDatasets.pluralName] = regRemoteColls('datasets', woUrls, RemoteDatasets);                       // 83
    remoteColls[RemoteApps.pluralName] = regRemoteColls('apps', woUrls, RemoteApps);                                   // 84
}                                                                                                                      // 85
                                                                                                                       //
pullRemoteColls = function () {                                                                                        // 87
    [RemoteApps, RemoteDatasets].map(function (coll) {                                                                 // 88
        return remoteColls[coll.pluralName];                                                                           // 89
    }).forEach(updateSub);                                                                                             // 89
};                                                                                                                     // 91
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"accounts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/accounts.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */ //Accounts.onCreateUser(function (options, user) {                                                                 //
//    let profile = options.profile;                                                                                   // 5
//    if (profile) {                                                                                                   // 6
//        if (profile.isgroup) {                                                                                       // 7
//            delete profile.isgroup;                                                                                  // 8
//            user.isGroup = Groups.insert({publisher: user._id, name: profile.name});                                 // 9
//            Roles.removeUserFromRoles( user._id, ["individual"] );                                                   // 10
//            Roles.addUserToRoles( user._id ,  ["group"] );                                                           // 11
//        }                                                                                                            // 12
//        user.profile = options.profile;                                                                              // 13
//    }                                                                                                                // 14
//    return user;                                                                                                     // 15
//});                                                                                                                  // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/comments.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 13/01/2016.                                                                                      //
 */Meteor.methods({                                                                                                    //
    commentInsert: function (commentAttributes, category) {                                                            // 6
        check(this.userId, String);                                                                                    // 7
        check(category, Mongo.Collection);                                                                             // 8
        check(category.singularName, Match.OneOf('dataset', 'app'));                                                   // 9
        check(commentAttributes, {                                                                                     // 10
            entryId: String,                                                                                           // 11
            body: String                                                                                               // 12
        });                                                                                                            // 10
        entry = category.findOne(commentAttributes.entryId);                                                           // 15
        if (!entry) throw new Meteor.Error('invalid-comment', 'You must comment on ' + category);                      // 17
        comment = _.extend(commentAttributes, {                                                                        // 20
            publisher: this.userId,                                                                                    // 21
            category: category.singularName,                                                                           // 22
            //author: user.username,                                                                                   // 23
            submitted: new Date()                                                                                      // 24
        }); // update the post with the number of comments                                                             // 20
                                                                                                                       //
        category.update(comment.entryId, {                                                                             // 28
            $inc: {                                                                                                    // 28
                commentsCount: 1                                                                                       // 28
            }                                                                                                          // 28
        }); // create the comment, save the id                                                                         // 28
                                                                                                                       //
        comment._id = Comments.insert(comment); // now create a notification, informing the user that there's been a comment
                                                                                                                       //
        createCommentNotification(comment, category);                                                                  // 34
        return comment._id;                                                                                            // 36
    }                                                                                                                  // 37
});                                                                                                                    // 5
                                                                                                                       //
function createCommentNotification(comment, category) {                                                                // 40
    check(comment, Object);                                                                                            // 41
    check(category, Mongo.Collection);                                                                                 // 42
    check(category.singularName, Match.OneOf('dataset', 'app'));                                                       // 43
    var entryId = comment.entryId,                                                                                     // 45
        entry = category.findOne(entryId),                                                                             // 45
        initiatorId = comment.publisher;                                                                               // 45
    var path = Router.routes[category.singularName + '.page'].path({                                                   // 49
        _id: entryId                                                                                                   // 49
    });                                                                                                                // 49
    var message = '<a href="' + path + '"> <strong>' + Meteor.users.findOne(initiatorId).username + '</strong> commented on your post </a>';
                                                                                                                       //
    if (initiatorId !== entry.publisher) {                                                                             // 52
        createNotification(initiatorId, entryId, entry.name, entry.publisher, category.singularName, message);         // 53
    }                                                                                                                  // 54
}                                                                                                                      // 55
                                                                                                                       //
;                                                                                                                      // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/creative_work.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 26/12/2015.                                                                                      //
 */Meteor.methods({                                                                                                    //
    //datasetInsert: function (datasetAttributes) {                                                                    // 6
    //    check(this.userId, String);                                                                                  // 7
    //    check(datasetAttributes, {                                                                                   // 8
    //        name: String,                                                                                            // 9
    //        //url: String                                                                                            // 10
    //    });                                                                                                          // 11
    //                                                                                                                 // 12
    //    let errors = validateDataset(datasetAttributes);                                                             // 13
    //    if (errors.name || errors.distribution)                                                                      // 14
    //        throw new Meteor.Error('invalid-dataset', "You must set a name and distribution for your dataset");      // 15
    //                                                                                                                 // 16
    //    //let datasetWithSameLink = Datasets.findOne({"distribution.url": datasetAttributes.distribution.url});      // 17
    //    //if (datasetWithSameLink) {                                                                                 // 18
    //    //    return {                                                                                               // 19
    //    //        postExists: true,                                                                                  // 20
    //    //        _id: datasetWithSameLink._id                                                                       // 21
    //    //    }                                                                                                      // 22
    //    //}                                                                                                          // 23
    //                                                                                                                 // 24
    //    let user = Meteor.user();                                                                                    // 25
    //    let dataset = _.extend(datasetAttributes, {                                                                  // 26
    //        publisher: user._id,                                                                                     // 27
    //        commentsCount: 0,                                                                                        // 28
    //        upvoters: [],                                                                                            // 29
    //        votes: 0                                                                                                 // 30
    //    });                                                                                                          // 31
    //                                                                                                                 // 32
    //    let datasetId = Datasets.insert(dataset);                                                                    // 33
    //                                                                                                                 // 34
    //    return {                                                                                                     // 35
    //        _id: datasetId                                                                                           // 36
    //    };                                                                                                           // 37
    //},                                                                                                               // 38
    upvote: function (entryId, category) {                                                                             // 40
        check(this.userId, String);                                                                                    // 41
        check(entryId, String);                                                                                        // 42
        check(category, Mongo.Collection);                                                                             // 43
        check(category.singularName, Match.OneOf('dataset', 'app'));                                                   // 44
        var affected = category.update({                                                                               // 46
            _id: entryId,                                                                                              // 47
            upvoters: {                                                                                                // 48
                $ne: this.userId                                                                                       // 48
            }                                                                                                          // 48
        }, {                                                                                                           // 46
            $addToSet: {                                                                                               // 50
                upvoters: this.userId                                                                                  // 50
            },                                                                                                         // 50
            $inc: {                                                                                                    // 51
                votes: 1                                                                                               // 51
            }                                                                                                          // 51
        });                                                                                                            // 49
        if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                     // 54
    },                                                                                                                 // 56
    downvote: function (entryId, category) {                                                                           // 57
        check(this.userId, String);                                                                                    // 58
        check(entryId, String);                                                                                        // 59
        check(category, Mongo.Collection);                                                                             // 60
        check(category.singularName, Match.OneOf('dataset', 'app'));                                                   // 61
        var affected = category.update({                                                                               // 63
            _id: entryId,                                                                                              // 64
            downvoters: {                                                                                              // 65
                $ne: this.userId                                                                                       // 65
            }                                                                                                          // 65
        }, {                                                                                                           // 63
            $addToSet: {                                                                                               // 67
                downvoters: this.userId                                                                                // 67
            },                                                                                                         // 67
            $inc: {                                                                                                    // 68
                downvotes: 1                                                                                           // 68
            }                                                                                                          // 68
        });                                                                                                            // 66
        if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                     // 71
    }                                                                                                                  // 73
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"distributions.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/distributions.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof2 = require("babel-runtime/helpers/typeof");                                                                //
                                                                                                                       //
var _typeof3 = _interopRequireDefault(_typeof2);                                                                       //
                                                                                                                       //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }                      //
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 02/01/2016.                                                                                      //
 */var connPool = {};                                                                                                  //
                                                                                                                       //
function idToURL(distId) {                                                                                             // 7
    var url = void 0,                                                                                                  // 8
        username = void 0,                                                                                             // 8
        pass = void 0;                                                                                                 // 8
    var dist = Datasets.findOne({                                                                                      // 10
        'distribution._id': distId                                                                                     // 10
    }, {                                                                                                               // 10
        fields: {                                                                                                      // 10
            distribution: {                                                                                            // 10
                $elemMatch: {                                                                                          // 10
                    _id: distId                                                                                        // 10
                }                                                                                                      // 10
            }                                                                                                          // 10
        }                                                                                                              // 10
    }).distribution[0];                                                                                                // 10
                                                                                                                       //
    if (dist) {                                                                                                        // 12
        url = dist.url;                                                                                                // 13
                                                                                                                       //
        if (dist.profile) {                                                                                            // 14
            var _dist$profile = dist.profile;                                                                          // 14
            username = _dist$profile.username;                                                                         // 15
            pass = _dist$profile.pass;                                                                                 // 15
        }                                                                                                              // 16
    } else {                                                                                                           // 17
        console.log(new Meteor.Error('not-found', "Distribution " + distId + " not found"));                           // 18
    }                                                                                                                  // 19
                                                                                                                       //
    return {                                                                                                           // 21
        url: url,                                                                                                      // 21
        username: username,                                                                                            // 21
        pass: pass                                                                                                     // 21
    };                                                                                                                 // 21
}                                                                                                                      // 22
                                                                                                                       //
function connectorSyncWrap(connect) {                                                                                  // 24
    return function (id) {                                                                                             // 25
        var _idToURL = idToURL(id);                                                                                    // 25
                                                                                                                       //
        url = _idToURL.url;                                                                                            // 27
        username = _idToURL.username;                                                                                  // 27
        pass = _idToURL.pass;                                                                                          // 27
                                                                                                                       //
        var _Async$runSync = Async.runSync(function (done) {                                                           // 25
            connect(url, username, pass, done);                                                                        // 30
        }),                                                                                                            // 31
            error = _Async$runSync.error,                                                                              // 25
            result = _Async$runSync.result;                                                                            // 25
                                                                                                                       //
        if (error) {                                                                                                   // 33
            Datasets.update({                                                                                          // 34
                "distribution._id": id                                                                                 // 34
            }, {                                                                                                       // 34
                $set: {                                                                                                // 34
                    'distribution.$.online': false                                                                     // 34
                }                                                                                                      // 34
            });                                                                                                        // 34
            console.log(new Meteor.Error('connection-failed', "Distribution " + id + ": " + error.message));           // 35
        } else {                                                                                                       // 36
            Datasets.update({                                                                                          // 37
                "distribution._id": id                                                                                 // 37
            }, {                                                                                                       // 37
                $set: {                                                                                                // 37
                    'distribution.$.online': true                                                                      // 37
                }                                                                                                      // 37
            }); //add connection to pool                                                                               // 37
                                                                                                                       //
            connPool[id] = result; //remove connection after a while                                                   // 39
                                                                                                                       //
            Meteor.setTimeout(function () {                                                                            // 41
                // console.log('close', id);                                                                           // 42
                var conn = connPool[id];                                                                               // 43
                                                                                                                       //
                if (conn) {                                                                                            // 45
                    if (conn.close) {                                                                                  // 46
                        conn.close();                                                                                  // 47
                    }                                                                                                  // 48
                                                                                                                       //
                    if (conn.disconnect) {                                                                             // 50
                        conn.disconnect();                                                                             // 51
                    }                                                                                                  // 52
                                                                                                                       //
                    delete connPool[id];                                                                               // 54
                }                                                                                                      // 55
            }, 30000);                                                                                                 // 56
            return true;                                                                                               // 57
        }                                                                                                              // 58
    };                                                                                                                 // 59
} /*                                                                                                                   // 60
   * @connector(distId) create an db connection and save it to dbPool                                                  //
   * @queryExec(db, done, ...args) query execution function. result is passed to done(error, result)                   //
   * */                                                                                                                //
                                                                                                                       //
function queryExecFactory(connector, queryExec) {                                                                      // 66
    return function (distId) {                                                                                         // 67
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {      // 67
            args[_key - 1] = arguments[_key];                                                                          // 67
        }                                                                                                              // 67
                                                                                                                       //
        var conn = connPool[distId];                                                                                   // 68
                                                                                                                       //
        try {                                                                                                          // 70
            connector(distId);                                                                                         // 71
            conn = connPool[distId];                                                                                   // 72
                                                                                                                       //
            var _Async$runSync2 = Async.runSync(function (done) {                                                      // 70
                queryExec.apply(undefined, [conn, done].concat(args));                                                 // 75
            }),                                                                                                        // 76
                error = _Async$runSync2.error,                                                                         // 70
                result = _Async$runSync2.result;                                                                       // 70
                                                                                                                       //
            if (error) {                                                                                               // 78
                throw new Meteor.Error(error.name, error.message);                                                     // 79
            } else {                                                                                                   // 80
                Datasets.update({                                                                                      // 81
                    "distribution._id": distId                                                                         // 81
                }, {                                                                                                   // 81
                    $set: {                                                                                            // 81
                        'distribution.$.online': true                                                                  // 81
                    }                                                                                                  // 81
                });                                                                                                    // 81
                return result;                                                                                         // 82
            }                                                                                                          // 83
        } catch (e) {                                                                                                  // 84
            Datasets.update({                                                                                          // 86
                "distribution._id": distId                                                                             // 86
            }, {                                                                                                       // 86
                $set: {                                                                                                // 86
                    'distribution.$.online': false                                                                     // 86
                }                                                                                                      // 86
            });                                                                                                        // 86
            throw e;                                                                                                   // 87
        }                                                                                                              // 88
    };                                                                                                                 // 90
} /*                                                                                                                   // 91
   * check whether credentials are included in the url                                                                 //
   */                                                                                                                  //
                                                                                                                       //
function hasCredential(url) {                                                                                          // 96
    var match = url.match(/(.*?:\/\/)?(.*:.*@).*/);                                                                    // 97
    return match && match[2];                                                                                          // 98
} /*MongoDB*/                                                                                                          // 99
                                                                                                                       //
var mongoclient = Npm.require("mongodb").MongoClient; /*                                                               // 102
                                                       call with one parameter @distId or three parameters @url @username @pass
                                                       */                                                              //
                                                                                                                       //
var mongodbConnect = connectorSyncWrap(function (url, username, pass, done) {                                          // 107
    if (!hasCredential(url) && username) {                                                                             // 108
        url = "mongodb://" + username + ":" + pass + "@" + url.slice('mongodb://'.length);                             // 109
    }                                                                                                                  // 110
                                                                                                                       //
    mongoclient.connect(url, done);                                                                                    // 111
});                                                                                                                    // 112
var mongodbQuery = queryExecFactory(mongodbConnect, function (conn, done, collection) {                                // 114
    var selector = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};                             // 114
    var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {                                // 114
        limit: 1000                                                                                                    // 114
    };                                                                                                                 // 114
    conn.collection(collection, function (error, col) {                                                                // 115
        if (error) {                                                                                                   // 116
            throw new Meteor.Error(error.name, error.message);                                                         // 117
        }                                                                                                              // 118
                                                                                                                       //
        var query = col.find(selector);                                                                                // 119
                                                                                                                       //
        for (var key in meteorBabelHelpers.sanitizeForInObject(options)) {                                             // 121
            if (options.hasOwnProperty(key)) {                                                                         // 122
                query = query[key](options[key]);                                                                      // 123
            }                                                                                                          // 124
        }                                                                                                              // 125
                                                                                                                       //
        query.toArray(done);                                                                                           // 126
    });                                                                                                                // 127
}); /* MySQL */                                                                                                        // 128
                                                                                                                       //
var mysql = Npm.require('mysql');                                                                                      // 131
                                                                                                                       //
function parseMySQL(url) {                                                                                             // 133
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://                                                      // 134
                                                                                                                       //
    var pathSepIndx = url.indexOf('/');                                                                                // 135
    var host = void 0,                                                                                                 // 136
        database = void 0;                                                                                             // 136
                                                                                                                       //
    if (pathSepIndx !== -1) {                                                                                          // 137
        host = url.substring(0, pathSepIndx), database = url.substring(pathSepIndx + 1);                               // 138
    } else {                                                                                                           // 140
        host = url;                                                                                                    // 141
    }                                                                                                                  // 142
                                                                                                                       //
    return {                                                                                                           // 144
        host: host,                                                                                                    // 144
        database: database                                                                                             // 144
    };                                                                                                                 // 144
}                                                                                                                      // 145
                                                                                                                       //
var mysqlConnect = connectorSyncWrap(function (url, username, pass, done) {                                            // 147
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://                                                      // 148
                                                                                                                       //
    var _parseMySQL = parseMySQL(url),                                                                                 // 147
        host = _parseMySQL.host,                                                                                       // 147
        database = _parseMySQL.database;                                                                               // 147
                                                                                                                       //
    var options = {                                                                                                    // 151
        connectionLimit: 20,                                                                                           // 152
        host: host,                                                                                                    // 153
        database: database                                                                                             // 154
    };                                                                                                                 // 151
                                                                                                                       //
    if (username) {                                                                                                    // 157
        options.user = username;                                                                                       // 158
    }                                                                                                                  // 159
                                                                                                                       //
    if (pass) {                                                                                                        // 161
        options.password = pass;                                                                                       // 162
    }                                                                                                                  // 163
                                                                                                                       //
    var pool = mysql.createPool(options);                                                                              // 165
    done(null, pool);                                                                                                  // 167
});                                                                                                                    // 168
var mysqlQuery = queryExecFactory(mysqlConnect, function (conn, done, query) {                                         // 170
    conn.query(query, done); // db.query returns a third argument @fields which is discarded                           // 171
}); // SPARQL                                                                                                          // 172
                                                                                                                       //
var sparqlConnect = connectorSyncWrap(function (url, _, __, done) {                                                    // 176
    HTTP.get(url, {}, function (error, _) {                                                                            // 177
        done(error, url);                                                                                              // 178
    });                                                                                                                // 179
});                                                                                                                    // 180
var sparqlQuery = queryExecFactory(sparqlConnect, function (url, done, query) {                                        // 182
    HTTP.get(url, {                                                                                                    // 183
        params: {                                                                                                      // 184
            query: query                                                                                               // 184
        },                                                                                                             // 184
        timeout: 30000,                                                                                                // 185
        headers: {                                                                                                     // 186
            'Content-Type': 'application/x-www-form-urlencoded',                                                       // 187
            'Accept': 'application/sparql-results+json'                                                                // 188
        }                                                                                                              // 186
    }, function (error, result) {                                                                                      // 183
        if ((typeof result === "undefined" ? "undefined" : (0, _typeof3.default)(result)) === 'object' && result.content) {
            result = result.content;                                                                                   // 193
        }                                                                                                              // 194
                                                                                                                       //
        done(error, result);                                                                                           // 195
    });                                                                                                                // 196
}); /*RabbitMQ*/                                                                                                       // 197
                                                                                                                       //
var amqp = Npm.require('amqplib/callback_api');                                                                        // 200
                                                                                                                       //
var amqpConnect = connectorSyncWrap(function (url, username, pass, done) {                                             // 201
    var parts = url.match(/(amqps?:\/\/)?([^\?]*)\??(\S*)/),                                                           // 202
        query = parts[3],                                                                                              // 202
        params = query.split(/[=,&]/),                                                                                 // 202
        exchanges = params[params.indexOf('exchange') + 1].split(','); //value of query exchange can be a comma separate list
                                                                                                                       //
    if (username) {                                                                                                    // 207
        url = parts[1] + (username + ":" + pass + "@") + parts[2] + (query ? "?" + query : '');                        // 208
    }                                                                                                                  // 209
                                                                                                                       //
    amqp.connect(url, function (error, conn) {                                                                         // 211
        if (conn) {                                                                                                    // 212
            conn.exchanges = exchanges;                                                                                // 213
        }                                                                                                              // 214
                                                                                                                       //
        done(error, conn);                                                                                             // 215
    });                                                                                                                // 216
});                                                                                                                    // 217
var amqpQuery = queryExecFactory(amqpConnect, function (conn, done, ex, sId) {                                         // 219
    var exchanges = conn.exchanges;                                                                                    // 220
                                                                                                                       //
    if (_.contains(exchanges, ex)) {                                                                                   // 221
        conn.createChannel(function (err, ch) {                                                                        // 222
            var socket = Streamy.sockets(sId);                                                                         // 223
                                                                                                                       //
            if (channels[sId]) {                                                                                       // 224
                closeCh(channels[sId], sId);                                                                           // 225
            } //keep the channel associate with a client (socket) to close it later                                    // 226
                                                                                                                       //
                                                                                                                       //
            channels[sId] = ch;                                                                                        // 228
            ch.assertExchange(ex, 'fanout', {                                                                          // 229
                durable: false                                                                                         // 229
            });                                                                                                        // 229
            ch.assertQueue('', {                                                                                       // 230
                exclusive: true                                                                                        // 230
            }, function (err, q) {                                                                                     // 230
                ch.on('close', function () {                                                                           // 231
                    console.log(sId + " channel closed");                                                              // 232
                    Streamy.emit('msg', {                                                                              // 233
                        content: sId + " channel closed"                                                               // 233
                    }, socket);                                                                                        // 233
                });                                                                                                    // 234
                done(err, q.queue);                                                                                    // 235
                Streamy.emit('msg', {                                                                                  // 236
                    content: " [*] Waiting for messages"                                                               // 236
                }, socket);                                                                                            // 236
                ch.bindQueue(q.queue, ex, '');                                                                         // 237
                ch.consume(q.queue, function (msg) {                                                                   // 238
                    console.log(" [x] %s", msg.content.toString());                                                    // 239
                    var content = msg.content.toString();                                                              // 240
                    Streamy.emit('msg', {                                                                              // 241
                        content: content                                                                               // 241
                    }, socket);                                                                                        // 241
                }, {                                                                                                   // 242
                    noAck: true                                                                                        // 242
                });                                                                                                    // 242
            });                                                                                                        // 243
        });                                                                                                            // 244
    } else {                                                                                                           // 245
        return done(new Error('Unrecognised exchange'));                                                               // 246
    }                                                                                                                  // 247
});                                                                                                                    // 248
Meteor.methods({                                                                                                       // 250
    //db connectors                                                                                                    // 251
    mongodbConnect: mongodbConnect,                                                                                    // 252
    mysqlConnect: mysqlConnect,                                                                                        // 253
    amqpConnect: amqpConnect,                                                                                          // 254
    sparqlConnect: sparqlConnect,                                                                                      // 255
    htmlConnect: sparqlConnect,                                                                                        // 256
    appConnect: function (id) {                                                                                        // 257
        var url = Apps.findOne(id).url;                                                                                // 258
                                                                                                                       //
        if (url) {                                                                                                     // 259
            HTTP.get(url, {                                                                                            // 260
                timeout: 30000                                                                                         // 261
            }, function (error) {                                                                                      // 260
                if (error) {                                                                                           // 264
                    Apps.update({                                                                                      // 265
                        _id: id                                                                                        // 265
                    }, {                                                                                               // 265
                        $set: {                                                                                        // 265
                            'online': false                                                                            // 265
                        }                                                                                              // 265
                    });                                                                                                // 265
                } else {                                                                                               // 266
                    Apps.update({                                                                                      // 267
                        _id: id                                                                                        // 267
                    }, {                                                                                               // 267
                        $set: {                                                                                        // 267
                            'online': true                                                                             // 267
                        }                                                                                              // 267
                    });                                                                                                // 267
                }                                                                                                      // 268
            });                                                                                                        // 269
        } else {                                                                                                       // 270
            Apps.update({                                                                                              // 271
                _id: id                                                                                                // 271
            }, {                                                                                                       // 271
                $set: {                                                                                                // 271
                    'online': false                                                                                    // 271
                }                                                                                                      // 271
            });                                                                                                        // 271
        }                                                                                                              // 272
    },                                                                                                                 // 273
    //query executors                                                                                                  // 275
    mongodbQuery: mongodbQuery,                                                                                        // 276
    mysqlQuery: mysqlQuery,                                                                                            // 277
    sparqlQuery: sparqlQuery,                                                                                          // 278
    amqpQuery: amqpQuery,                                                                                              // 279
    //utils                                                                                                            // 281
    mongodbCollectionNames: function (distId) {                                                                        // 282
        var db = connPool[distId];                                                                                     // 283
                                                                                                                       //
        if (!db) {                                                                                                     // 285
            mongodbConnect(distId);                                                                                    // 286
        }                                                                                                              // 287
                                                                                                                       //
        db = connPool[distId];                                                                                         // 289
                                                                                                                       //
        if (!db) {                                                                                                     // 291
            throw new Meteor.Error('not-found', "Distribution " + distId + " not initialised");                        // 292
        }                                                                                                              // 293
                                                                                                                       //
        var _Async$runSync3 = Async.runSync(function (done) {                                                          // 282
            db.listCollections().toArray(done);                                                                        // 296
        }),                                                                                                            // 297
            error = _Async$runSync3.error,                                                                             // 282
            result = _Async$runSync3.result;                                                                           // 282
                                                                                                                       //
        if (error) {                                                                                                   // 299
            throw new Meteor.Error(error.name, error.message);                                                         // 300
        } else {                                                                                                       // 301
            result = result.filter(function (x) {                                                                      // 302
                return x.name !== 'system.indexes';                                                                    // 303
            }); //console.log(result);                                                                                 // 304
                                                                                                                       //
            return result;                                                                                             // 306
        }                                                                                                              // 307
    },                                                                                                                 // 308
    amqpCollectionNames: function (distId) {                                                                           // 310
        var conn = connPool[distId];                                                                                   // 311
                                                                                                                       //
        if (!conn) {                                                                                                   // 313
            amqpConnect(distId);                                                                                       // 314
        }                                                                                                              // 315
                                                                                                                       //
        conn = connPool[distId];                                                                                       // 317
                                                                                                                       //
        if (!conn) {                                                                                                   // 319
            throw new Meteor.Error('not-found', "Distribution " + distId + " not initialised");                        // 320
        }                                                                                                              // 321
                                                                                                                       //
        return conn.exchanges;                                                                                         // 323
    }                                                                                                                  // 324
});                                                                                                                    // 250
var channels = {}; //socketId:channel, each socket only grants for one channels                                        // 327
                                                                                                                       //
function closeCh(ch, sId) {                                                                                            // 328
    if (ch) {                                                                                                          // 329
        try {                                                                                                          // 330
            ch.close();                                                                                                // 331
        } catch (e) {                                                                                                  // 332
            console.log(e.stackAtStateChange);                                                                         // 334
        } finally {                                                                                                    // 335
            delete channels[sId];                                                                                      // 337
        }                                                                                                              // 338
    }                                                                                                                  // 339
} /**                                                                                                                  // 340
   * Upon disconnect, clear the client database                                                                        //
   */                                                                                                                  //
                                                                                                                       //
Streamy.onDisconnect(function (socket) {                                                                               // 344
    var sId = Streamy.id(socket),                                                                                      // 345
        ch = channels[sId];                                                                                            // 345
    closeCh(ch, sId);                                                                                                  // 348
    Streamy.broadcast('__leave__', {                                                                                   // 349
        'sid': Streamy.id(socket)                                                                                      // 350
    });                                                                                                                // 349
});                                                                                                                    // 352
Streamy.on('amqp_end', function (socket) {                                                                             // 354
    var sId = Streamy.id(socket),                                                                                      // 355
        ch = channels[sId];                                                                                            // 355
    closeCh(ch, sId);                                                                                                  // 358
    Streamy.broadcast('__leave__', {                                                                                   // 359
        'sid': Streamy.id(socket)                                                                                      // 360
    });                                                                                                                // 359
});                                                                                                                    // 362
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/groups.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */Meteor.methods({                                                                                                    //
    addToGroup: function (userId, groupId) {                                                                           // 6
        check(userId, String);                                                                                         // 7
        check(groupId, String);                                                                                        // 8
        return Groups.update(groupId, {                                                                                // 9
            $addToSet: {                                                                                               // 9
                contentWhiteList: userId                                                                               // 9
            }                                                                                                          // 9
        });                                                                                                            // 9
    },                                                                                                                 // 10
    removeFromGroup: function (userId, groupId) {                                                                      // 11
        check(userId, String);                                                                                         // 12
        check(groupId, String);                                                                                        // 13
        Groups.update(groupId, {                                                                                       // 14
            $pull: {                                                                                                   // 14
                contentWhiteList: userId                                                                               // 14
            }                                                                                                          // 14
        });                                                                                                            // 14
    }                                                                                                                  // 15
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/notifications.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 13/01/2016.                                                                                      //
 */createNotification = function (initiatorId, entryId, entryName, userId, category, message) {                        //
    var actions = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;                           // 5
    check(initiatorId, String);                                                                                        // 6
    check(entryId, String);                                                                                            // 7
    check(entryName, String);                                                                                          // 8
    check(userId, String);                                                                                             // 9
    check(category, String);                                                                                           // 10
    check(message, String);                                                                                            // 11
    check(actions, Match.Any);                                                                                         // 12
                                                                                                                       //
    if (initiatorId !== userId) {                                                                                      // 14
        Notifications.update({                                                                                         // 15
            userId: userId,                                                                                            // 16
            initiatorId: initiatorId,                                                                                  // 17
            category: category,                                                                                        // 18
            entryId: entryId,                                                                                          // 19
            entryName: entryName,                                                                                      // 20
            message: message,                                                                                          // 21
            actions: actions,                                                                                          // 22
            read: false                                                                                                // 23
        }, {                                                                                                           // 15
            $set: {                                                                                                    // 25
                userId: userId,                                                                                        // 26
                initiatorId: initiatorId,                                                                              // 27
                category: category,                                                                                    // 28
                entryId: entryId,                                                                                      // 29
                entryName: entryName,                                                                                  // 30
                message: message,                                                                                      // 31
                actions: actions,                                                                                      // 32
                read: false                                                                                            // 33
            }                                                                                                          // 25
        }, {                                                                                                           // 24
            upsert: true                                                                                               // 35
        });                                                                                                            // 35
    }                                                                                                                  // 36
};                                                                                                                     // 37
                                                                                                                       //
Meteor.methods({                                                                                                       // 39
    createNotification: createNotification,                                                                            // 40
    createRequestNotification: function (username, organisation, initiatorId, entry, category, note) {                 // 41
        check(username, String);                                                                                       // 42
        check(organisation, String);                                                                                   // 43
        check(initiatorId, String);                                                                                    // 44
        check(entry, Object);                                                                                          // 45
        check(category, String);                                                                                       // 46
        var path = Router.routes[category + '.page'].path({                                                            // 48
            _id: entry._id                                                                                             // 48
        });                                                                                                            // 48
        var message = "<strong>" + username + "</strong>" + (organisation ? ' of ' + '<strong>' + organisation + '</strong>' : '') + ' requested access to ' + (category + " <a class=\"blue-text\" href=\"" + path + "\">" + entry.name + "</a><br>") + (note ? "\"" + note + "\"" : ""),
            actions = ['Allow', 'Deny'];                                                                               // 50
        createNotification(initiatorId, entry._id, entry.name, entry.publisher, category, message, actions);           // 57
    }                                                                                                                  // 58
});                                                                                                                    // 39
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/_utils.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */ /**                                                                                                                //
     *                                                                                                                 //
     * @param coll A collection                                                                                        //
     * @param pubCBFactry A factory function that returns the publish callback                                         //
     * @param pubAs Maps a collection to publishing name                                                               //
     */publish = function (coll, pubCBFactry) {                                                                        //
  var pubAs = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function (coll) {                    // 11
    return coll.pluralName;                                                                                            // 11
  };                                                                                                                   // 11
  var name = pubAs(coll);                                                                                              // 12
  Meteor.publish(name, pubCBFactry(coll, name));                                                                       // 13
}; //import JSONStream from 'JSONStream';                                                                              // 14
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fixtures.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (Meteor.settings.public.environment === 'dev' && !Meteor.settings.public.migrate) {                                 // 1
    /* testing cases                                                                                                   // 2
     *               ds1 (all)     ds2 (none)     ds3 (group)                                                          //
     * admin           own             y            own                                                                //
     * individual      y               own          n                                                                  //
     * member          y               n            y                                                                  //
     * group           y               n            y                                                                  //
     * */var addAdmin = function (name) {                                                                              //
        var xgfdId = Accounts.createUser({                                                                             // 12
            profile: {                                                                                                 // 13
                name: name                                                                                             // 14
            },                                                                                                         // 13
            username: name,                                                                                            // 16
            email: name + "@example.com",                                                                              // 17
            password: "123456"                                                                                         // 18
        });                                                                                                            // 12
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 21
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 22
        return xgfdId;                                                                                                 // 24
    };                                                                                                                 // 25
                                                                                                                       //
    var addIndividual = function (name) {                                                                              // 1
        return Accounts.createUser({                                                                                   // 28
            profile: {                                                                                                 // 29
                name: name                                                                                             // 30
            },                                                                                                         // 29
            username: name,                                                                                            // 32
            email: name + "@example.com",                                                                              // 33
            password: "123456"                                                                                         // 34
        });                                                                                                            // 28
    };                                                                                                                 // 36
                                                                                                                       //
    var addGroup = function (name) {                                                                                   // 1
        var xgfdId = Accounts.createUser({                                                                             // 39
            profile: {                                                                                                 // 40
                name: name,                                                                                            // 41
                isgroup: true,                                                                                         // 42
                description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
                url: "https://www.google.co.uk"                                                                        // 44
            },                                                                                                         // 40
            username: name,                                                                                            // 46
            email: name + "@example.com",                                                                              // 47
            password: "123456"                                                                                         // 48
        });                                                                                                            // 39
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 51
        Roles.addUserToRoles(xgfdId, ["group"]);                                                                       // 52
        return xgfdId;                                                                                                 // 54
    };                                                                                                                 // 55
                                                                                                                       //
    var xgfdId = void 0,                                                                                               // 57
        individualId = void 0,                                                                                         // 57
        groupId = void 0,                                                                                              // 57
        memberId = void 0;                                                                                             // 57
                                                                                                                       //
    if (Meteor.users.find().count() === 0) {                                                                           // 58
        xgfdId = addAdmin('xgfd');                                                                                     // 59
        individualId = addIndividual('individual');                                                                    // 60
        groupId = addGroup('group');                                                                                   // 61
        memberId = addIndividual('member');                                                                            // 62
        var tmp = Meteor.call('addToGroup', memberId, Groups.findOne({                                                 // 63
            publisher: groupId                                                                                         // 63
        })._id);                                                                                                       // 63
    } // Fixture data                                                                                                  // 64
                                                                                                                       //
                                                                                                                       //
    var telescopeId = void 0;                                                                                          // 66
                                                                                                                       //
    if (Datasets.find().count() === 0) {                                                                               // 67
        var now = new Date().getTime();                                                                                // 68
        telescopeId = Datasets.insert({                                                                                // 70
            name: 'Introducing Telescope',                                                                             // 71
            publisher: xgfdId,                                                                                         // 72
            distribution: [{                                                                                           // 73
                url: 'mongodb://localhost:3001/meteor',                                                                // 74
                fileFormat: "MongoDB",                                                                                 // 75
                online: true                                                                                           // 76
            }, {                                                                                                       // 73
                url: 'amqp://wsi-h1.soton.ac.uk?exchange=logs',                                                        // 78
                fileFormat: "AMQP",                                                                                    // 79
                online: true                                                                                           // 80
            }],                                                                                                        // 77
            license: "MIT",                                                                                            // 82
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 2,                                                                                          // 84
            aclContent: false,                                                                                         // 85
            online: true,                                                                                              // 86
            upvoters: [],                                                                                              // 87
            votes: 0                                                                                                   // 87
        });                                                                                                            // 70
        Comments.insert({                                                                                              // 90
            entryId: telescopeId,                                                                                      // 91
            publisher: individualId,                                                                                   // 92
            submitted: new Date(now - 5 * 3600 * 1000),                                                                // 93
            body: 'Interesting project Sacha, can I get involved?'                                                     // 94
        });                                                                                                            // 90
        Comments.insert({                                                                                              // 97
            entryId: telescopeId,                                                                                      // 98
            publisher: xgfdId,                                                                                         // 99
            submitted: new Date(now - 3 * 3600 * 1000),                                                                // 100
            body: "<p><span style=\"font-family: 'Comic Sans MS';\"><span style=\"font-size: 18px; background-color: rgb(255, 0, 0);\">You</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 156, 0);\">sure</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 255, 0);\">can</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(0, 255, 0);\">Tom</span><span style=\"font-size: 18px; background-color: rgb(0, 0, 255);\">!!!</span></span></p>"
        });                                                                                                            // 97
        Datasets.insert({                                                                                              // 104
            name: 'The Meteor Book',                                                                                   // 105
            publisher: individualId,                                                                                   // 106
            distribution: [{                                                                                           // 107
                url: 'http://themeteorbook.com',                                                                       // 108
                fileFormat: "MySQL",                                                                                   // 109
                online: false                                                                                          // 110
            }, {                                                                                                       // 107
                url: 'http://dbpedia.org/sparql',                                                                      // 112
                fileFormat: "SPARQL",                                                                                  // 113
                online: true                                                                                           // 114
            }],                                                                                                        // 111
            license: "MIT",                                                                                            // 116
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi pharetra augue eget hendrerit bibendum. Vivamus quis laoreet magna. Quisque eu mi sit amet lorem vestibulum rhoncus. Donec lacus est, sodales convallis urna nec, condimentum accumsan ligula. Nullam maximus a sem ac laoreet. In hac habitasse platea dictumst. Pellentesque porttitor ex orci, sed suscipit ante pretium eget. Nam vestibulum metus a libero ultricies molestie sed vel est. Maecenas porta tempus purus, sed pharetra nibh sodales vitae. Nullam in erat tristique, posuere enim laoreet, suscipit erat. Sed quis efficitur enim. 2",
            commentsCount: 0,                                                                                          // 118
            online: false,                                                                                             // 119
            aclMeta: false,                                                                                            // 120
            upvoters: [],                                                                                              // 121
            votes: 0                                                                                                   // 121
        });                                                                                                            // 104
        Datasets.insert({                                                                                              // 124
            name: 'Group visible dataset',                                                                             // 125
            publisher: xgfdId,                                                                                         // 126
            distribution: [{                                                                                           // 127
                url: 'http://sachagreif.com/introducing-telescope/',                                                   // 128
                fileFormat: "HTML",                                                                                    // 129
                online: true                                                                                           // 130
            }],                                                                                                        // 127
            license: "MIT",                                                                                            // 132
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 0,                                                                                          // 134
            aclMeta: false,                                                                                            // 135
            aclContent: false,                                                                                         // 136
            metaWhiteList: [groupId],                                                                                  // 137
            contentWhiteList: [groupId],                                                                               // 138
            online: true,                                                                                              // 139
            upvoters: [],                                                                                              // 140
            votes: 0                                                                                                   // 140
        });                                                                                                            // 124
                                                                                                                       //
        for (var i = 0; i < 50; i++) {                                                                                 // 143
            Apps.insert({                                                                                              // 144
                name: 'Test app #' + i,                                                                                // 145
                url: 'http://sachagreif.com/introducing-telescope/#' + i,                                              // 146
                publisher: groupId,                                                                                    // 147
                license: "MIT",                                                                                        // 148
                aclContent: !!(i % 2),                                                                                 // 149
                description: "Etiam porttitor purus et mollis malesuada. Nulla tempor orci id ex tincidunt consectetur. Praesent et dignissim lectus, in posuere ante. Curabitur nunc dolor, interdum a ornare eget, laoreet eu metus. Ut tempor lacinia eros nec finibus. Maecenas quis felis non mi euismod consectetur quis at leo. Nullam porta tempus ullamcorper. Phasellus et nibh feugiat, iaculis massa eget, blandit quam. Aliquam dolor justo, feugiat et sem ut, fermentum elementum arcu. Aliquam quis tincidunt tortor. Suspendisse potenti. Duis congue sapien ac purus iaculis pharetra. Donec hendrerit lacus leo, non ultricies purus accumsan nec. Nulla vel suscipit quam. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
                commentsCount: 0,                                                                                      // 151
                upvoters: [],                                                                                          // 152
                votes: 0                                                                                               // 152
            });                                                                                                        // 144
        }                                                                                                              // 154
    }                                                                                                                  // 155
}                                                                                                                      // 156
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/init.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 11/01/2016.                                                                                      //
 */SyncedCron.add({                                                                                                    //
    name: 'Pull remote collections',                                                                                   // 5
    schedule: function (parser) {                                                                                      // 6
        // parser is a later.parse object                                                                              // 7
        return parser.text('every 1 hour');                                                                            // 8
    },                                                                                                                 // 9
    job: pullRemoteColls                                                                                               // 10
});                                                                                                                    // 4
SyncedCron.add({                                                                                                       // 13
    name: 'Datasets/Apps connection test',                                                                             // 14
    schedule: function (parser) {                                                                                      // 15
        // parser is a later.parse object                                                                              // 16
        return parser.text('every 12 hour');                                                                           // 17
    },                                                                                                                 // 18
    job: checkCon                                                                                                      // 19
});                                                                                                                    // 13
Meteor.startup(function () {                                                                                           // 22
    var settings = Meteor.settings; //create admin                                                                     // 23
                                                                                                                       //
    if (!settings.admin) {                                                                                             // 26
        settings.admin = {                                                                                             // 27
            name: 'admin',                                                                                             // 27
            username: 'admin',                                                                                         // 27
            email: 'admin@webobservatory.org',                                                                         // 27
            password: 'admin'                                                                                          // 27
        };                                                                                                             // 27
    }                                                                                                                  // 28
                                                                                                                       //
    if (!Accounts.findUserByUsername(settings.admin.username)) {                                                       // 30
        var xgfdId = Accounts.createUser({                                                                             // 31
            profile: {                                                                                                 // 32
                name: settings.admin.name                                                                              // 33
            },                                                                                                         // 32
            username: settings.admin.username,                                                                         // 35
            email: settings.admin.email,                                                                               // 36
            password: settings.admin.password                                                                          // 37
        });                                                                                                            // 31
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 40
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 41
    }                                                                                                                  // 42
                                                                                                                       //
    Meteor.call('nicolaslopezj_roles_migrate'); // 1. Set up stmp                                                      // 44
    //   your_server would be something like 'smtp.gmail.com'                                                          // 47
    //   and your_port would be a number like 25                                                                       // 48
                                                                                                                       //
    if (settings.smtp) {                                                                                               // 50
        process.env.MAIL_URL = encodeURIComponent(settings.smtp);                                                      // 51
    } // Add Facebook configuration entry                                                                              // 52
                                                                                                                       //
                                                                                                                       //
    if (settings.facebook) {                                                                                           // 56
        ServiceConfiguration.configurations.update({                                                                   // 57
            "service": "facebook"                                                                                      // 58
        }, {                                                                                                           // 58
            $set: {                                                                                                    // 60
                "appId": settings.facebook.appId,                                                                      // 61
                "secret": settings.facebook.secret                                                                     // 62
            }                                                                                                          // 60
        }, {                                                                                                           // 59
            upsert: true                                                                                               // 65
        });                                                                                                            // 65
    } // Add GitHub configuration entry                                                                                // 67
                                                                                                                       //
                                                                                                                       //
    if (settings.github) {                                                                                             // 70
        ServiceConfiguration.configurations.update({                                                                   // 71
            "service": "github"                                                                                        // 72
        }, {                                                                                                           // 72
            $set: {                                                                                                    // 74
                "clientId": settings.github.clientId,                                                                  // 75
                "secret": settings.github.secret                                                                       // 76
            }                                                                                                          // 74
        }, {                                                                                                           // 73
            upsert: true                                                                                               // 79
        });                                                                                                            // 79
    } // Set up LDAP.                                                                                                  // 81
    // Overwrite this function to produce settings based on the incoming request                                       // 84
                                                                                                                       //
                                                                                                                       //
    LDAP.generateSettings = function (request) {                                                                       // 85
        var username = request.username,                                                                               // 86
            domain = username.split('@')[1];                                                                           // 86
        var ldaps = orion.dictionary.get('ldap.ldap'),                                                                 // 89
            ldapConfig = void 0;                                                                                       // 89
                                                                                                                       //
        if (ldaps) {                                                                                                   // 92
            ldapConfig = ldaps.filter(function (v) {                                                                   // 93
                return v.domain === domain;                                                                            // 93
            })[0];                                                                                                     // 93
            ldapConfig.whiteListedFields = ldapConfig.whiteListedFields.split(/,\s*/);                                 // 94
            ldapConfig.autopublishFields = ldapConfig.autopublishFields ? ldapConfig.autopublishFields.split(/,\s*/) : ldapConfig.whiteListedFields;
            delete ldapConfig.domain;                                                                                  // 96
        }                                                                                                              // 97
                                                                                                                       //
        return ldapConfig;                                                                                             // 99
    };                                                                                                                 // 100
                                                                                                                       //
    LDAP.bindValue = function (username, isEmailAddress, serverDn) {                                                   // 102
        return (isEmailAddress ? username.split('@')[0] : username) + '@' + serverDn;                                  // 103
    };                                                                                                                 // 104
                                                                                                                       //
    LDAP.filter = function (isEmailAddress, usernameOrEmail) {                                                         // 106
        return '(&(cn=' + (isEmailAddress ? usernameOrEmail.split('@')[0] : usernameOrEmail) + ')(objectClass=user))';
    };                                                                                                                 // 108
                                                                                                                       //
    LDAP.logging = false;                                                                                              // 110
    Accounts.onCreateUser(function (options, user) {                                                                   // 112
        // console.log(options, user);                                                                                 // 113
        var profile = options.profile || {};                                                                           // 114
                                                                                                                       //
        if (!profile.name) {                                                                                           // 116
            profile.name = profile.displayName || options.username;                                                    // 117
        }                                                                                                              // 118
                                                                                                                       //
        user.profile = profile; // console.log(user);                                                                  // 120
                                                                                                                       //
        return user;                                                                                                   // 122
    }); // Get remote apps and datasets                                                                                // 123
    // pullRemoteColls();                                                                                              // 126
    // checkCon();                                                                                                     // 127
                                                                                                                       //
    SyncedCron.start();                                                                                                // 128
});                                                                                                                    // 129
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*collection publication*/function pubSingle(coll) {                                                                   // 1
    function cbFactry(coll) {                                                                                          // 3
        return function (id) {                                                                                         // 4
            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};                      // 4
            check(id, String);                                                                                         // 5
            var selector = {                                                                                           // 7
                _id: id                                                                                                // 7
            },                                                                                                         // 7
                userId = this.userId;                                                                                  // 7
            extendOr(selector, viewsDocumentQuery(userId));                                                            // 10
            options.fields = {                                                                                         // 11
                //'distribution.url': 0,                                                                               // 12
                'distribution.file': 0,                                                                                // 13
                'distribution.profile.username': 0,                                                                    // 14
                'distribution.profile.pass': 0                                                                         // 15
            };                                                                                                         // 11
            return coll.find(selector, options);                                                                       // 18
        };                                                                                                             // 19
    }                                                                                                                  // 20
                                                                                                                       //
    publish(coll, cbFactry, function (coll) {                                                                          // 22
        return coll.singularName;                                                                                      // 22
    });                                                                                                                // 22
}                                                                                                                      // 23
                                                                                                                       //
function pubPlural(coll) {                                                                                             // 25
    function cbFactry(coll) {                                                                                          // 26
        return function () {                                                                                           // 27
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};                      // 27
            var selector = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};                     // 27
                                                                                                                       //
            //check(options, {                                                                                         // 28
            //    fields: Match.Optional(Object),                                                                      // 29
            //    skip: Match.Optional(Object),                                                                        // 30
            //    sort: Match.Optional(Object),                                                                        // 31
            //    limit: Match.Optional(Number)                                                                        // 32
            //});                                                                                                      // 33
            if (!selector) {                                                                                           // 34
                selector = {};                                                                                         // 35
            }                                                                                                          // 36
                                                                                                                       //
            if (!options) {                                                                                            // 38
                options = {};                                                                                          // 39
            }                                                                                                          // 40
                                                                                                                       //
            check(selector, Object);                                                                                   // 42
                                                                                                                       //
            switch (coll) {                                                                                            // 44
                case Meteor.users:                                                                                     // 45
                    options.fields = {                                                                                 // 46
                        username: 1                                                                                    // 46
                    };                                                                                                 // 46
                    break;                                                                                             // 47
                                                                                                                       //
                case Datasets:                                                                                         // 49
                    var userId = this.userId;                                                                          // 50
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 51
                    options.fields = {                                                                                 // 52
                        //'distribution.url': 0,                                                                       // 53
                        'distribution.file': 0,                                                                        // 54
                        'distribution.profile.username': 0,                                                            // 55
                        'distribution.profile.pass': 0                                                                 // 56
                    };                                                                                                 // 52
                    Counts.publish(this, coll.singularName, coll.find(), {                                             // 58
                        nonReactive: true                                                                              // 58
                    });                                                                                                // 58
                    break;                                                                                             // 59
                                                                                                                       //
                case Apps:                                                                                             // 61
                    userId = this.userId;                                                                              // 62
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 63
                    Counts.publish(this, coll.singularName, coll.find(), {                                             // 64
                        nonReactive: true                                                                              // 64
                    });                                                                                                // 64
                    break;                                                                                             // 65
            }                                                                                                          // 44
                                                                                                                       //
            return coll.find(selector, options);                                                                       // 68
        };                                                                                                             // 69
    }                                                                                                                  // 70
                                                                                                                       //
    publish(coll, cbFactry, function (coll) {                                                                          // 72
        return coll.pluralName;                                                                                        // 72
    });                                                                                                                // 72
}                                                                                                                      // 73
                                                                                                                       //
[Datasets, Apps, RemoteApps, RemoteDatasets, Groups].forEach(pubSingle);                                               // 75
[Datasets, Apps, Groups, Licenses, Meteor.users, RemoteApps, RemoteDatasets].forEach(pubPlural);                       // 77
Meteor.publish('comments', function (entryId) {                                                                        // 79
    check(entryId, String);                                                                                            // 80
    return Comments.find({                                                                                             // 81
        entryId: entryId                                                                                               // 81
    });                                                                                                                // 81
}); //publish({                                                                                                        // 82
//        countDatasets: Datasets,                                                                                     // 85
//        countApps: Apps,                                                                                             // 86
//        countGroups: Groups,                                                                                         // 87
//}, Meteor.publish, function (collection) {                                                                           // 88
//    return function () {                                                                                             // 89
//        Counts.publish(this, collection.singularName, collection.find());                                            // 90
//        //return collection.find();                                                                                  // 91
//    }                                                                                                                // 92
//});                                                                                                                  // 93
                                                                                                                       //
Meteor.publish('notifications', function () {                                                                          // 95
    return Notifications.find({                                                                                        // 96
        userId: this.userId,                                                                                           // 96
        read: false                                                                                                    // 96
    });                                                                                                                // 96
});                                                                                                                    // 97
Meteor.publish('images', function () {                                                                                 // 99
    return Images.find();                                                                                              // 100
}); //Meteor.publish("datasetsAndApps", function () {                                                                  // 101
//    return [                                                                                                         // 104
//        Datasets.find(),                                                                                             // 105
//        Apps.find()                                                                                                  // 106
//    ];                                                                                                               // 107
//});                                                                                                                  // 108
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/search.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by eugene on 11/02/2016.                                                                                    //
 */function buildRegExp(keywords) {                                                                                    //
    // this is a dumb implementation                                                                                   // 6
    var parts = keywords.trim().split(/[ \-\:]+/);                                                                     // 7
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 8
} //function containAny(keywords) {                                                                                    // 9
//    return keywords ? {$or: [{name: buildRegExp(keywords)}]} : {};                                                   // 12
//}                                                                                                                    // 13
//function fedSearch(colls, keywords, options) {                                                                       // 15
//    options = options || {limit: 10};                                                                                // 16
//                                                                                                                     // 17
//    let fedResult = colls                                                                                            // 18
//        .map(col=> col.find(containAny(keywords), options).fetch())//fetch collection                                // 19
//        .reduce((a, b)=>a.concat(b));//concat results                                                                // 20
//    return fedResult;                                                                                                // 21
//}                                                                                                                    // 22
//                                                                                                                     // 23
//let searchDatasets = fedSearch.bind(null, [Datasets, RemoteDatasets]),                                               // 24
//    searchApps = fedSearch.bind(null, [Apps, RemoteApps]);                                                           // 25
                                                                                                                       //
                                                                                                                       //
SearchSource.defineSource('apps', function (keywords, options) {                                                       // 27
    var options = {                                                                                                    // 28
        limit: 10                                                                                                      // 28
    };                                                                                                                 // 28
                                                                                                                       //
    if (keywords) {                                                                                                    // 30
        var regExp = buildRegExp(keywords);                                                                            // 31
        var selector = {                                                                                               // 32
            $or: [{                                                                                                    // 33
                name: regExp                                                                                           // 34
            }]                                                                                                         // 34
        };                                                                                                             // 32
        return Apps.find(selector, options).fetch();                                                                   // 38
    } else {                                                                                                           // 39
        return Apps.find({}, options).fetch();                                                                         // 40
    }                                                                                                                  // 41
});                                                                                                                    // 42
SearchSource.defineSource('datasets', function (keywords, options) {                                                   // 44
    var options = {                                                                                                    // 45
        limit: 10                                                                                                      // 45
    };                                                                                                                 // 45
                                                                                                                       //
    if (keywords) {                                                                                                    // 47
        var regExp = buildRegExp(keywords);                                                                            // 48
        var selector = {                                                                                               // 49
            $or: [{                                                                                                    // 50
                name: regExp                                                                                           // 51
            }]                                                                                                         // 51
        };                                                                                                             // 49
        return Datasets.find(selector, options).fetch();                                                               // 55
    } else {                                                                                                           // 56
        return Datasets.find({}, options).fetch();                                                                     // 57
    }                                                                                                                  // 58
});                                                                                                                    // 59
SearchSource.defineSource('remoteDatasets', function (keywords, options) {                                             // 61
    var options = {                                                                                                    // 62
        limit: 10                                                                                                      // 62
    };                                                                                                                 // 62
                                                                                                                       //
    if (keywords) {                                                                                                    // 64
        var regExp = buildRegExp(keywords);                                                                            // 65
        var selector = {                                                                                               // 66
            $or: [{                                                                                                    // 67
                name: regExp                                                                                           // 68
            }]                                                                                                         // 68
        };                                                                                                             // 66
        return RemoteDatasets.find(selector, options).fetch();                                                         // 72
    } else {                                                                                                           // 73
        return RemoteDatasets.find({}, options).fetch();                                                               // 74
    }                                                                                                                  // 75
});                                                                                                                    // 76
SearchSource.defineSource('remoteApps', function (keywords, options) {                                                 // 78
    var options = {                                                                                                    // 79
        limit: 10                                                                                                      // 79
    };                                                                                                                 // 79
                                                                                                                       //
    if (keywords) {                                                                                                    // 81
        var regExp = buildRegExp(keywords);                                                                            // 82
        var selector = {                                                                                               // 83
            $or: [{                                                                                                    // 84
                name: regExp                                                                                           // 85
            }]                                                                                                         // 85
        };                                                                                                             // 83
        return RemoteApps.find(selector, options).fetch();                                                             // 89
    } else {                                                                                                           // 90
        return RemoteApps.find({}, options).fetch();                                                                   // 91
    }                                                                                                                  // 92
});                                                                                                                    // 93
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/collections/declarations/_utils.js");
require("./lib/collections/declarations/apps.js");
require("./lib/collections/declarations/clients.js");
require("./lib/collections/declarations/comments.js");
require("./lib/collections/declarations/datasets.js");
require("./lib/collections/declarations/group.js");
require("./lib/collections/declarations/licenses.js");
require("./lib/collections/declarations/notifications.js");
require("./lib/collections/declarations/remote.js");
require("./lib/collections/schemas/_creative_work.js");
require("./lib/collections/schemas/apps.js");
require("./lib/collections/schemas/clients.js");
require("./lib/collections/schemas/comments.js");
require("./lib/collections/schemas/datasets.js");
require("./lib/collections/schemas/groups.js");
require("./lib/collections/schemas/licenses.js");
require("./lib/collections/schemas/remote.js");
require("./lib/config/at_config.js");
require("./lib/roles/_utils.js");
require("./lib/roles/individual.js");
require("./lib/_utils.js");
require("./lib/orion_config.js");
require("./lib/orion_dictionary.js");
require("./lib/orion_filesystem.js");
require("./lib/router.js");
require("./server/api/resource_server/middlewares/content.js");
require("./server/api/resource_server/middlewares/metadata.js");
require("./server/api/resource_server/middlewares/prov.js");
require("./server/api/resource_server/middlewares/utils.js");
require("./server/api/gateway/client_routes.js");
require("./server/api/gateway/models.js");
require("./server/api/gateway/oidc.js");
require("./server/api/gateway/routes.js");
require("./server/api/resource_server/routes.js");
require("./server/api/app.js");
require("./server/cronjobs/connectionTest.js");
require("./server/cronjobs/get_remote_colls.js");
require("./server/methods/accounts.js");
require("./server/methods/comments.js");
require("./server/methods/creative_work.js");
require("./server/methods/distributions.js");
require("./server/methods/groups.js");
require("./server/methods/notifications.js");
require("./server/_utils.js");
require("./server/fixtures.js");
require("./server/init.js");
require("./server/publications.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
