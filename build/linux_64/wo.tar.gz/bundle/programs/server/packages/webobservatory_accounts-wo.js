(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Accounts = Package['accounts-base'].Accounts;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var Wooidc = Package['webobservatory:wooidc'].Wooidc;
var selectedWONode = Package['webobservatory:wooidc'].selectedWONode;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var Iron = Package['iron:core'].Iron;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/webobservatory_accounts-wo/wooidc.js                                                           //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
Accounts.oauth.registerService('wooidc');

if (Meteor.isClient) {

    Meteor.loginWithWooidc = function (options, wonode, callback) {
        // support a callback without options
        if (! callback && typeof options === 'function') {
            callback = options;
            options = null;
        }

        var credentialRequestCompleteCallback = Accounts.oauth.credentialRequestCompleteHandler(callback);
        Wooidc.requestCredential(options, wonode, credentialRequestCompleteCallback);
    };
}
else {
    Accounts.addAutopublishFields({
        forLoggedInUser: ['services.wooidc'],
        forOtherUsers: ['services.wooidc.id']
    });
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['webobservatory:accounts-wo'] = {};

})();
