(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var check = Package.check.check;
var Match = Package.check.Match;
var orion = Package['orionjs:base'].orion;
var moment = Package['momentjs:moment'].moment;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var process = Package.modules.process;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var HTML = Package.htmljs.HTML;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:attributes":{"attributes.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/attributes.js                                                             //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
/**                                                                                                      // 1
 * Adds the option the set orionAttribute on SimpleSchema                                                //
 */SimpleSchema.extendOptions({                                                                          //
  orionAttribute: Match.Optional(String),                                                                // 5
  orion: Match.Optional(Object)                                                                          // 6
}); /**                                                                                                  // 4
     * Definition of the attributes object                                                               //
     */                                                                                                  //
orion.attributes = {}; /**                                                                               // 12
                        * Returns the schema for the attribute                                           //
                        */                                                                               //
                                                                                                         //
orion.attribute = function (name, schema, options) {                                                     // 17
  if (!_.has(orion.attributes, name)) {                                                                  // 18
    throw 'The attribute "' + name + '" does not exist';                                                 // 19
  }                                                                                                      // 20
                                                                                                         //
  schema = schema || {};                                                                                 // 21
  options = options || {};                                                                               // 22
  var attributeSchema = orion.attributes[name].getSchema.call(this, options);                            // 23
  var override = {                                                                                       // 24
    orionAttribute: name,                                                                                // 25
    autoform: {                                                                                          // 26
      type: 'orion.' + name                                                                              // 27
    }                                                                                                    // 26
  };                                                                                                     // 24
  var attribute = orion.helpers.deepExtend(orion.helpers.deepExtend(schema, attributeSchema), override);
  return attribute;                                                                                      // 31
}; /**                                                                                                   // 32
    * Returns proper tabular column for the attribute                                                    //
    */                                                                                                   //
                                                                                                         //
orion.attributeColumn = function (name, key, title) {                                                    // 37
  var options = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};                  // 37
  check(options, {                                                                                       // 38
    orderable: Match.Optional(Boolean)                                                                   // 39
  });                                                                                                    // 38
  var attributeDef = orion.attributes[name];                                                             // 41
                                                                                                         //
  if (attributeDef.orderable && options.orderable !== false) {                                           // 43
    options.orderable = true;                                                                            // 44
  }                                                                                                      // 45
                                                                                                         //
  return {                                                                                               // 47
    data: key,                                                                                           // 48
    title: title,                                                                                        // 49
    defaultContent: '',                                                                                  // 50
    orderable: !!options.orderable,                                                                      // 51
    render: function () {                                                                                // 52
      return '';                                                                                         // 53
    },                                                                                                   // 54
    createdCell: function (cell, cellData, rowData) {                                                    // 55
      var collection = rowData._collection();                                                            // 56
                                                                                                         //
      var schema = rowData._collection().simpleSchema()._schema[key];                                    // 57
                                                                                                         //
      var data = {                                                                                       // 58
        key: key,                                                                                        // 59
        value: cellData,                                                                                 // 60
        item: rowData,                                                                                   // 61
        collection: collection,                                                                          // 62
        schema: schema                                                                                   // 63
      };                                                                                                 // 58
      var template = ReactiveTemplates.get('attributePreview.' + name);                                  // 65
      Blaze.renderWithData(Template[template], data, cell);                                              // 66
    }                                                                                                    // 67
  };                                                                                                     // 47
}; /**                                                                                                   // 69
    * Helper function to use arrays of attributes (Ex: array of images)                                  //
    */                                                                                                   //
                                                                                                         //
orion.arrayOfAttribute = function (name, schema, options) {                                              // 74
  var subSchema = new SimpleSchema({                                                                     // 75
    item: orion.attribute(name, {                                                                        // 76
      autoform: {                                                                                        // 77
        label: false                                                                                     // 78
      }                                                                                                  // 77
    })                                                                                                   // 76
  });                                                                                                    // 75
  return orion.helpers.deepExtend(schema, {                                                              // 82
    type: [subSchema]                                                                                    // 83
  });                                                                                                    // 82
}; /**                                                                                                   // 85
    * Creates a new attribute                                                                            //
    */                                                                                                   //
                                                                                                         //
orion.attributes.registerAttribute = function (name, attribute) {                                        // 90
  check(name, String);                                                                                   // 91
  check(attribute, {                                                                                     // 92
    template: Match.Optional(String),                                                                    // 93
    columnTemplate: Match.Optional(String),                                                              // 94
    previewTemplate: Match.Optional(String),                                                             // 95
    getSchema: Function,                                                                                 // 96
    valueOut: Match.Optional(Function),                                                                  // 97
    valueIn: Match.Optional(Function),                                                                   // 98
    valueConverters: Match.Optional(Function),                                                           // 99
    contextAdjust: Match.Optional(Function),                                                             // 100
    orderable: Match.Optional(Boolean)                                                                   // 101
  });                                                                                                    // 92
                                                                                                         //
  if (attribute.template) {                                                                              // 104
    ReactiveTemplates.request('attribute.' + name, attribute.template);                                  // 105
  }                                                                                                      // 106
                                                                                                         //
  if (attribute.previewTemplate) {                                                                       // 108
    ReactiveTemplates.request('attributePreview.' + name, attribute.previewTemplate);                    // 109
  }                                                                                                      // 110
                                                                                                         //
  orion.attributes[name] = attribute;                                                                    // 112
                                                                                                         //
  if (Meteor.isClient && attribute.template) {                                                           // 114
    Tracker.autorun(function () {                                                                        // 115
      AutoForm.addInputType('orion.' + name, {                                                           // 116
        template: ReactiveTemplates.get('attribute.' + name),                                            // 117
        valueIn: attribute.valueIn,                                                                      // 118
        valueOut: attribute.valueOut,                                                                    // 119
        valueConverters: attribute.valueConverters,                                                      // 120
        contextAdjust: attribute.contextAdjust                                                           // 121
      });                                                                                                // 116
    });                                                                                                  // 123
  }                                                                                                      // 124
};                                                                                                       // 125
///////////////////////////////////////////////////////////////////////////////////////////////////////////

},"created-by":{"created-by.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-by/created-by.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdBy', {                                                        // 1
  previewTemplate: 'createdByPreview',                                                                   // 2
  getSchema: function (options) {                                                                        // 3
    return {                                                                                             // 4
      type: String,                                                                                      // 5
      index: 1,                                                                                          // 6
      autoform: {                                                                                        // 7
        omit: true                                                                                       // 8
      },                                                                                                 // 7
      optional: true,                                                                                    // 10
      autoValue: function () {                                                                           // 11
        if (this.isInsert) {                                                                             // 12
          return this.userId;                                                                            // 13
        } else if (this.isUpsert) {                                                                      // 14
          return {                                                                                       // 15
            $setOnInsert: this.userId                                                                    // 15
          };                                                                                             // 15
        } else {                                                                                         // 16
          this.unset();                                                                                  // 17
        }                                                                                                // 18
      }                                                                                                  // 19
    };                                                                                                   // 4
  }                                                                                                      // 21
});                                                                                                      // 1
                                                                                                         //
if (Meteor.isServer) {                                                                                   // 24
  Meteor.publish('userProfileForCreatedByAttributeColumn', function (userId) {                           // 25
    check(userId, String);                                                                               // 26
    return Meteor.users.find({                                                                           // 27
      _id: userId                                                                                        // 27
    }, {                                                                                                 // 27
      fields: {                                                                                          // 27
        profile: 1                                                                                       // 27
      }                                                                                                  // 27
    });                                                                                                  // 27
  });                                                                                                    // 28
}                                                                                                        // 29
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 31
  ReactiveTemplates.onRendered('attributePreview.createdBy', function () {                               // 32
    this.subscribe('userProfileForCreatedByAttributeColumn', this.data.value);                           // 33
  });                                                                                                    // 34
  ReactiveTemplates.helpers('attributePreview.createdBy', {                                              // 36
    name: function () {                                                                                  // 37
      var user = Meteor.users.findOne(this.value);                                                       // 38
      return user && user.profile && user.profile.name;                                                  // 39
    }                                                                                                    // 40
  });                                                                                                    // 36
}                                                                                                        // 42
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"created-at":{"created-at.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/created-at/created-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('createdAt', {                                                        // 1
  previewTemplate: 'createdAtPreview',                                                                   // 2
  orderable: true,                                                                                       // 3
  getSchema: function (options) {                                                                        // 4
    return {                                                                                             // 5
      type: Date,                                                                                        // 6
      index: 1,                                                                                          // 7
      autoform: {                                                                                        // 8
        omit: true                                                                                       // 9
      },                                                                                                 // 8
      autoValue: function () {                                                                           // 11
        if (this.isInsert) {                                                                             // 12
          return new Date();                                                                             // 13
        } else if (this.isUpsert) {                                                                      // 14
          return {                                                                                       // 15
            $setOnInsert: new Date()                                                                     // 15
          };                                                                                             // 15
        } else {                                                                                         // 16
          this.unset();                                                                                  // 17
        }                                                                                                // 18
      }                                                                                                  // 19
    };                                                                                                   // 5
  }                                                                                                      // 21
});                                                                                                      // 1
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 24
  ReactiveTemplates.helpers('attributePreview.createdAt', {                                              // 25
    date: function () {                                                                                  // 26
      return this.value && moment(this.value).format('LLL');                                             // 27
    }                                                                                                    // 28
  });                                                                                                    // 25
}                                                                                                        // 30
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"updated-by":{"updated-by.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/updated-by/updated-by.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('updatedBy', {                                                        // 1
  previewTemplate: 'updatedByPreview',                                                                   // 2
  getSchema: function (options) {                                                                        // 3
    return {                                                                                             // 4
      type: String,                                                                                      // 5
      index: 1,                                                                                          // 6
      autoform: {                                                                                        // 7
        omit: true                                                                                       // 8
      },                                                                                                 // 7
      autoValue: function () {                                                                           // 10
        if (this.isUpdate || this.isInsert) {                                                            // 11
          return this.userId;                                                                            // 12
        } else if (this.isUpsert) {                                                                      // 13
          return {                                                                                       // 14
            $setOnInsert: this.userId                                                                    // 14
          };                                                                                             // 14
        } else {                                                                                         // 15
          this.unset();                                                                                  // 16
        }                                                                                                // 17
      }                                                                                                  // 18
    };                                                                                                   // 4
  }                                                                                                      // 20
});                                                                                                      // 1
                                                                                                         //
if (Meteor.isServer) {                                                                                   // 23
  Meteor.publish('userProfileForUpdatedByAttributeColumn', function (userId) {                           // 24
    check(userId, String);                                                                               // 25
    return Meteor.users.find({                                                                           // 26
      _id: userId                                                                                        // 26
    }, {                                                                                                 // 26
      fields: {                                                                                          // 26
        profile: 1                                                                                       // 26
      }                                                                                                  // 26
    });                                                                                                  // 26
  });                                                                                                    // 27
}                                                                                                        // 28
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 30
  ReactiveTemplates.onRendered('attributePreview.updatedBy', function () {                               // 31
    this.subscribe('userProfileForUpdatedByAttributeColumn', this.data.value);                           // 32
  });                                                                                                    // 33
  ReactiveTemplates.helpers('attributePreview.updatedBy', {                                              // 34
    name: function () {                                                                                  // 35
      var user = Meteor.users.findOne(this.value);                                                       // 36
      return user && user.profile.name;                                                                  // 37
    }                                                                                                    // 38
  });                                                                                                    // 34
}                                                                                                        // 40
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"updated-at":{"updated-at.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                       //
// packages/orionjs_attributes/updated-at/updated-at.js                                                  //
//                                                                                                       //
///////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                         //
orion.attributes.registerAttribute('updatedAt', {                                                        // 1
  previewTemplate: 'updatedAtPreview',                                                                   // 2
  orderable: true,                                                                                       // 3
  getSchema: function (options) {                                                                        // 4
    return {                                                                                             // 5
      type: Date,                                                                                        // 6
      index: 1,                                                                                          // 7
      autoform: {                                                                                        // 8
        omit: true                                                                                       // 9
      },                                                                                                 // 8
      autoValue: function () {                                                                           // 11
        if (this.isUpdate || this.isInsert) {                                                            // 12
          return new Date();                                                                             // 13
        } else if (this.isUpsert) {                                                                      // 14
          return {                                                                                       // 15
            $setOnInsert: new Date()                                                                     // 15
          };                                                                                             // 15
        } else {                                                                                         // 16
          this.unset();                                                                                  // 17
        }                                                                                                // 18
      }                                                                                                  // 19
    };                                                                                                   // 5
  }                                                                                                      // 21
});                                                                                                      // 1
                                                                                                         //
if (Meteor.isClient) {                                                                                   // 24
  ReactiveTemplates.helpers('attributePreview.updatedAt', {                                              // 25
    date: function () {                                                                                  // 26
      return this.value && moment(this.value).format('LLL');                                             // 27
    }                                                                                                    // 28
  });                                                                                                    // 25
}                                                                                                        // 30
///////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/orionjs:attributes/attributes.js");
require("./node_modules/meteor/orionjs:attributes/created-by/created-by.js");
require("./node_modules/meteor/orionjs:attributes/created-at/created-at.js");
require("./node_modules/meteor/orionjs:attributes/updated-by/updated-by.js");
require("./node_modules/meteor/orionjs:attributes/updated-at/updated-at.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:attributes'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_attributes.js.map
