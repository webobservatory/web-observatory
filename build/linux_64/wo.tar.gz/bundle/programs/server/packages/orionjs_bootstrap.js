(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:attributes'].orion;
var Tabular = Package['aldeed:tabular'].Tabular;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var process = Package.modules.process;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var HTML = Package.htmljs.HTML;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var Accounts = Package['accounts-base'].Accounts;
var CollectionHooks = Package['matb33:collection-hooks'].CollectionHooks;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:bootstrap":{"init.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/orionjs_bootstrap/init.js                                                                            //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
Options.init('homePath');                                                                                        // 1
Options.init('siteName');                                                                                        // 2
ReactiveTemplates.request('tabs', 'orionBootstrapTabs');                                                         // 4
ReactiveTemplates.request('adminSidebar');                                                                       // 5
ReactiveTemplates.set('layout', 'orionBootstrapLayout');                                                         // 7
ReactiveTemplates.set('outAdminLayout', 'orionBootstrapOutAdminLayout');                                         // 8
ReactiveTemplates.set('adminSidebar', 'orionBootstrapSidebar');                                                  // 10
ReactiveTemplates.set('login', 'orionBootstrapLogin');                                                           // 11
ReactiveTemplates.set('registerWithInvitation', 'orionBootstrapRegisterWithInvitation');                         // 12
ReactiveTemplates.set('myAccount.index', 'orionBootstrapAccountIndex');                                          // 14
ReactiveTemplates.set('myAccount.password', 'orionBootstrapAccountPassword');                                    // 15
ReactiveTemplates.set('myAccount.profile', 'orionBootstrapAccountProfile');                                      // 16
ReactiveTemplates.set('accounts.index', 'orionBootstrapAccountsIndex');                                          // 18
ReactiveTemplates.set('accounts.update', 'orionBootstrapAccountsUpdate');                                        // 19
ReactiveTemplates.set('accounts.create', 'orionBootstrapAccountsCreate');                                        // 20
ReactiveTemplates.set('configUpdate', 'orionBootstrapConfigUpdate');                                             // 22
ReactiveTemplates.set('dictionaryUpdate', 'orionBootstrapDictionaryUpdate'); // Set the default entity templates
                                                                                                                 //
Options.set('collectionsDefaultIndexTemplate', 'orionBootstrapCollectionsIndex');                                // 26
Options.set('collectionsDefaultCreateTemplate', 'orionBootstrapCollectionsCreate');                              // 27
Options.set('collectionsDefaultUpdateTemplate', 'orionBootstrapCollectionsUpdate');                              // 28
Options.set('collectionsDefaultDeleteTemplate', 'orionBootstrapCollectionsDelete'); // Pages                     // 29
                                                                                                                 //
ReactiveTemplates.set('pages.index', 'orionBootstrapPagesIndex');                                                // 32
ReactiveTemplates.set('pages.create', 'orionBootstrapPagesCreate');                                              // 33
ReactiveTemplates.set('pages.update', 'orionBootstrapPagesUpdate');                                              // 34
ReactiveTemplates.set('pages.delete', 'orionBootstrapPagesDelete');                                              // 35
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tabular.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/orionjs_bootstrap/tabular.js                                                                         //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
orion.collections.onCreated(function () {                                                                        // 1
  var self = this; // if the collection doesn't has the tabular option, nothing to do here!                      // 2
                                                                                                                 //
  if (!_.has(this, 'tabular')) return;                                                                           // 5
                                                                                                                 //
  var tabularOptions = _.extend({                                                                                // 7
    name: 'tabular_' + self.name,                                                                                // 8
    collection: self,                                                                                            // 9
    columns: [{                                                                                                  // 10
      data: '_id',                                                                                               // 11
      title: 'ID'                                                                                                // 11
    }],                                                                                                          // 11
    stateSave: true,                                                                                             // 13
    responsive: true,                                                                                            // 14
    autoWidth: false,                                                                                            // 15
    selector: function (userId) {                                                                                // 16
      var selectors = Roles.helper(userId, 'collections.' + self.name + '.indexFilter');                         // 17
      return {                                                                                                   // 18
        $or: selectors                                                                                           // 18
      };                                                                                                         // 18
    },                                                                                                           // 19
    language: {                                                                                                  // 21
      search: i18n('tabular.search'),                                                                            // 22
      info: i18n('tabular.info'),                                                                                // 23
      infoEmpty: i18n('tabular.infoEmpty'),                                                                      // 24
      lengthMenu: i18n('tabular.lengthMenu'),                                                                    // 25
      emptyTable: i18n('tabular.emptyTable'),                                                                    // 26
      paginate: {                                                                                                // 27
        first: i18n('tabular.paginate.first'),                                                                   // 28
        previous: i18n('tabular.paginate.previous'),                                                             // 29
        next: i18n('tabular.paginate.next'),                                                                     // 30
        last: i18n('tabular.paginate.last')                                                                      // 31
      }                                                                                                          // 27
    }                                                                                                            // 21
  }, this.tabular);                                                                                              // 7
                                                                                                                 //
  Tracker.autorun(function () {                                                                                  // 36
    tabularOptions.columns.map(function (column) {                                                               // 37
      if (_.isFunction(column.title)) {                                                                          // 38
        column.langTitle = column.title;                                                                         // 39
      }                                                                                                          // 40
                                                                                                                 //
      if (_.isFunction(column.langTitle)) {                                                                      // 42
        column.title = column.langTitle();                                                                       // 43
      }                                                                                                          // 44
                                                                                                                 //
      return column;                                                                                             // 46
    });                                                                                                          // 47
    self.tabularTable = new Tabular.Table(tabularOptions);                                                       // 49
  });                                                                                                            // 50
});                                                                                                              // 51
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/orionjs:bootstrap/init.js");
require("./node_modules/meteor/orionjs:bootstrap/tabular.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:bootstrap'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_bootstrap.js.map
