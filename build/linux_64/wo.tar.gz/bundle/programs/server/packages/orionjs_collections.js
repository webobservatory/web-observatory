(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:base'].orion;
var _ = Package.underscore._;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var process = Package.modules.process;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var HTML = Package.htmljs.HTML;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:collections":{"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/orionjs_collections/init.js                                                                    //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
/**                                                                                                        // 1
 * Init the entities variable                                                                              //
 */orion.collections = {};                                                                                 //
orion.collections.hooks = {                                                                                // 6
  onCreated: []                                                                                            // 7
};                                                                                                         // 6
                                                                                                           //
orion.collections.onCreated = function (cb) {                                                              // 10
  this.hooks.onCreated.push(cb);                                                                           // 11
}; /**                                                                                                     // 12
    * Request the default templates using options                                                          //
    */                                                                                                     //
                                                                                                           //
Options.init('collectionsDefaultIndexTemplate');                                                           // 17
Options.init('collectionsDefaultCreateTemplate');                                                          // 18
Options.init('collectionsDefaultUpdateTemplate');                                                          // 19
Options.init('collectionsDefaultDeleteTemplate');                                                          // 20
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"new.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/orionjs_collections/new.js                                                                     //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
orion.collections.list = {}; /**                                                                           // 1
                              * Collection definition, it overrides Mongo.Collection                       //
                              */                                                                           //
                                                                                                           //
orion.collection = function (name, options) {                                                              // 6
  check(name, String);                                                                                     // 7
  check(options, Object);                                                                                  // 8
  var collection = new Mongo.Collection(name, options);                                                    // 10
  options = _.extend({                                                                                     // 12
    name: name,                                                                                            // 13
    routePath: name,                                                                                       // 14
    pluralName: name,                                                                                      // 15
    singularName: name,                                                                                    // 16
    autopublishUpdate: true,                                                                               // 17
    title: name[0].toUpperCase() + name.slice(1)                                                           // 18
  }, options);                                                                                             // 12
  collection = _.extend(collection, options);                                                              // 21
                                                                                                           //
  for (var i = 0, N = orion.collections.hooks.onCreated.length; i < N; i++) {                              // 23
    orion.collections.hooks.onCreated[i].call(collection);                                                 // 24
  }                                                                                                        // 25
                                                                                                           //
  collection.helpers({                                                                                     // 27
    _collection: function () {                                                                             // 28
      return collection;                                                                                   // 29
    }                                                                                                      // 30
  });                                                                                                      // 27
  orion.collections.list[name] = collection;                                                               // 33
  return collection;                                                                                       // 34
};                                                                                                         // 35
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"permissions.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/orionjs_collections/permissions.js                                                             //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
orion.collections.onCreated(function () {                                                                  // 1
  var self = this;                                                                                         // 2
  var allow = !this.dontAllowByDefault; /**                                                                // 4
                                         * Collection permissions                                          //
                                         */                                                                //
  Roles.registerAction('collections.' + this.name + '.index', allow);                                      // 9
  Roles.registerAction('collections.' + this.name + '.showCreate', allow);                                 // 10
  Roles.registerAction('collections.' + this.name + '.showUpdate', allow);                                 // 11
  Roles.registerAction('collections.' + this.name + '.showRemove', allow);                                 // 12
  Roles.registerHelper('collections.' + this.name + '.indexFilter', allow && {});                          // 13
  this.attachRoles('collections.' + this.name);                                                            // 15
                                                                                                           //
  if (Meteor.isClient) {                                                                                   // 17
    this.canIndex = function () {                                                                          // 18
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.index');              // 19
    };                                                                                                     // 20
                                                                                                           //
    this.canShowCreate = function () {                                                                     // 21
      return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showCreate');         // 22
    };                                                                                                     // 23
                                                                                                           //
    this.getHiddenFields = function () {                                                                   // 24
      var docId = RouterLayer.getParam('_id');                                                             // 25
      return _.union.apply(this, Roles.helper(Meteor.userId(), 'collections.' + self.name + '.forbiddenFields', docId));
    };                                                                                                     // 27
                                                                                                           //
    this.helpers({                                                                                         // 28
      canShowUpdate: function () {                                                                         // 29
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showUpdate', this);
      },                                                                                                   // 31
      canShowRemove: function () {                                                                         // 32
        return Roles.userHasPermission(Meteor.userId(), 'collections.' + self.name + '.showRemove', this);
      }                                                                                                    // 34
    });                                                                                                    // 28
  }                                                                                                        // 36
});                                                                                                        // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"admin.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/orionjs_collections/admin.js                                                                   //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
orion.collections.onCreated(function () {                                                                  // 1
  var self = this; /**                                                                                     // 2
                    * Request a template for the collection                                                //
                    */                                                                                     //
  ReactiveTemplates.request('collections.' + self.name + '.index', Options.get('collectionsDefaultIndexTemplate')); /**
                                                                                                                     * Register the index route
                                                                                                                     */
  RouterLayer.route('/admin/' + self.routePath, {                                                          // 12
    layout: 'layout',                                                                                      // 13
    template: 'collections.' + self.name + '.index',                                                       // 14
    name: 'collections.' + self.name + '.index',                                                           // 15
    reactiveTemplates: true                                                                                // 16
  });                                                                                                      // 12
                                                                                                           //
  self.indexPath = function () {                                                                           // 18
    return RouterLayer.pathFor('collections.' + self.name + '.index');                                     // 19
  }; /**                                                                                                   // 20
      * Ensure user is logged in                                                                           //
      */                                                                                                   //
                                                                                                           //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.index'); /**                             // 25
                                                                            * Request a template for the collection create
                                                                            */                             //
  ReactiveTemplates.request('collections.' + self.name + '.create', Options.get('collectionsDefaultCreateTemplate')); /**
                                                                                                                       * Register the create route
                                                                                                                       */
  RouterLayer.route('/admin/' + self.routePath + '/create', {                                              // 35
    layout: 'layout',                                                                                      // 36
    template: 'collections.' + self.name + '.create',                                                      // 37
    name: 'collections.' + self.name + '.create',                                                          // 38
    reactiveTemplates: true                                                                                // 39
  });                                                                                                      // 35
                                                                                                           //
  self.createPath = function () {                                                                          // 41
    return RouterLayer.pathFor('collections.' + self.name + '.create');                                    // 42
  }; /**                                                                                                   // 43
      * Ensure user is logged in                                                                           //
      */                                                                                                   //
                                                                                                           //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.create'); /**                            // 48
                                                                             * Request a template for the collection update
                                                                             */                            //
  ReactiveTemplates.request('collections.' + self.name + '.update', Options.get('collectionsDefaultUpdateTemplate')); /**
                                                                                                                       * Register the update route
                                                                                                                       */
  RouterLayer.route('/admin/' + self.routePath + '/:_id', {                                                // 58
    layout: 'layout',                                                                                      // 59
    template: 'collections.' + self.name + '.update',                                                      // 60
    name: 'collections.' + self.name + '.update',                                                          // 61
    reactiveTemplates: true                                                                                // 62
  });                                                                                                      // 58
                                                                                                           //
  self.updatePath = function (item) {                                                                      // 64
    var options = item;                                                                                    // 65
                                                                                                           //
    if (_.isString(item)) {                                                                                // 66
      options = {                                                                                          // 67
        _id: item                                                                                          // 67
      };                                                                                                   // 67
    }                                                                                                      // 68
                                                                                                           //
    return RouterLayer.pathFor('collections.' + self.name + '.update', options);                           // 70
  }; /**                                                                                                   // 71
      * Ensure user is logged in                                                                           //
      */                                                                                                   //
                                                                                                           //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.update'); /**                            // 76
                                                                             * Request a template for the collection delete
                                                                             */                            //
  ReactiveTemplates.request('collections.' + self.name + '.delete', Options.get('collectionsDefaultDeleteTemplate')); /**
                                                                                                                       * Register the delete route
                                                                                                                       */
  RouterLayer.route('/admin/' + self.routePath + '/:_id/delete', {                                         // 86
    layout: 'layout',                                                                                      // 87
    template: 'collections.' + self.name + '.delete',                                                      // 88
    name: 'collections.' + self.name + '.delete',                                                          // 89
    reactiveTemplates: true                                                                                // 90
  });                                                                                                      // 86
                                                                                                           //
  this.deletePath = function (item) {                                                                      // 92
    var options = item;                                                                                    // 93
                                                                                                           //
    if (_.isString(item)) {                                                                                // 94
      options = {                                                                                          // 95
        _id: item                                                                                          // 95
      };                                                                                                   // 95
    }                                                                                                      // 96
                                                                                                           //
    return RouterLayer.pathFor('collections.' + self.name + '.delete', options);                           // 98
  }; /**                                                                                                   // 99
      * Ensure user is logged in                                                                           //
      */                                                                                                   //
                                                                                                           //
  orion.accounts.addProtectedRoute('collections.' + self.name + '.delete');                                // 104
});                                                                                                        // 105
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                         //
// packages/orionjs_collections/publications.js                                                            //
//                                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                           //
orion.collections.onCreated(function () {                                                                  // 1
  var self = this;                                                                                         // 2
  Meteor.publish('adminGetOne.' + this.name, function (_id) {                                              // 3
    check(_id, String);                                                                                    // 4
    return self.find(_id);                                                                                 // 5
  }, {                                                                                                     // 6
    is_auto: true                                                                                          // 6
  });                                                                                                      // 6
});                                                                                                        // 7
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./node_modules/meteor/orionjs:collections/init.js");
require("./node_modules/meteor/orionjs:collections/new.js");
require("./node_modules/meteor/orionjs:collections/permissions.js");
require("./node_modules/meteor/orionjs:collections/admin.js");
require("./node_modules/meteor/orionjs:collections/publications.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:collections'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_collections.js.map
