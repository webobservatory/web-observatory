(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var orion = Package['orionjs:base'].orion;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var _ = Package.underscore._;
var check = Package.check.check;
var Match = Package.check.Match;
var RouterLayer = Package['nicolaslopezj:router-layer'].RouterLayer;
var Options = Package['nicolaslopezj:options'].Options;
var ReactiveTemplates = Package['nicolaslopezj:reactive-templates'].ReactiveTemplates;
var Roles = Package['nicolaslopezj:roles'].Roles;
var objectHasKey = Package['nicolaslopezj:roles'].objectHasKey;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var HTML = Package.htmljs.HTML;
var i18n = Package['anti:i18n'].i18n;
var T9n = Package['softwarerero:accounts-t9n'].T9n;

var require = meteorInstall({"node_modules":{"meteor":{"orionjs:filesystem":{"filesystem.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/orionjs_filesystem/filesystem.js                                                          //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
Roles.registerAction('filesystem.upload', true); // input: { name, meta, uploader, uploadedBy }.      // 1
Roles.registerAction('filesystem.remove', true); // input: { url, name, meta, uploader, uploadedBy }.
                                                                                                      //
orion.filesystem = {};                                                                                // 4
                                                                                                      //
/**                                                                                                   // 6
 * Files stored in the database                                                                       //
 */                                                                                                   //
orion.filesystem.collection = new Mongo.Collection('orionFiles');                                     // 9
                                                                                                      //
/**                                                                                                   // 11
 * Files collection schema                                                                            //
 */                                                                                                   //
orion.filesystem.collection.attachSchema(new SimpleSchema({                                           // 14
  url: {                                                                                              // 15
    type: String                                                                                      // 16
  },                                                                                                  // 15
  name: {                                                                                             // 18
    type: String                                                                                      // 19
  },                                                                                                  // 18
  uploader: {                                                                                         // 21
    type: String                                                                                      // 22
  },                                                                                                  // 21
  meta: {                                                                                             // 24
    type: Object,                                                                                     // 25
    optional: true,                                                                                   // 26
    blackbox: true                                                                                    // 27
  },                                                                                                  // 24
  size: {                                                                                             // 29
    type: Number,                                                                                     // 30
    optional: true                                                                                    // 31
  },                                                                                                  // 29
  uploadedBy: {                                                                                       // 33
    type: String,                                                                                     // 34
    optional: true                                                                                    // 35
  }                                                                                                   // 33
}));                                                                                                  // 14
                                                                                                      //
orion.filesystem.collection.allow({                                                                   // 39
  insert: function () {                                                                               // 40
    function insert(userId, doc) {                                                                    // 40
      return Roles.allow(userId, 'filesystem.upload', doc);                                           // 41
    }                                                                                                 // 42
                                                                                                      //
    return insert;                                                                                    // 40
  }(),                                                                                                // 40
                                                                                                      //
  remove: function () {                                                                               // 44
    function remove(userId, doc) {                                                                    // 44
      return Roles.allow(userId, 'filesystem.upload', doc);                                           // 45
    }                                                                                                 // 46
                                                                                                      //
    return remove;                                                                                    // 44
  }()                                                                                                 // 44
});                                                                                                   // 39
                                                                                                      //
orion.filesystem.collection.deny({                                                                    // 49
  insert: function () {                                                                               // 50
    function insert(userId, doc) {                                                                    // 50
      return Roles.deny(userId, 'filesystem.remove', doc);                                            // 51
    }                                                                                                 // 52
                                                                                                      //
    return insert;                                                                                    // 50
  }(),                                                                                                // 50
                                                                                                      //
  remove: function () {                                                                               // 54
    function remove(userId, doc) {                                                                    // 54
      return Roles.deny(userId, 'filesystem.remove', doc);                                            // 55
    }                                                                                                 // 56
                                                                                                      //
    return remove;                                                                                    // 54
  }()                                                                                                 // 54
});                                                                                                   // 49
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filesystem_server.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/orionjs_filesystem/filesystem_server.js                                                   //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
Meteor.methods({                                                                                      // 1
  getFileDataToEarse: function () {                                                                   // 2
    function getFileDataToEarse(fileId) {                                                             // 2
      check(fileId, String);                                                                          // 3
      var doc = orion.filesystem.collection.findOne(fileId);                                          // 4
      if (doc) {                                                                                      // 5
        Roles.checkPermission(Meteor.userId(), 'filesystem.remove', doc);                             // 6
        return doc;                                                                                   // 7
      }                                                                                               // 8
    }                                                                                                 // 9
                                                                                                      //
    return getFileDataToEarse;                                                                        // 2
  }()                                                                                                 // 2
});                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{"extensions":[".js",".json"]});
require("./node_modules/meteor/orionjs:filesystem/filesystem.js");
require("./node_modules/meteor/orionjs:filesystem/filesystem_server.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['orionjs:filesystem'] = {}, {
  orion: orion
});

})();

//# sourceMappingURL=orionjs_filesystem.js.map
