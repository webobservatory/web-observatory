(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['jesperwe:bootstrap-select'] = {};

})();
