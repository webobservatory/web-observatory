(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['github-config-ui'] = {};

})();
