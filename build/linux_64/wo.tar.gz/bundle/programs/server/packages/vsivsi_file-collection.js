(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var check = Package.check.check;
var Match = Package.check.Match;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;
var Symbol = Package['ecmascript-runtime-server'].Symbol;
var Map = Package['ecmascript-runtime-server'].Map;
var Set = Package['ecmascript-runtime-server'].Set;

/* Package-scope variables */
var __coffeescriptShare, FileCollection;

(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS.coffee.js                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
share.defaultChunkSize = 2 * 1024 * 1024 - 1024;                                                                       // 7
                                                                                                                       //
share.defaultRoot = 'fs';                                                                                              // 8
                                                                                                                       //
share.resumableBase = '/_resumable';                                                                                   // 10
                                                                                                                       //
share.insert_func = function(file, chunkSize) {                                                                        // 12
  var id, ref, ref1, ref2, ref3, subFile;                                                                              // 13
  if (file == null) {                                                                                                  //
    file = {};                                                                                                         //
  }                                                                                                                    //
  try {                                                                                                                // 13
    id = new Mongo.ObjectID("" + file._id);                                                                            //
  } catch (error) {                                                                                                    //
    id = new Mongo.ObjectID();                                                                                         //
  }                                                                                                                    //
  subFile = {};                                                                                                        //
  subFile._id = id;                                                                                                    //
  subFile.length = 0;                                                                                                  //
  subFile.md5 = 'd41d8cd98f00b204e9800998ecf8427e';                                                                    //
  subFile.uploadDate = new Date();                                                                                     //
  subFile.chunkSize = chunkSize;                                                                                       //
  subFile.filename = (ref = file.filename) != null ? ref : '';                                                         //
  subFile.metadata = (ref1 = file.metadata) != null ? ref1 : {};                                                       //
  subFile.aliases = (ref2 = file.aliases) != null ? ref2 : [];                                                         //
  subFile.contentType = (ref3 = file.contentType) != null ? ref3 : 'application/octet-stream';                         //
  return subFile;                                                                                                      // 27
};                                                                                                                     // 12
                                                                                                                       //
share.reject_file_modifier = function(modifier) {                                                                      // 29
  var forbidden, required;                                                                                             // 31
  forbidden = Match.OneOf(Match.ObjectIncluding({                                                                      //
    _id: Match.Any                                                                                                     //
  }), Match.ObjectIncluding({                                                                                          //
    length: Match.Any                                                                                                  //
  }), Match.ObjectIncluding({                                                                                          //
    chunkSize: Match.Any                                                                                               //
  }), Match.ObjectIncluding({                                                                                          //
    md5: Match.Any                                                                                                     //
  }), Match.ObjectIncluding({                                                                                          //
    uploadDate: Match.Any                                                                                              //
  }));                                                                                                                 //
  required = Match.OneOf(Match.ObjectIncluding({                                                                       //
    _id: Match.Any                                                                                                     //
  }), Match.ObjectIncluding({                                                                                          //
    length: Match.Any                                                                                                  //
  }), Match.ObjectIncluding({                                                                                          //
    chunkSize: Match.Any                                                                                               //
  }), Match.ObjectIncluding({                                                                                          //
    md5: Match.Any                                                                                                     //
  }), Match.ObjectIncluding({                                                                                          //
    uploadDate: Match.Any                                                                                              //
  }), Match.ObjectIncluding({                                                                                          //
    metadata: Match.Any                                                                                                //
  }), Match.ObjectIncluding({                                                                                          //
    aliases: Match.Any                                                                                                 //
  }), Match.ObjectIncluding({                                                                                          //
    filename: Match.Any                                                                                                //
  }), Match.ObjectIncluding({                                                                                          //
    contentType: Match.Any                                                                                             //
  }));                                                                                                                 //
  return Match.test(modifier, Match.OneOf(Match.ObjectIncluding({                                                      // 51
    $set: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $unset: required                                                                                                   //
  }), Match.ObjectIncluding({                                                                                          //
    $inc: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $mul: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $bit: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $min: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $max: forbidden                                                                                                    //
  }), Match.ObjectIncluding({                                                                                          //
    $rename: required                                                                                                  //
  }), Match.ObjectIncluding({                                                                                          //
    $currentDate: forbidden                                                                                            //
  }), Match.Where(function(pat) {                                                                                      //
    return !Match.test(pat, Match.OneOf(Match.ObjectIncluding({                                                        // 62
      $inc: Match.Any                                                                                                  //
    }), Match.ObjectIncluding({                                                                                        //
      $set: Match.Any                                                                                                  //
    }), Match.ObjectIncluding({                                                                                        //
      $unset: Match.Any                                                                                                //
    }), Match.ObjectIncluding({                                                                                        //
      $addToSet: Match.Any                                                                                             //
    }), Match.ObjectIncluding({                                                                                        //
      $pop: Match.Any                                                                                                  //
    }), Match.ObjectIncluding({                                                                                        //
      $pullAll: Match.Any                                                                                              //
    }), Match.ObjectIncluding({                                                                                        //
      $pull: Match.Any                                                                                                 //
    }), Match.ObjectIncluding({                                                                                        //
      $pushAll: Match.Any                                                                                              //
    }), Match.ObjectIncluding({                                                                                        //
      $push: Match.Any                                                                                                 //
    }), Match.ObjectIncluding({                                                                                        //
      $bit: Match.Any                                                                                                  //
    })));                                                                                                              //
  })));                                                                                                                //
};                                                                                                                     // 29
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/server_shared.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var through2;                                                                                                          // 7
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  through2 = Npm.require('through2');                                                                                  //
  share.defaultResponseHeaders = {                                                                                     //
    'Content-Type': 'text/plain'                                                                                       //
  };                                                                                                                   //
  share.check_allow_deny = function(type, userId, file, fields) {                                                      //
    var checkRules, result;                                                                                            // 16
    checkRules = function(rules) {                                                                                     //
      var func, i, len, ref, res;                                                                                      // 17
      res = false;                                                                                                     //
      ref = rules[type];                                                                                               // 18
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 18
        func = ref[i];                                                                                                 //
        if (!res) {                                                                                                    //
          res = func(userId, file, fields);                                                                            //
        }                                                                                                              //
      }                                                                                                                // 18
      return res;                                                                                                      // 20
    };                                                                                                                 //
    result = !checkRules(this.denys) && checkRules(this.allows);                                                       //
    return result;                                                                                                     // 23
  };                                                                                                                   //
  share.bind_env = function(func) {                                                                                    //
    if (func != null) {                                                                                                //
      return Meteor.bindEnvironment(func, function(err) {                                                              // 27
        throw err;                                                                                                     // 27
      });                                                                                                              //
    } else {                                                                                                           //
      return func;                                                                                                     // 29
    }                                                                                                                  //
  };                                                                                                                   //
  share.safeObjectID = function(s) {                                                                                   //
    if (s != null ? s.match(/^[0-9a-f]{24}$/i) : void 0) {                                                             //
      return new Mongo.ObjectID(s);                                                                                    //
    } else {                                                                                                           //
      return null;                                                                                                     //
    }                                                                                                                  //
  };                                                                                                                   //
  share.streamChunker = function(size) {                                                                               //
    var makeFuncs;                                                                                                     // 38
    if (size == null) {                                                                                                //
      size = share.defaultChunkSize;                                                                                   //
    }                                                                                                                  //
    makeFuncs = function(size) {                                                                                       //
      var bufferList, flush, total, transform;                                                                         // 39
      bufferList = [new Buffer(0)];                                                                                    //
      total = 0;                                                                                                       //
      flush = function(cb) {                                                                                           //
        var lastBuffer, newBuffer, outSize, outputBuffer;                                                              // 42
        outSize = total > size ? size : total;                                                                         //
        if (outSize > 0) {                                                                                             //
          outputBuffer = Buffer.concat(bufferList, outSize);                                                           //
          this.push(outputBuffer);                                                                                     //
          total -= outSize;                                                                                            //
        }                                                                                                              //
        lastBuffer = bufferList.pop();                                                                                 //
        newBuffer = lastBuffer.slice(lastBuffer.length - total);                                                       //
        bufferList = [newBuffer];                                                                                      //
        if (total < size) {                                                                                            //
          return cb();                                                                                                 //
        } else {                                                                                                       //
          return flush.bind(this)(cb);                                                                                 //
        }                                                                                                              //
      };                                                                                                               //
      transform = function(chunk, enc, cb) {                                                                           //
        bufferList.push(chunk);                                                                                        //
        total += chunk.length;                                                                                         //
        if (total < size) {                                                                                            //
          return cb();                                                                                                 //
        } else {                                                                                                       //
          return flush.bind(this)(cb);                                                                                 //
        }                                                                                                              //
      };                                                                                                               //
      return [transform, flush];                                                                                       // 61
    };                                                                                                                 //
    return through2.apply(this, makeFuncs(size));                                                                      // 62
  };                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/gridFS_server.coffee.js                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var dicer, express, fs, grid, gridLocks, mongodb, path,                                                                // 7
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;                                                                                         //
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  mongodb = Npm.require('mongodb');                                                                                    //
  grid = Npm.require('gridfs-locking-stream');                                                                         //
  gridLocks = Npm.require('gridfs-locks');                                                                             //
  fs = Npm.require('fs');                                                                                              //
  path = Npm.require('path');                                                                                          //
  dicer = Npm.require('dicer');                                                                                        //
  express = Npm.require('express');                                                                                    //
  FileCollection = (function(superClass) {                                                                             //
    extend(FileCollection, superClass);                                                                                //
                                                                                                                       //
    function FileCollection(root, options) {                                                                           //
      var indexOptions, ref, ref1, ref2, ref3, ref4, ref5, ref6, ref7, ref8, self;                                     // 20
      this.root = root != null ? root : share.defaultRoot;                                                             //
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (!(this instanceof FileCollection)) {                                                                         //
        return new FileCollection(this.root, options);                                                                 // 21
      }                                                                                                                //
      if (!(this instanceof Mongo.Collection)) {                                                                       //
        throw new Meteor.Error('The global definition of Mongo.Collection has changed since the file-collection package was loaded. Please ensure that any packages that redefine Mongo.Collection are loaded before file-collection.');
      }                                                                                                                //
      if (Mongo.Collection !== Mongo.Collection.prototype.constructor) {                                               //
        throw new Meteor.Error('The global definition of Mongo.Collection has been patched by another package, and the prototype constructor has been left in an inconsistent state. Please see this link for a workaround: https://github.com/vsivsi/meteor-file-sample-app/issues/2#issuecomment-120780592');
      }                                                                                                                //
      if (typeof this.root === 'object') {                                                                             //
        options = this.root;                                                                                           //
        this.root = share.defaultRoot;                                                                                 //
      }                                                                                                                //
      this.chunkSize = (ref = options.chunkSize) != null ? ref : share.defaultChunkSize;                               //
      this.db = Meteor.wrapAsync(mongodb.MongoClient.connect)(process.env.MONGO_URL, {});                              //
      this.lockOptions = {                                                                                             //
        timeOut: (ref1 = (ref2 = options.locks) != null ? ref2.timeOut : void 0) != null ? ref1 : 360,                 //
        lockExpiration: (ref3 = (ref4 = options.locks) != null ? ref4.lockExpiration : void 0) != null ? ref3 : 90,    //
        pollingInterval: (ref5 = (ref6 = options.locks) != null ? ref6.pollingInterval : void 0) != null ? ref5 : 5    //
      };                                                                                                               //
      this.locks = gridLocks.LockCollection(this.db, {                                                                 //
        root: this.root,                                                                                               //
        timeOut: this.lockOptions.timeOut,                                                                             //
        lockExpiration: this.lockOptions.lockExpiration,                                                               //
        pollingInterval: this.lockOptions.pollingInterval                                                              //
      });                                                                                                              //
      this.gfs = new grid(this.db, mongodb, this.root);                                                                //
      this.baseURL = (ref7 = options.baseURL) != null ? ref7 : "/gridfs/" + this.root;                                 //
      if (options.resumable || options.http) {                                                                         //
        share.setupHttpAccess.bind(this)(options);                                                                     //
      }                                                                                                                //
      this.allows = {                                                                                                  //
        read: [],                                                                                                      //
        insert: [],                                                                                                    //
        write: [],                                                                                                     //
        remove: []                                                                                                     //
      };                                                                                                               //
      this.denys = {                                                                                                   //
        read: [],                                                                                                      //
        insert: [],                                                                                                    //
        write: [],                                                                                                     //
        remove: []                                                                                                     //
      };                                                                                                               //
      FileCollection.__super__.constructor.call(this, this.root + '.files', {                                          //
        idGeneration: 'MONGO'                                                                                          //
      });                                                                                                              //
      if (options.resumable) {                                                                                         //
        indexOptions = {};                                                                                             //
        if (typeof options.resumableIndexName === 'string') {                                                          //
          indexOptions.name = options.resumableIndexName;                                                              //
        }                                                                                                              //
        this.db.collection(this.root + ".files").ensureIndex({                                                         //
          'metadata._Resumable.resumableIdentifier': 1,                                                                //
          'metadata._Resumable.resumableChunkNumber': 1,                                                               //
          length: 1                                                                                                    //
        }, indexOptions);                                                                                              //
      }                                                                                                                //
      this.maxUploadSize = (ref8 = options.maxUploadSize) != null ? ref8 : -1;                                         //
      FileCollection.__super__.allow.bind(this)({                                                                      //
        insert: (function(_this) {                                                                                     //
          return function(userId, file) {                                                                              //
            return true;                                                                                               //
          };                                                                                                           //
        })(this),                                                                                                      //
        remove: (function(_this) {                                                                                     //
          return function(userId, file) {                                                                              //
            return true;                                                                                               //
          };                                                                                                           //
        })(this)                                                                                                       //
      });                                                                                                              //
      FileCollection.__super__.deny.bind(this)({                                                                       //
        insert: (function(_this) {                                                                                     //
          return function(userId, file) {                                                                              //
            check(file, {                                                                                              //
              _id: Mongo.ObjectID,                                                                                     //
              length: Match.Where(function(x) {                                                                        //
                check(x, Match.Integer);                                                                               //
                return x === 0;                                                                                        //
              }),                                                                                                      //
              md5: Match.Where(function(x) {                                                                           //
                check(x, String);                                                                                      //
                return x === 'd41d8cd98f00b204e9800998ecf8427e';                                                       //
              }),                                                                                                      //
              uploadDate: Date,                                                                                        //
              chunkSize: Match.Where(function(x) {                                                                     //
                check(x, Match.Integer);                                                                               //
                return x === _this.chunkSize;                                                                          //
              }),                                                                                                      //
              filename: String,                                                                                        //
              contentType: String,                                                                                     //
              aliases: [String],                                                                                       //
              metadata: Object                                                                                         //
            });                                                                                                        //
            if (file.chunkSize !== _this.chunkSize) {                                                                  //
              console.warn("Invalid chunksize");                                                                       //
              return true;                                                                                             // 118
            }                                                                                                          //
            if (share.check_allow_deny.bind(_this)('insert', userId, file)) {                                          //
              return false;                                                                                            // 122
            }                                                                                                          //
            return true;                                                                                               // 124
          };                                                                                                           //
        })(this),                                                                                                      //
        update: (function(_this) {                                                                                     //
          return function(userId, file, fields) {                                                                      //
            return true;                                                                                               // 132
          };                                                                                                           //
        })(this),                                                                                                      //
        remove: (function(_this) {                                                                                     //
          return function(userId, file) {                                                                              //
            return true;                                                                                               // 137
          };                                                                                                           //
        })(this)                                                                                                       //
      });                                                                                                              //
      self = this;                                                                                                     //
      Meteor.server.method_handlers[this._prefix + "remove"] = function(selector) {                                    //
        var file;                                                                                                      // 143
        check(selector, Object);                                                                                       //
        if (!LocalCollection._selectorIsIdPerhapsAsObject(selector)) {                                                 //
          throw new Meteor.Error(403, "Not permitted. Untrusted code may only remove documents by ID.");               // 146
        }                                                                                                              //
        file = self.findOne(selector);                                                                                 //
        if (file) {                                                                                                    //
          if (share.check_allow_deny.bind(self)('remove', this.userId, file)) {                                        //
            return self.remove(file);                                                                                  // 151
          } else {                                                                                                     //
            throw new Meteor.Error(403, "Access denied");                                                              // 153
          }                                                                                                            //
        } else {                                                                                                       //
          return 0;                                                                                                    // 155
        }                                                                                                              //
      };                                                                                                               //
    }                                                                                                                  //
                                                                                                                       //
    FileCollection.prototype.allow = function(allowOptions) {                                                          //
      var func, results, type;                                                                                         // 159
      results = [];                                                                                                    // 159
      for (type in allowOptions) {                                                                                     //
        func = allowOptions[type];                                                                                     //
        if (!(type in this.allows)) {                                                                                  //
          throw new Meteor.Error("Unrecognized allow rule type '" + type + "'.");                                      // 161
        }                                                                                                              //
        if (typeof func !== 'function') {                                                                              //
          throw new Meteor.Error("Allow rule " + type + " must be a valid function.");                                 // 163
        }                                                                                                              //
        results.push(this.allows[type].push(func));                                                                    //
      }                                                                                                                // 159
      return results;                                                                                                  //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.deny = function(denyOptions) {                                                            //
      var func, results, type;                                                                                         // 168
      results = [];                                                                                                    // 168
      for (type in denyOptions) {                                                                                      //
        func = denyOptions[type];                                                                                      //
        if (!(type in this.denys)) {                                                                                   //
          throw new Meteor.Error("Unrecognized deny rule type '" + type + "'.");                                       // 170
        }                                                                                                              //
        if (typeof func !== 'function') {                                                                              //
          throw new Meteor.Error("Deny rule " + type + " must be a valid function.");                                  // 172
        }                                                                                                              //
        results.push(this.denys[type].push(func));                                                                     //
      }                                                                                                                // 168
      return results;                                                                                                  //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.insert = function(file, callback) {                                                       //
      if (file == null) {                                                                                              //
        file = {};                                                                                                     //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      file = share.insert_func(file, this.chunkSize);                                                                  //
      return FileCollection.__super__.insert.call(this, file, callback);                                               //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.update = function(selector, modifier, options, callback) {                                //
      var err;                                                                                                         // 185
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       //
        callback = options;                                                                                            //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (options.upsert != null) {                                                                                    //
        err = new Meteor.Error("Update does not support the upsert option");                                           //
        if (callback != null) {                                                                                        //
          return callback(err);                                                                                        // 192
        } else {                                                                                                       //
          throw err;                                                                                                   // 194
        }                                                                                                              //
      }                                                                                                                //
      if (share.reject_file_modifier(modifier) && !options.force) {                                                    //
        err = new Meteor.Error("Modifying gridFS read-only document elements is a very bad idea!");                    //
        if (callback != null) {                                                                                        //
          return callback(err);                                                                                        // 199
        } else {                                                                                                       //
          throw err;                                                                                                   // 201
        }                                                                                                              //
      } else {                                                                                                         //
        return FileCollection.__super__.update.call(this, selector, modifier, options, callback);                      //
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.upsert = function(selector, modifier, options, callback) {                                //
      var err;                                                                                                         // 206
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       //
        callback = options;                                                                                            //
      }                                                                                                                //
      err = new Meteor.Error("File Collections do not support 'upsert'");                                              //
      if (callback != null) {                                                                                          //
        return callback(err);                                                                                          //
      } else {                                                                                                         //
        throw err;                                                                                                     // 212
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.upsertStream = function(file, options, callback) {                                        //
      var cbCalled, found, mods, writeStream;                                                                          // 215
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       //
        callback = options;                                                                                            //
        options = {};                                                                                                  //
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             //
      cbCalled = false;                                                                                                //
      mods = {};                                                                                                       //
      if (file.filename != null) {                                                                                     //
        mods.filename = file.filename;                                                                                 //
      }                                                                                                                //
      if (file.aliases != null) {                                                                                      //
        mods.aliases = file.aliases;                                                                                   //
      }                                                                                                                //
      if (file.contentType != null) {                                                                                  //
        mods.contentType = file.contentType;                                                                           //
      }                                                                                                                //
      if (file.metadata != null) {                                                                                     //
        mods.metadata = file.metadata;                                                                                 //
      }                                                                                                                //
      if (options.autoRenewLock == null) {                                                                             //
        options.autoRenewLock = true;                                                                                  //
      }                                                                                                                //
      if (options.mode === 'w+') {                                                                                     //
        throw new Meteor.Error("The ability to append file data in upsertStream() was removed in version 1.0.0");      // 229
      }                                                                                                                //
      if (file._id) {                                                                                                  //
        found = this.findOne({                                                                                         //
          _id: file._id                                                                                                //
        });                                                                                                            //
      }                                                                                                                //
      if (!(file._id && found)) {                                                                                      //
        file._id = this.insert(mods);                                                                                  //
      } else if (Object.keys(mods).length > 0) {                                                                       //
        this.update({                                                                                                  //
          _id: file._id                                                                                                //
        }, {                                                                                                           //
          $set: mods                                                                                                   //
        });                                                                                                            //
      }                                                                                                                //
      writeStream = Meteor.wrapAsync(this.gfs.createWriteStream.bind(this.gfs))({                                      //
        root: this.root,                                                                                               //
        _id: mongodb.ObjectID("" + file._id),                                                                          //
        mode: 'w',                                                                                                     //
        timeOut: this.lockOptions.timeOut,                                                                             //
        lockExpiration: this.lockOptions.lockExpiration,                                                               //
        pollingInterval: this.lockOptions.pollingInterval                                                              //
      });                                                                                                              //
      if (writeStream) {                                                                                               //
        if (options.autoRenewLock) {                                                                                   //
          writeStream.on('expires-soon', (function(_this) {                                                            //
            return function() {                                                                                        //
              return writeStream.renewLock(function(e, d) {                                                            //
                if (e || !d) {                                                                                         //
                  return console.warn("Automatic Write Lock Renewal Failed: " + file._id, e);                          //
                }                                                                                                      //
              });                                                                                                      //
            };                                                                                                         //
          })(this));                                                                                                   //
        }                                                                                                              //
        if (callback != null) {                                                                                        //
          writeStream.on('close', function(retFile) {                                                                  //
            if (retFile) {                                                                                             //
              retFile._id = new Mongo.ObjectID(retFile._id.toHexString());                                             //
              return callback(null, retFile);                                                                          //
            }                                                                                                          //
          });                                                                                                          //
          writeStream.on('error', function(err) {                                                                      //
            return callback(err);                                                                                      //
          });                                                                                                          //
        }                                                                                                              //
        return writeStream;                                                                                            // 264
      }                                                                                                                //
      return null;                                                                                                     // 266
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.findOneStream = function(selector, options, callback) {                                   //
      var file, opts, range, readStream, ref, ref1, ref2, ref3;                                                        // 269
      if (options == null) {                                                                                           //
        options = {};                                                                                                  //
      }                                                                                                                //
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      if ((callback == null) && typeof options === 'function') {                                                       //
        callback = options;                                                                                            //
        options = {};                                                                                                  //
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             //
      opts = {};                                                                                                       //
      if (options.sort != null) {                                                                                      //
        opts.sort = options.sort;                                                                                      //
      }                                                                                                                //
      if (options.skip != null) {                                                                                      //
        opts.skip = options.skip;                                                                                      //
      }                                                                                                                //
      file = this.findOne(selector, opts);                                                                             //
      if (file) {                                                                                                      //
        if (options.autoRenewLock == null) {                                                                           //
          options.autoRenewLock = true;                                                                                //
        }                                                                                                              //
        range = {                                                                                                      //
          start: (ref = (ref1 = options.range) != null ? ref1.start : void 0) != null ? ref : 0,                       //
          end: (ref2 = (ref3 = options.range) != null ? ref3.end : void 0) != null ? ref2 : file.length - 1            //
        };                                                                                                             //
        readStream = Meteor.wrapAsync(this.gfs.createReadStream.bind(this.gfs))({                                      //
          root: this.root,                                                                                             //
          _id: mongodb.ObjectID("" + file._id),                                                                        //
          timeOut: this.lockOptions.timeOut,                                                                           //
          lockExpiration: this.lockOptions.lockExpiration,                                                             //
          pollingInterval: this.lockOptions.pollingInterval,                                                           //
          range: {                                                                                                     //
            startPos: range.start,                                                                                     //
            endPos: range.end                                                                                          //
          }                                                                                                            //
        });                                                                                                            //
        if (readStream) {                                                                                              //
          if (options.autoRenewLock) {                                                                                 //
            readStream.on('expires-soon', (function(_this) {                                                           //
              return function() {                                                                                      //
                return readStream.renewLock(function(e, d) {                                                           //
                  if (e || !d) {                                                                                       //
                    return console.warn("Automatic Read Lock Renewal Failed: " + file._id, e);                         //
                  }                                                                                                    //
                });                                                                                                    //
              };                                                                                                       //
            })(this));                                                                                                 //
          }                                                                                                            //
          if (callback != null) {                                                                                      //
            readStream.on('close', function() {                                                                        //
              return callback(null, file);                                                                             //
            });                                                                                                        //
            readStream.on('error', function(err) {                                                                     //
              return callback(err);                                                                                    //
            });                                                                                                        //
          }                                                                                                            //
          return readStream;                                                                                           // 309
        }                                                                                                              //
      }                                                                                                                //
      return null;                                                                                                     // 311
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.remove = function(selector, callback) {                                                   //
      var err, ret;                                                                                                    // 314
      if (callback == null) {                                                                                          //
        callback = void 0;                                                                                             //
      }                                                                                                                //
      callback = share.bind_env(callback);                                                                             //
      if (selector != null) {                                                                                          //
        ret = 0;                                                                                                       //
        this.find(selector).forEach((function(_this) {                                                                 //
          return function(file) {                                                                                      //
            var res;                                                                                                   // 318
            res = Meteor.wrapAsync(_this.gfs.remove.bind(_this.gfs))({                                                 //
              _id: mongodb.ObjectID("" + file._id),                                                                    //
              root: _this.root,                                                                                        //
              timeOut: _this.lockOptions.timeOut,                                                                      //
              lockExpiration: _this.lockOptions.lockExpiration,                                                        //
              pollingInterval: _this.lockOptions.pollingInterval                                                       //
            });                                                                                                        //
            return ret += res ? 1 : 0;                                                                                 //
          };                                                                                                           //
        })(this));                                                                                                     //
        (callback != null) && callback(null, ret);                                                                     //
        return ret;                                                                                                    // 326
      } else {                                                                                                         //
        err = new Meteor.Error("Remove with an empty selector is not supported");                                      //
        if (callback != null) {                                                                                        //
          callback(err);                                                                                               //
        } else {                                                                                                       //
          throw err;                                                                                                   // 333
        }                                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.importFile = function(filePath, file, callback) {                                         //
      var readStream, writeStream;                                                                                     // 336
      callback = share.bind_env(callback);                                                                             //
      filePath = path.normalize(filePath);                                                                             //
      if (file == null) {                                                                                              //
        file = {};                                                                                                     //
      }                                                                                                                //
      if (file.filename == null) {                                                                                     //
        file.filename = path.basename(filePath);                                                                       //
      }                                                                                                                //
      readStream = fs.createReadStream(filePath);                                                                      //
      readStream.on('error', share.bind_env(callback));                                                                //
      writeStream = this.upsertStream(file);                                                                           //
      return readStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env(function(d) {
        return callback(null, d);                                                                                      //
      })).on('error', share.bind_env(callback));                                                                       //
    };                                                                                                                 //
                                                                                                                       //
    FileCollection.prototype.exportFile = function(selector, filePath, callback) {                                     //
      var readStream, writeStream;                                                                                     // 348
      callback = share.bind_env(callback);                                                                             //
      filePath = path.normalize(filePath);                                                                             //
      readStream = this.findOneStream(selector);                                                                       //
      writeStream = fs.createWriteStream(filePath);                                                                    //
      return readStream.pipe(writeStream).on('finish', share.bind_env(callback)).on('error', share.bind_env(callback));
    };                                                                                                                 //
                                                                                                                       //
    return FileCollection;                                                                                             //
                                                                                                                       //
  })(Mongo.Collection);                                                                                                //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/resumable_server.coffee.js                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var async, check_order, dicer, express, grid, gridLocks, mongodb, resumable_get_handler, resumable_get_lookup, resumable_post_handler, resumable_post_lookup;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    //
  mongodb = Npm.require('mongodb');                                                                                    //
  grid = Npm.require('gridfs-locking-stream');                                                                         //
  gridLocks = Npm.require('gridfs-locks');                                                                             //
  dicer = Npm.require('dicer');                                                                                        //
  async = Npm.require('async');                                                                                        //
  check_order = function(file, callback) {                                                                             //
    var fileId, lock;                                                                                                  // 20
    fileId = mongodb.ObjectID("" + file.metadata._Resumable.resumableIdentifier);                                      //
    lock = gridLocks.Lock(fileId, this.locks, {}).obtainWriteLock();                                                   //
    lock.on('locked', (function(_this) {                                                                               //
      return function() {                                                                                              //
        var cursor, files;                                                                                             // 24
        files = _this.db.collection(_this.root + ".files");                                                            //
        cursor = files.find({                                                                                          //
          'metadata._Resumable.resumableIdentifier': file.metadata._Resumable.resumableIdentifier,                     //
          length: {                                                                                                    //
            $ne: 0                                                                                                     //
          }                                                                                                            //
        }, {                                                                                                           //
          fields: {                                                                                                    //
            length: 1,                                                                                                 //
            metadata: 1                                                                                                //
          },                                                                                                           //
          sort: {                                                                                                      //
            'metadata._Resumable.resumableChunkNumber': 1                                                              //
          }                                                                                                            //
        });                                                                                                            //
        return cursor.count(function(err, count) {                                                                     //
          var chunks;                                                                                                  // 42
          if (err) {                                                                                                   //
            lock.releaseLock();                                                                                        //
            return callback(err);                                                                                      // 44
          }                                                                                                            //
          if (!(count >= 1)) {                                                                                         //
            cursor.close();                                                                                            //
            lock.releaseLock();                                                                                        //
            return callback();                                                                                         // 49
          }                                                                                                            //
          if (count !== file.metadata._Resumable.resumableTotalChunks) {                                               //
            cursor.close();                                                                                            //
            lock.releaseLock();                                                                                        //
            return callback();                                                                                         // 54
          }                                                                                                            //
          chunks = _this.db.collection(_this.root + ".chunks");                                                        //
          cursor.batchSize(file.metadata._Resumable.resumableTotalChunks + 1);                                         //
          return cursor.toArray(function(err, parts) {                                                                 //
            if (err) {                                                                                                 //
              lock.releaseLock();                                                                                      //
              return callback(err);                                                                                    // 65
            }                                                                                                          //
            return async.eachLimit(parts, 5, function(part, cb) {                                                      //
              var partId, partlock;                                                                                    // 69
              if (err) {                                                                                               //
                console.error("Error from cursor.next()", err);                                                        //
                cb(err);                                                                                               //
              }                                                                                                        //
              if (!part) {                                                                                             //
                return cb(new Meteor.Error("Received null part"));                                                     // 72
              }                                                                                                        //
              partId = mongodb.ObjectID("" + part._id);                                                                //
              partlock = gridLocks.Lock(partId, _this.locks, {}).obtainWriteLock();                                    //
              partlock.on('locked', function() {                                                                       //
                return async.series([                                                                                  //
                  function(cb) {                                                                                       //
                    return chunks.update({                                                                             //
                      files_id: partId,                                                                                //
                      n: 0                                                                                             //
                    }, {                                                                                               //
                      $set: {                                                                                          //
                        files_id: fileId,                                                                              //
                        n: part.metadata._Resumable.resumableChunkNumber - 1                                           //
                      }                                                                                                //
                    }, cb);                                                                                            //
                  }, function(cb) {                                                                                    //
                    return files.remove({                                                                              //
                      _id: partId                                                                                      //
                    }, cb);                                                                                            //
                  }                                                                                                    //
                ], function(err, res) {                                                                                //
                  if (err) {                                                                                           //
                    return cb(err);                                                                                    // 85
                  }                                                                                                    //
                  if (part.metadata._Resumable.resumableChunkNumber !== part.metadata._Resumable.resumableTotalChunks) {
                    partlock.removeLock();                                                                             //
                    return cb();                                                                                       //
                  } else {                                                                                             //
                    return chunks.update({                                                                             //
                      files_id: partId,                                                                                //
                      n: 1                                                                                             //
                    }, {                                                                                               //
                      $set: {                                                                                          //
                        files_id: fileId,                                                                              //
                        n: part.metadata._Resumable.resumableChunkNumber                                               //
                      }                                                                                                //
                    }, function(err, res) {                                                                            //
                      partlock.removeLock();                                                                           //
                      if (err) {                                                                                       //
                        return cb(err);                                                                                // 95
                      }                                                                                                //
                      return cb();                                                                                     //
                    });                                                                                                //
                  }                                                                                                    //
                });                                                                                                    //
              });                                                                                                      //
              partlock.on('timed-out', function() {                                                                    //
                return cb(new Meteor.Error('Partlock timed out!'));                                                    //
              });                                                                                                      //
              partlock.on('expired', function() {                                                                      //
                return cb(new Meteor.Error('Partlock expired!'));                                                      //
              });                                                                                                      //
              return partlock.on('error', function(err) {                                                              //
                console.error("Error obtaining partlock " + part._id, err);                                            //
                return cb(err);                                                                                        //
              });                                                                                                      //
            }, function(err) {                                                                                         //
              var md5Command;                                                                                          // 103
              if (err) {                                                                                               //
                lock.releaseLock();                                                                                    //
                return callback(err);                                                                                  // 105
              }                                                                                                        //
              md5Command = {                                                                                           //
                filemd5: fileId,                                                                                       //
                root: "" + _this.root                                                                                  //
              };                                                                                                       //
              return _this.db.command(md5Command, function(err, results) {                                             //
                if (err) {                                                                                             //
                  lock.releaseLock();                                                                                  //
                  return callback(err);                                                                                // 114
                }                                                                                                      //
                return files.update({                                                                                  //
                  _id: fileId                                                                                          //
                }, {                                                                                                   //
                  $set: {                                                                                              //
                    length: file.metadata._Resumable.resumableTotalSize,                                               //
                    md5: results.md5                                                                                   //
                  }                                                                                                    //
                }, (function(_this) {                                                                                  //
                  return function(err, res) {                                                                          //
                    lock.releaseLock();                                                                                //
                    return callback(err);                                                                              //
                  };                                                                                                   //
                })(this));                                                                                             //
              });                                                                                                      //
            });                                                                                                        //
          });                                                                                                          //
        });                                                                                                            //
      };                                                                                                               //
    })(this));                                                                                                         //
    lock.on('expires-soon', function() {                                                                               //
      return lock.renewLock().once('renewed', function(ld) {                                                           //
        if (!ld) {                                                                                                     //
          return console.warn("Resumable upload lock renewal failed!");                                                //
        }                                                                                                              //
      });                                                                                                              //
    });                                                                                                                //
    lock.on('expired', function() {                                                                                    //
      return callback(new Meteor.Error("File Lock expired"));                                                          //
    });                                                                                                                //
    lock.on('timed-out', function() {                                                                                  //
      return callback(new Meteor.Error("File Lock timed out"));                                                        //
    });                                                                                                                //
    return lock.on('error', function(err) {                                                                            //
      return callback(err);                                                                                            //
    });                                                                                                                //
  };                                                                                                                   //
  resumable_post_lookup = function(params, query, multipart) {                                                         //
    var ref;                                                                                                           // 132
    return {                                                                                                           // 132
      _id: share.safeObjectID(multipart != null ? (ref = multipart.params) != null ? ref.resumableIdentifier : void 0 : void 0)
    };                                                                                                                 //
  };                                                                                                                   //
  resumable_post_handler = function(req, res, next) {                                                                  //
    var chunkQuery, findResult, ref, ref1, resumable, writeStream;                                                     // 137
    if (!((ref = req.multipart) != null ? (ref1 = ref.params) != null ? ref1.resumableIdentifier : void 0 : void 0)) {
      console.error("Missing resumable.js multipart information");                                                     //
      res.writeHead(501, share.defaultResponseHeaders);                                                                //
      res.end();                                                                                                       //
      return;                                                                                                          // 141
    }                                                                                                                  //
    resumable = req.multipart.params;                                                                                  //
    resumable.resumableTotalSize = parseInt(resumable.resumableTotalSize);                                             //
    resumable.resumableTotalChunks = parseInt(resumable.resumableTotalChunks);                                         //
    resumable.resumableChunkNumber = parseInt(resumable.resumableChunkNumber);                                         //
    resumable.resumableChunkSize = parseInt(resumable.resumableChunkSize);                                             //
    resumable.resumableCurrentChunkSize = parseInt(resumable.resumableCurrentChunkSize);                               //
    if (req.maxUploadSize > 0) {                                                                                       //
      if (!(resumable.resumableTotalSize <= req.maxUploadSize)) {                                                      //
        res.writeHead(413, share.defaultResponseHeaders);                                                              //
        res.end();                                                                                                     //
        return;                                                                                                        // 154
      }                                                                                                                //
    }                                                                                                                  //
    if (!((req.gridFS.chunkSize === resumable.resumableChunkSize) && (resumable.resumableChunkNumber <= resumable.resumableTotalChunks) && (resumable.resumableTotalSize / resumable.resumableChunkSize <= resumable.resumableTotalChunks + 1) && (resumable.resumableCurrentChunkSize === resumable.resumableChunkSize) || ((resumable.resumableChunkNumber === resumable.resumableTotalChunks) && (resumable.resumableCurrentChunkSize < 2 * resumable.resumableChunkSize)))) {
      res.writeHead(501, share.defaultResponseHeaders);                                                                //
      res.end();                                                                                                       //
      return;                                                                                                          // 166
    }                                                                                                                  //
    chunkQuery = {                                                                                                     //
      length: resumable.resumableCurrentChunkSize,                                                                     //
      'metadata._Resumable.resumableIdentifier': resumable.resumableIdentifier,                                        //
      'metadata._Resumable.resumableChunkNumber': resumable.resumableChunkNumber                                       //
    };                                                                                                                 //
    findResult = this.findOne(chunkQuery, {                                                                            //
      fields: {                                                                                                        //
        _id: 1                                                                                                         //
      }                                                                                                                //
    });                                                                                                                //
    if (findResult) {                                                                                                  //
      res.writeHead(200, share.defaultResponseHeaders);                                                                //
      return res.end();                                                                                                //
    } else {                                                                                                           //
      req.gridFS.metadata._Resumable = resumable;                                                                      //
      writeStream = this.upsertStream({                                                                                //
        filename: "_Resumable_" + resumable.resumableIdentifier + "_" + resumable.resumableChunkNumber + "_" + resumable.resumableTotalChunks,
        metadata: req.gridFS.metadata                                                                                  //
      });                                                                                                              //
      if (!writeStream) {                                                                                              //
        res.writeHead(404, share.defaultResponseHeaders);                                                              //
        res.end();                                                                                                     //
        return;                                                                                                        // 191
      }                                                                                                                //
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(writeStream).on('close', share.bind_env((function(_this) {
        return function(retFile) {                                                                                     //
          if (retFile) {                                                                                               //
            return check_order.bind(_this)(req.gridFS, function(err) {                                                 //
              if (err) {                                                                                               //
                console.error("Error reassembling chunks of resumable.js upload", err);                                //
                res.writeHead(500, share.defaultResponseHeaders);                                                      //
              } else {                                                                                                 //
                res.writeHead(200, share.defaultResponseHeaders);                                                      //
              }                                                                                                        //
              return res.end();                                                                                        //
            });                                                                                                        //
          } else {                                                                                                     //
            console.error("Missing retFile on pipe close");                                                            //
            res.writeHead(500, share.defaultResponseHeaders);                                                          //
            return res.end();                                                                                          //
          }                                                                                                            //
        };                                                                                                             //
      })(this))).on('error', share.bind_env((function(_this) {                                                         //
        return function(err) {                                                                                         //
          console.error("Piping Error!", err);                                                                         //
          res.writeHead(500, share.defaultResponseHeaders);                                                            //
          return res.end();                                                                                            //
        };                                                                                                             //
      })(this)));                                                                                                      //
    }                                                                                                                  //
  };                                                                                                                   //
  resumable_get_lookup = function(params, query) {                                                                     //
    var q;                                                                                                             // 217
    q = {                                                                                                              //
      _id: share.safeObjectID(query.resumableIdentifier)                                                               //
    };                                                                                                                 //
    return q;                                                                                                          // 218
  };                                                                                                                   //
  resumable_get_handler = function(req, res, next) {                                                                   //
    var chunkQuery, query, result;                                                                                     // 224
    query = req.query;                                                                                                 //
    chunkQuery = {                                                                                                     //
      $or: [                                                                                                           //
        {                                                                                                              //
          _id: share.safeObjectID(query.resumableIdentifier),                                                          //
          length: parseInt(query.resumableTotalSize)                                                                   //
        }, {                                                                                                           //
          length: parseInt(query.resumableCurrentChunkSize),                                                           //
          'metadata._Resumable.resumableIdentifier': query.resumableIdentifier,                                        //
          'metadata._Resumable.resumableChunkNumber': parseInt(query.resumableChunkNumber)                             //
        }                                                                                                              //
      ]                                                                                                                //
    };                                                                                                                 //
    result = this.findOne(chunkQuery, {                                                                                //
      fields: {                                                                                                        //
        _id: 1                                                                                                         //
      }                                                                                                                //
    });                                                                                                                //
    if (result) {                                                                                                      //
      res.writeHead(200, share.defaultResponseHeaders);                                                                //
    } else {                                                                                                           //
      res.writeHead(204, share.defaultResponseHeaders);                                                                //
    }                                                                                                                  //
    return res.end();                                                                                                  //
  };                                                                                                                   //
  share.resumablePaths = [                                                                                             //
    {                                                                                                                  //
      method: 'head',                                                                                                  //
      path: share.resumableBase,                                                                                       //
      lookup: resumable_get_lookup,                                                                                    //
      handler: resumable_get_handler                                                                                   //
    }, {                                                                                                               //
      method: 'post',                                                                                                  //
      path: share.resumableBase,                                                                                       //
      lookup: resumable_post_lookup,                                                                                   //
      handler: resumable_post_handler                                                                                  //
    }, {                                                                                                               //
      method: 'get',                                                                                                   //
      path: share.resumableBase,                                                                                       //
      lookup: resumable_get_lookup,                                                                                    //
      handler: resumable_get_handler                                                                                   //
    }                                                                                                                  //
  ];                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/vsivsi_file-collection/src/http_access_server.coffee.js                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var build_access_point, cookieParser, del, dice_multipart, dicer, express, find_mime_boundary, get, grid, gridLocks, handle_auth, lookup_userId_by_token, mongodb, post, put;
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 7
  express = Npm.require('express');                                                                                    //
  cookieParser = Npm.require('cookie-parser');                                                                         //
  mongodb = Npm.require('mongodb');                                                                                    //
  grid = Npm.require('gridfs-locking-stream');                                                                         //
  gridLocks = Npm.require('gridfs-locks');                                                                             //
  dicer = Npm.require('dicer');                                                                                        //
  find_mime_boundary = function(req) {                                                                                 //
    var RE_BOUNDARY, result;                                                                                           // 17
    RE_BOUNDARY = /^multipart\/.+?(?:; boundary=(?:(?:"(.+)")|(?:([^\s]+))))$/i;                                       //
    result = RE_BOUNDARY.exec(req.headers['content-type']);                                                            //
    return (result != null ? result[1] : void 0) || (result != null ? result[2] : void 0);                             //
  };                                                                                                                   //
  dice_multipart = function(req, res, next) {                                                                          //
    var boundary, count, d, fileName, fileStream, fileType, handleFailure, params, responseSent;                       // 24
    next = share.bind_env(next);                                                                                       //
    if (!(req.method === 'POST' && !req.diced)) {                                                                      //
      next();                                                                                                          //
      return;                                                                                                          // 28
    }                                                                                                                  //
    req.diced = true;                                                                                                  //
    responseSent = false;                                                                                              //
    handleFailure = function(msg, err, retCode) {                                                                      //
      if (err == null) {                                                                                               //
        err = "";                                                                                                      //
      }                                                                                                                //
      if (retCode == null) {                                                                                           //
        retCode = 500;                                                                                                 //
      }                                                                                                                //
      console.error(msg + " \n", err);                                                                                 //
      if (!responseSent) {                                                                                             //
        responseSent = true;                                                                                           //
        res.writeHead(retCode, share.defaultResponseHeaders);                                                          //
        return res.end();                                                                                              //
      }                                                                                                                //
    };                                                                                                                 //
    boundary = find_mime_boundary(req);                                                                                //
    if (!boundary) {                                                                                                   //
      handleFailure("No MIME multipart boundary found for dicer");                                                     //
      return;                                                                                                          // 44
    }                                                                                                                  //
    params = {};                                                                                                       //
    count = 0;                                                                                                         //
    fileStream = null;                                                                                                 //
    fileType = 'text/plain';                                                                                           //
    fileName = 'blob';                                                                                                 //
    d = new dicer({                                                                                                    //
      boundary: boundary                                                                                               //
    });                                                                                                                //
    d.on('part', function(p) {                                                                                         //
      p.on('header', function(header) {                                                                                //
        var RE_FILE, RE_PARAM, data, k, param, re, ref, v;                                                             // 56
        RE_FILE = /^form-data; name="file"; filename="([^"]+)"/;                                                       //
        RE_PARAM = /^form-data; name="([^"]+)"/;                                                                       //
        for (k in header) {                                                                                            // 58
          v = header[k];                                                                                               //
          if (k === 'content-type') {                                                                                  //
            fileType = v;                                                                                              //
          }                                                                                                            //
          if (k === 'content-disposition') {                                                                           //
            if (re = RE_FILE.exec(v)) {                                                                                //
              fileStream = p;                                                                                          //
              fileName = re[1];                                                                                        //
            } else if (param = (ref = RE_PARAM.exec(v)) != null ? ref[1] : void 0) {                                   //
              data = '';                                                                                               //
              count++;                                                                                                 //
              p.on('data', function(d) {                                                                               //
                return data += d.toString();                                                                           //
              });                                                                                                      //
              p.on('end', function() {                                                                                 //
                count--;                                                                                               //
                params[param] = data;                                                                                  //
                if (count === 0 && fileStream) {                                                                       //
                  req.multipart = {                                                                                    //
                    fileStream: fileStream,                                                                            //
                    fileName: fileName,                                                                                //
                    fileType: fileType,                                                                                //
                    params: params                                                                                     //
                  };                                                                                                   //
                  responseSent = true;                                                                                 //
                  return next();                                                                                       //
                }                                                                                                      //
              });                                                                                                      //
            } else {                                                                                                   //
              console.warn("Dicer part", v);                                                                           //
            }                                                                                                          //
          }                                                                                                            //
        }                                                                                                              // 58
        if (count === 0 && fileStream) {                                                                               //
          req.multipart = {                                                                                            //
            fileStream: fileStream,                                                                                    //
            fileName: fileName,                                                                                        //
            fileType: fileType,                                                                                        //
            params: params                                                                                             //
          };                                                                                                           //
          responseSent = true;                                                                                         //
          return next();                                                                                               //
        }                                                                                                              //
      });                                                                                                              //
      return p.on('error', function(err) {                                                                             //
        return handleFailure('Error in Dicer while parsing multipart:', err);                                          //
      });                                                                                                              //
    });                                                                                                                //
    d.on('error', function(err) {                                                                                      //
      return handleFailure('Error in Dicer while parsing parts:', err);                                                //
    });                                                                                                                //
    d.on('finish', function() {                                                                                        //
      if (!fileStream) {                                                                                               //
        return handleFailure("Error in Dicer, no file found in POST");                                                 //
      }                                                                                                                //
    });                                                                                                                //
    return req.pipe(d);                                                                                                //
  };                                                                                                                   //
  post = function(req, res, next) {                                                                                    //
    var stream;                                                                                                        // 113
    if (req.multipart.fileType) {                                                                                      //
      req.gridFS.contentType = req.multipart.fileType;                                                                 //
    }                                                                                                                  //
    if (req.multipart.fileName) {                                                                                      //
      req.gridFS.filename = req.multipart.fileName;                                                                    //
    }                                                                                                                  //
    stream = this.upsertStream(req.gridFS);                                                                            //
    if (stream) {                                                                                                      //
      return req.multipart.fileStream.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {
        if (retFile) {                                                                                                 //
          res.writeHead(200, share.defaultResponseHeaders);                                                            //
          return res.end();                                                                                            //
        }                                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              //
        return res.end();                                                                                              //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(410, share.defaultResponseHeaders);                                                                //
      return res.end();                                                                                                //
    }                                                                                                                  //
  };                                                                                                                   //
  get = function(req, res, next) {                                                                                     //
    var chunksize, end, filename, h, headers, parts, ref, ref1, since, start, statusCode, stream, v;                   // 137
    headers = {};                                                                                                      //
    ref = share.defaultResponseHeaders;                                                                                // 138
    for (h in ref) {                                                                                                   // 138
      v = ref[h];                                                                                                      //
      headers[h] = v;                                                                                                  //
    }                                                                                                                  // 138
    if (req.headers['if-modified-since']) {                                                                            //
      since = Date.parse(req.headers['if-modified-since']);                                                            //
      if (since && req.gridFS.uploadDate && (req.headers['if-modified-since'] === req.gridFS.uploadDate.toUTCString() || since >= req.gridFS.uploadDate.getTime())) {
        res.writeHead(304, headers);                                                                                   //
        res.end();                                                                                                     //
        return;                                                                                                        // 150
      }                                                                                                                //
    }                                                                                                                  //
    if (req.headers['range']) {                                                                                        //
      statusCode = 206;                                                                                                //
      parts = req.headers["range"].replace(/bytes=/, "").split("-");                                                   //
      start = parseInt(parts[0], 10);                                                                                  //
      end = (parts[1] ? parseInt(parts[1], 10) : req.gridFS.length - 1);                                               //
      if ((start < 0) || (end >= req.gridFS.length) || (start > end) || isNaN(start) || isNaN(end)) {                  //
        headers['Content-Range'] = 'bytes ' + '*/' + req.gridFS.length;                                                //
        res.writeHead(416, headers);                                                                                   //
        res.end();                                                                                                     //
        return;                                                                                                        // 167
      }                                                                                                                //
      chunksize = (end - start) + 1;                                                                                   //
      headers['Content-Range'] = 'bytes ' + start + '-' + end + '/' + req.gridFS.length;                               //
      headers['Accept-Ranges'] = 'bytes';                                                                              //
      headers['Content-Type'] = req.gridFS.contentType;                                                                //
      headers['Content-Length'] = chunksize;                                                                           //
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  //
      if (req.method !== 'HEAD') {                                                                                     //
        stream = this.findOneStream({                                                                                  //
          _id: req.gridFS._id                                                                                          //
        }, {                                                                                                           //
          range: {                                                                                                     //
            start: start,                                                                                              //
            end: end                                                                                                   //
          }                                                                                                            //
        });                                                                                                            //
      }                                                                                                                //
    } else {                                                                                                           //
      statusCode = 200;                                                                                                //
      headers['Content-Type'] = req.gridFS.contentType;                                                                //
      headers['Content-MD5'] = req.gridFS.md5;                                                                         //
      headers['Content-Length'] = req.gridFS.length;                                                                   //
      headers['Last-Modified'] = req.gridFS.uploadDate.toUTCString();                                                  //
      if (req.method !== 'HEAD') {                                                                                     //
        stream = this.findOneStream({                                                                                  //
          _id: req.gridFS._id                                                                                          //
        });                                                                                                            //
      }                                                                                                                //
    }                                                                                                                  //
    if ((req.query.download && req.query.download.toLowerCase() === 'true') || req.query.filename) {                   //
      filename = encodeURIComponent((ref1 = req.query.filename) != null ? ref1 : req.gridFS.filename);                 //
      headers['Content-Disposition'] = "attachment; filename=\"" + filename + "\"; filename*=UTF-8''" + filename;      //
    }                                                                                                                  //
    if (req.query.cache && !isNaN(parseInt(req.query.cache))) {                                                        //
      headers['Cache-Control'] = "max-age=" + parseInt(req.query.cache) + ", private";                                 //
    }                                                                                                                  //
    if (req.method === 'HEAD') {                                                                                       //
      res.writeHead(204, headers);                                                                                     //
      res.end();                                                                                                       //
      return;                                                                                                          // 217
    }                                                                                                                  //
    if (stream) {                                                                                                      //
      res.writeHead(statusCode, headers);                                                                              //
      return stream.pipe(res).on('close', function() {                                                                 //
        return res.end();                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              //
        return res.end(err);                                                                                           //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(410, share.defaultResponseHeaders);                                                                //
      return res.end();                                                                                                //
    }                                                                                                                  //
  };                                                                                                                   //
  put = function(req, res, next) {                                                                                     //
    var stream;                                                                                                        // 241
    if (req.headers['content-type']) {                                                                                 //
      req.gridFS.contentType = req.headers['content-type'];                                                            //
    }                                                                                                                  //
    stream = this.upsertStream(req.gridFS);                                                                            //
    if (stream) {                                                                                                      //
      return req.pipe(share.streamChunker(this.chunkSize)).pipe(stream).on('close', function(retFile) {                //
        if (retFile) {                                                                                                 //
          res.writeHead(200, share.defaultResponseHeaders);                                                            //
          return res.end();                                                                                            //
        } else {                                                                                                       //
                                                                                                                       // 249
        }                                                                                                              //
      }).on('error', function(err) {                                                                                   //
        res.writeHead(500, share.defaultResponseHeaders);                                                              //
        return res.end(err);                                                                                           //
      });                                                                                                              //
    } else {                                                                                                           //
      res.writeHead(404, share.defaultResponseHeaders);                                                                //
      return res.end(req.url + " Not found!");                                                                         //
    }                                                                                                                  //
  };                                                                                                                   //
  del = function(req, res, next) {                                                                                     //
    this.remove(req.gridFS);                                                                                           //
    res.writeHead(204, share.defaultResponseHeaders);                                                                  //
    return res.end();                                                                                                  //
  };                                                                                                                   //
  build_access_point = function(http) {                                                                                //
    var i, len, r;                                                                                                     // 278
    for (i = 0, len = http.length; i < len; i++) {                                                                     // 278
      r = http[i];                                                                                                     //
      if (r.method.toUpperCase() === 'POST') {                                                                         //
        this.router.post(r.path, dice_multipart);                                                                      //
      }                                                                                                                //
      this.router[r.method](r.path, (function(_this) {                                                                 //
        return function(r) {                                                                                           //
          return function(req, res, next) {                                                                            //
            var lookup, opts, ref, ref1, ref2;                                                                         // 289
            if (((ref = req.params) != null ? ref._id : void 0) != null) {                                             //
              req.params._id = share.safeObjectID(req.params._id);                                                     //
            }                                                                                                          //
            if (((ref1 = req.query) != null ? ref1._id : void 0) != null) {                                            //
              req.query._id = share.safeObjectID(req.query._id);                                                       //
            }                                                                                                          //
            lookup = (ref2 = r.lookup) != null ? ref2.bind(_this)(req.params || {}, req.query || {}, req.multipart) : void 0;
            if (lookup == null) {                                                                                      //
              res.writeHead(500, share.defaultResponseHeaders);                                                        //
              res.end();                                                                                               //
            } else {                                                                                                   //
              req.gridFS = _this.findOne(lookup);                                                                      //
              if (!req.gridFS) {                                                                                       //
                res.writeHead(404, share.defaultResponseHeaders);                                                      //
                res.end();                                                                                             //
                return;                                                                                                // 305
              }                                                                                                        //
              switch (req.method) {                                                                                    // 308
                case 'HEAD':                                                                                           // 308
                case 'GET':                                                                                            // 308
                  if (!share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS)) {                     //
                    res.writeHead(403, share.defaultResponseHeaders);                                                  //
                    res.end();                                                                                         //
                    return;                                                                                            // 313
                  }                                                                                                    //
                  break;                                                                                               // 309
                case 'POST':                                                                                           // 308
                case 'PUT':                                                                                            // 308
                  req.maxUploadSize = _this.maxUploadSize;                                                             //
                  if (!(opts = share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS))) {           //
                    res.writeHead(403, share.defaultResponseHeaders);                                                  //
                    res.end();                                                                                         //
                    return;                                                                                            // 319
                  }                                                                                                    //
                  if ((opts.maxUploadSize != null) && typeof opts.maxUploadSize === 'number') {                        //
                    req.maxUploadSize = opts.maxUploadSize;                                                            //
                  }                                                                                                    //
                  if (req.maxUploadSize > 0) {                                                                         //
                    if (req.headers['content-length'] == null) {                                                       //
                      res.writeHead(411, share.defaultResponseHeaders);                                                //
                      res.end();                                                                                       //
                      return;                                                                                          // 326
                    }                                                                                                  //
                    if (!(parseInt(req.headers['content-length']) <= req.maxUploadSize)) {                             //
                      res.writeHead(413, share.defaultResponseHeaders);                                                //
                      res.end();                                                                                       //
                      return;                                                                                          // 330
                    }                                                                                                  //
                  }                                                                                                    //
                  break;                                                                                               // 314
                case 'DELETE':                                                                                         // 308
                  if (!share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS)) {                   //
                    res.writeHead(403, share.defaultResponseHeaders);                                                  //
                    res.end();                                                                                         //
                    return;                                                                                            // 335
                  }                                                                                                    //
                  break;                                                                                               // 331
                case 'OPTIONS':                                                                                        // 308
                  if (!(share.check_allow_deny.bind(_this)('read', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('write', req.meteorUserId, req.gridFS) || share.check_allow_deny.bind(_this)('remove', req.meteorUserId, req.gridFS))) {
                    res.writeHead(403, share.defaultResponseHeaders);                                                  //
                    res.end();                                                                                         //
                    return;                                                                                            // 342
                  }                                                                                                    //
                  break;                                                                                               // 336
                default:                                                                                               // 308
                  res.writeHead(500, share.defaultResponseHeaders);                                                    //
                  res.end();                                                                                           //
                  return;                                                                                              // 346
              }                                                                                                        // 308
              return next();                                                                                           //
            }                                                                                                          //
          };                                                                                                           //
        };                                                                                                             //
      })(this)(r));                                                                                                    //
      if (typeof r.handler === 'function') {                                                                           //
        this.router[r.method](r.path, r.handler.bind(this));                                                           //
      }                                                                                                                //
    }                                                                                                                  // 278
    return this.router.route('/*').all(function(req, res, next) {                                                      //
      if (req.gridFS != null) {                                                                                        //
        next();                                                                                                        //
      } else {                                                                                                         //
        res.writeHead(404, share.defaultResponseHeaders);                                                              //
        return res.end();                                                                                              //
      }                                                                                                                //
    }).head(get.bind(this)).get(get.bind(this)).put(put.bind(this)).post(post.bind(this))["delete"](del.bind(this)).all(function(req, res, next) {
      res.writeHead(500, share.defaultResponseHeaders);                                                                //
      return res.end();                                                                                                //
    });                                                                                                                //
  };                                                                                                                   //
  lookup_userId_by_token = function(authToken) {                                                                       //
    var ref, userDoc;                                                                                                  // 375
    userDoc = (ref = Meteor.users) != null ? ref.findOne({                                                             //
      'services.resume.loginTokens': {                                                                                 //
        $elemMatch: {                                                                                                  //
          hashedToken: typeof Accounts !== "undefined" && Accounts !== null ? Accounts._hashLoginToken(authToken) : void 0
        }                                                                                                              //
      }                                                                                                                //
    }) : void 0;                                                                                                       //
    return (userDoc != null ? userDoc._id : void 0) || null;                                                           // 379
  };                                                                                                                   //
  handle_auth = function(req, res, next) {                                                                             //
    var ref, ref1;                                                                                                     // 385
    if (req.meteorUserId == null) {                                                                                    //
      if (((ref = req.headers) != null ? ref['x-auth-token'] : void 0) != null) {                                      //
        req.meteorUserId = lookup_userId_by_token(req.headers['x-auth-token']);                                        //
      } else if (((ref1 = req.cookies) != null ? ref1['X-Auth-Token'] : void 0) != null) {                             //
        req.meteorUserId = lookup_userId_by_token(req.cookies['X-Auth-Token']);                                        //
      } else {                                                                                                         //
        req.meteorUserId = null;                                                                                       //
      }                                                                                                                //
    }                                                                                                                  //
    return next();                                                                                                     //
  };                                                                                                                   //
  share.setupHttpAccess = function(options) {                                                                          //
    var h, i, len, otherHandlers, r, ref, ref1, resumableHandlers;                                                     // 400
    if (options.resumable) {                                                                                           //
      if (options.http == null) {                                                                                      //
        options.http = [];                                                                                             //
      }                                                                                                                //
      resumableHandlers = [];                                                                                          //
      otherHandlers = [];                                                                                              //
      ref = options.http;                                                                                              // 404
      for (i = 0, len = ref.length; i < len; i++) {                                                                    // 404
        h = ref[i];                                                                                                    //
        if (h.path === share.resumableBase) {                                                                          //
          resumableHandlers.push(h);                                                                                   //
        } else {                                                                                                       //
          otherHandlers.push(h);                                                                                       //
        }                                                                                                              //
      }                                                                                                                // 404
      resumableHandlers = resumableHandlers.concat(share.resumablePaths);                                              //
      options.http = resumableHandlers.concat(otherHandlers);                                                          //
    }                                                                                                                  //
    if (((ref1 = options.http) != null ? ref1.length : void 0) > 0) {                                                  //
      r = express.Router();                                                                                            //
      r.use(express.query());                                                                                          //
      r.use(cookieParser());                                                                                           //
      r.use(handle_auth);                                                                                              //
      WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(r));                                                  //
      this.router = express.Router();                                                                                  //
      build_access_point.bind(this)(options.http, this.router);                                                        //
      return WebApp.rawConnectHandlers.use(this.baseURL, share.bind_env(this.router));                                 //
    }                                                                                                                  //
  };                                                                                                                   //
}                                                                                                                      //
                                                                                                                       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['vsivsi:file-collection'] = {}, {
  FileCollection: FileCollection
});

})();

//# sourceMappingURL=vsivsi_file-collection.js.map
