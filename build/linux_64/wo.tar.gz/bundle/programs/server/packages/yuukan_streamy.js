(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var _ = Package.underscore._;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var check = Package.check.check;
var Match = Package.check.Match;
var ReactiveVar = Package['reactive-var'].ReactiveVar;

/* Package-scope variables */
var Streamy;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/namespaces.js                                                                      //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
Streamy = {};
Streamy.BroadCasts = {};
Streamy.DirectMessages = {};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/core/core.js                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var handlers = {};
var connect_handlers = [];
var disconnect_handlers = [];

// -------------------------------------------------------------------------- //
// --------------------- Overriden by client/server ------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Init streamy, attach base handlers in client/server
 */
Streamy.init = function() { };

/**
 * Write the message on the socket
 * @param {String} data Data stringified
 * @param {Object} to (Server side) Which socket should we use
 */
Streamy._write = function(data, to) { };

// -------------------------------------------------------------------------- //
// ------------------------------ Accessors --------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Retrieve connect handlers
 */
Streamy.connectHandlers = function() {
  return connect_handlers;
};

/**
 * Retrieve disconnect handlers
 */
Streamy.disconnectHandlers = function() {
  return disconnect_handlers;
};

/**
 * Retrieve all handlers or the one for the given message
 * @param {String} message Optional, if defined, returns the handler for this specific messsage
 */
Streamy.handlers = function(message) {
  if(message) {
    var handler = handlers[message];
    if(!handler)
      handler = function() {};

    return handler;
  }

  return handlers;
};

// -------------------------------------------------------------------------- //
// -------------------------- Common interface ------------------------------ //
// -------------------------------------------------------------------------- //

/**
 * Apply a specific prefix to avoid name conflicts
 * @param {String} value Base value
 * @return {String} The base value prefixed
 */
Streamy._applyPrefix = function(value) {
  return 'streamy$' + value;
};

/**
 * Register an handler for the given message type
 * @param {String} message Message name to handle
 * @param {Function} callback Callback to call when this message is received
 */
Streamy.on = function(message, callback) {
  message = Streamy._applyPrefix(message);
  handlers[message] = Meteor.bindEnvironment(callback);
};

/**
 * Un-register an handler for the given message type
 * @param {String} message Message name to handle
 */
Streamy.off = function(message) {
  message = Streamy._applyPrefix(message);
  delete handlers[message];
};

/**
 * Adds an handler for the connection success
 * @param {Function} callback Callback to call upon connection
 */
Streamy.onConnect = function(callback) {
  connect_handlers.push(Meteor.bindEnvironment(callback));
};

/**
 * Adds an handler for the disconnection
 * @param {Function} callback Callback to call upon disconnect
 */
Streamy.onDisconnect = function(callback) {
  disconnect_handlers.push(Meteor.bindEnvironment(callback));
};

/**
 * Emits a message with the given name and associated data
 * @param {String} message Message name to emit
 * @param {Object} data Data to send
 * @param {Socket} to (Server side only) which socket we should use
 */
Streamy.emit = function(message, data, to) {
  data = data || {};
  message = Streamy._applyPrefix(message);

  check(message, String);
  check(data, Object);

  data.msg = message;

  Streamy._write(JSON.stringify(data), to);
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/direct_messages/direct_messages.js                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// --------------------- Overriden by client/server ------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Gets the wrapper for the emit returned by Streamy.sessions(sid)
 * @param {String|Array} sid Session id(s)
 * @return  {Function}  Function which will be called by emit on the session
 */
Streamy._sessionsEmit = function(sid) { };

/**
 * Gets the wrapper for the emit returned by Streamy.sessionsForUsers(sid)
 * @param {String|Array} uid User id(s)
 * @return  {Function}  Function which will be called by emit on the session
 */
Streamy._sessionsForUsersEmit = function(uid) { };

// -------------------------------------------------------------------------- //
// -------------------------- Common interface ------------------------------ //
// -------------------------------------------------------------------------- //

/**
 * Returns an object for the targetted session id(s) which contains an emit method
 * @param {String|Array} sid Session id(s)
 * @return  {Object}  Object with an emit function
 */
Streamy.sessions = function(sid) {
  return {
    emit: Streamy._sessionsEmit(sid)
  };
};

/**
 * Returns an object for the targetted user id(s) which contains an emit method
 * @param {String|Array} uid User id(s)
 * @return  {Object}  Object with an emit function
 */
Streamy.sessionsForUsers = function(uid) {
  return {
    emit: Streamy._sessionsForUsersEmit(uid)
  }
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/broadcasts/broadcasts.js                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// --------------------- Overriden by client/server ------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Returns an object for the targetted session id which contains an emit method
 * @param {String} message Message to emit
 * @param {Object} data Data to send
 * @param {Array|String} except Which sid should we exclude from the broadcast message
 */
Streamy.broadcast = function(message, data, except) { };
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/utils/utils.js                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// --------------------- Overriden by client/server ------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Retrieve the connection id
 * @param  {Socket} socket On server, should be given to determine the concerned connection
 * @return {String}        The connection id
 */
Streamy.id = function(socket) {};

/**
 * Retrieve the user id
 * @param {Socket} socket On server, should be given to determine the concerned user
 */
Streamy.userId = function(socket) {};

/**
 * Retrieve the user
 * @param {Socket} socket On server, should be given to determine the concerned user
 */
Streamy.user = function(socket) {};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/multiple_servers/connection.js                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * Streamy Connection constructor: init a DDP connection to work with Streamy
 * @param {Object} DDP connection created by DDP.connect
 */

Streamy.Connection = function(connection) {
  var self = this;
  var _handlers = {};
  var _connectHandlers = [];
  var _disconnectHandlers = [];
  var _connection = connection;

  // XXX: Are there any ways to make sure connection is created by DDP.connect?
  if (!connection ||
    typeof connection !== 'object' ||
    typeof connection._stream !== 'object' ||
    typeof connection._stream.on !== 'function' ||
    typeof connection._stream.status !== 'function'
  ) {
    throw new Meteor.Error('WrongType', 'Connection has to be created by DDP.connect');
  }

  self._getConnection = function _getConnection() {
    return _connection;
  };

  self._setHandler = function _setHandler(msg, callback) {
    _handlers[msg] = callback;
  };

  self._deleteHandler = function _deleteHandler(msg) {
    delete _handlers[msg];
  };

  self._deleteHandlers = function _deleteHandlers() {
    for (var func in _handlers) {
      if (_handlers.hasOwnProperty(func)) {
        delete _handlers[func];
      }
    }
  };

  self._addConnectHandlers = function _addConnectHandlers(callback) {
    _connectHandlers.push(callback);
  };

  self._addDisconnectHandlers = function _addDisconnectHandlers(callback) {
    _disconnectHandlers.push(callback);
  };

  _connection._stream.on('disconnect', function onClose() {
    // If it was previously connected, call disconnect handlers
    if(_connection._stream.status().connected) {
      _.each(_disconnectHandlers, function forEachDisconnectHandler(cb) {
        cb.call(self);
      });
    }
  });

  // Attach message handlers
  _connection._stream.on('message', function onMessage(data) {

    // Parse the message
    var parsed_data = JSON.parse(data);

    // Retrieve the msg value
    var msg = parsed_data.msg;

    // And dismiss it
    delete parsed_data.msg;

    // If its the connected message
    if(msg === 'connected') {
      // Call each handlers
      _.each(_connectHandlers, function forEachConnectHandler(cb) {
        cb.call(self);
      });
    } else if(msg) {
      // Else, call the appropriate handler
      var f = _handlers[msg] || function() {};
      f.call(self, parsed_data);
    }
  });
};

/**
 * Register an handler for the given message type
 * @param {String} message Message name to handle
 * @param {Function} callback Callback to call when this message is received
 */
Streamy.Connection.prototype.on = function(message, callback) {
  check(message, String);

  if (typeof callback !== 'function') {
    throw new Meteor.Error('WrongType', 'Message handler has to be a function');
  }

  message = Streamy._applyPrefix(message);
  this._setHandler(message, Meteor.bindEnvironment(callback));
};

/**
 * Un-register an handler for the given message type
 * @param {String} message Message name to handle
 */

Streamy.Connection.prototype.off = function(message) {
  check(message, String);

  message = Streamy._applyPrefix(message);
  this._deleteHandler(message);
};

/**
 * Un-register handlers of all messages
 */

Streamy.Connection.prototype.close = function() {
  this._deleteHandlers();
};

/**
 * Emits a message with the given name and associated data
 * @param {String} message Message name to emit
 * @param {Object} data Data to send
 */
Streamy.Connection.prototype.emit = function(message, data) {
  data = data || {};

  check(message, String);
  check(data, Object);

  message = Streamy._applyPrefix(message);

  data.msg = message;
  this._getConnection()._stream.send(JSON.stringify(data));
};

/**
 * Adds an handler for the connection success
 * @param {Function} callback Callback to call upon connection
 */
Streamy.Connection.prototype.onConnect = function(callback) {

  if (typeof callback !== 'function') {
    throw new Meteor.Error('WrongType', 'Connect handler has to be a function');
  }

  this._addConnectHandlers(Meteor.bindEnvironment(callback));
};

/**
 * Adds an handler for the disconnection
 * @param {Function} callback Callback to call upon disconnect
 */

Streamy.Connection.prototype.onDisconnect = function(callback) {

  if (typeof callback !== 'function') {
    throw new Meteor.Error('WrongType', 'Disconnect handler has to be a function');
  }

  this._addDisconnectHandlers(Meteor.bindEnvironment(callback));
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/core/core_server.js                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
var sessions = {};

// -------------------------------------------------------------------------- //
// ------------------------------- Accessors -------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Contains reactive variables for each connection id/user id
 * @type {Object}
 */
Streamy._usersId = {};

/**
 * Retrieve server connected sockets or a subset
 * @param {String|Array} sid Optional, socket id or ids to retrieve
 * @return  {Object} If sid is provided, it will returns an object with a send method and _sockets array of sockets, else, it will returns all sockets
 */
Streamy.sockets = function(sid) {

  if(sid) {
    sid = _.isArray(sid) ? sid : [sid];
    var sockets = [];

    _.each(sid, function(session_id) {
      var sock = sessions[session_id];

      if(sock)
        sockets.push(sock);
    });

    return {
      _sockets: sockets,
      send: function(data) {
        _.each(sockets, function(socket) {
          socket.send(data);
        });
      }
    }
  }

  return sessions;
};

/**
 * Retrieve server connected sockets or a subset
 * @param {String|Array} uid Optional, user id or ids to retrieve
 * @return  {Object} If uid is provided, it will returns an object with a send method and _sockets array of sockets, else, it will returns all sockets
 */
Streamy.socketsForUsers = function(uid) {

  if(uid) {
    uid = _.isArray(uid) ? uid : [uid];

    var sockets = _.filter(Streamy.sockets(), function(socket) {
      return uid.indexOf(socket._meteorSession.userId) !== -1;
    });

    return {
      _sockets: sockets,
      send: function(data) {
        _.each(sockets, function(socket) {
          socket.send(data);
        });
      }
    }
  }

  return sessions;

};

// -------------------------------------------------------------------------- //
// ------------------------------- Overrides -------------------------------- //
// -------------------------------------------------------------------------- //

Streamy.init = function() {
  var self = this;

  // If accounts package is installed, register for successful login attempts
  if(typeof(Accounts) !== 'undefined' ) {
    Accounts.onLogin(function onLoggedIn(data) {
      Streamy._usersId[data.connection.id].set(data.user._id);
    });
  }

  // When a new connection has been received
  Meteor.default_server.stream_server.register(function onNewConnected(socket) {
    var handlers_registered = false;

    // On closed, call disconnect handlers
    socket.on('close', function onSocketClosed() {
      if(handlers_registered) {
        var sid = Streamy.id(socket);

        delete sessions[sid];
        delete Streamy._usersId[sid];

        _.each(self.disconnectHandlers(), function forEachDisconnectHandler(cb) {
          cb.call(self, socket);
        });
      }
    });

    // This little trick is used to register protocol handlers on the
    // socket._meteorSession object, so we need it to be set
    socket.on('data', function onSocketData(raw_data) {

      // Since we doesn't have a Accounts.onLogout callback, we must use this little trick, will be replaced when a proper callback is added
      if(JSON.parse(raw_data).method === 'logout' && socket.__sid) {
        Streamy._usersId[Streamy.id(socket)].set(null);
      }

      // Only if the socket as a meteor session
      if(!handlers_registered && socket._meteorSession) {

        // Store the meteorSesion id in an inner property since _meteorSession will be deleted upon socket closed
        socket.__sid = socket._meteorSession.id;

        var sid = Streamy.id(socket);

        handlers_registered = true;

        sessions[sid] = socket;
        Streamy._usersId[sid] = new ReactiveVar(null);

        // Call connection handlers
        _.each(self.connectHandlers(), function forEachConnectHandler(cb) {
          cb.call(self, socket);
        });

        // Add each handler to the list of protocol handlers
        _.each(self.handlers(), function forEachHandler(cb, name) {
          if(!socket._meteorSession.protocol_handlers[name]) {
            socket._meteorSession.protocol_handlers[name] = function onMessage(raw_msg) {
              delete raw_msg.msg; // Remove msg field
              cb.call(self, raw_msg, this.socket);
            };
          }
        });
      }
    });
  });
};

Streamy._write = function(data, to) {
  if(to)
    to.send(data);
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/direct_messages/direct_messages_server.js                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// ------------------------------ Allow/deny -------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Wether or not the direct messages is allowed
 * @param {Object} data Data of the message
 * @param {Socket} from From socket
 * @param {Object} to Special object as returned by Streamy.sockets
 */
Streamy.DirectMessages.allow = function(data, from, to) {
  return true;
};

// -------------------------------------------------------------------------- //
// -------------------------------- Handlers -------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Attach the direct message handler
 * @param {Object} data Data object
 * @param {Socket} from Socket emitter
 */
Streamy.on('__direct__', function(data, from) {

  // Check for sanity
  if(!data.__msg || !data.__data)
    return;

  var to_socks = null;

  if(data.__to_users)
    to_socks = Streamy.socketsForUsers(data.__to_users);
  else if(data.__to)
    to_socks = Streamy.sockets(data.__to);

  if(!to_socks)
    return;

  // Check if the server allows this direct message
  if(!Streamy.DirectMessages.allow(data, from, to_socks))
      return;

  // Attach the sender ID to the inner data
  data.__data.__from = Streamy.id(from);

  // And then emit the message
  Streamy.emit(data.__msg, data.__data, to_socks);
});

// -------------------------------------------------------------------------- //
// ------------------------------- Overrides -------------------------------- //
// -------------------------------------------------------------------------- //

Streamy._sessionsEmit = function(sid) {
  var socket = _.isObject(sid) ? sid : Streamy.sockets(sid);

  return function(msg, data) {
    Streamy.emit(msg, data, socket);
  };
};

Streamy._sessionsForUsersEmit = function(uid) {
  uid = _.isArray(uid) ? uid : [uid];
  var sockets = Streamy.socketsForUsers(uid);

  return function(msg, data) {
    Streamy.emit(msg, data, sockets);
  };
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/broadcasts/broadcasts_server.js                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// ------------------------------ Allow/deny -------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Wether or not the broadcast is allowed
 * @param {Object} data Data of the message
 * @param {Socket} from From socket
 */
Streamy.BroadCasts.allow = function(data, from) {
  return true;
};

// -------------------------------------------------------------------------- //
// -------------------------------- Handlers -------------------------------- //
// -------------------------------------------------------------------------- //

/**
 * Attach the broadcast message handler
 * @param {Object} data Data object
 * @param {Socket} from Socket emitter
 */
Streamy.on('__broadcast__', function(data, from) {

  // Check for sanity
  if(!data.__msg || !data.__data)
    return;

  // Check if the server allows this direct message
  if(!Streamy.BroadCasts.allow(data, from))
      return;

  // Attach the sender ID to the inner data
  data.__data.__from = Streamy.id(from);
  data.__data.__fromUserId = from._meteorSession.userId;

  // And then emit the message
  Streamy.broadcast(data.__msg, data.__data, data.__except);
});

// -------------------------------------------------------------------------- //
// ------------------------------- Overrides -------------------------------- //
// -------------------------------------------------------------------------- //

Streamy.broadcast = function(message, data, except) {
  if(!_.isArray(except))
    except = [except];

  _.each(Streamy.sockets(), function(sock) {
    if(except.indexOf(Streamy.id(sock)) !== -1)
      return;

    Streamy.emit(message, data, sock);
  });
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/utils/utils_server.js                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
// -------------------------------------------------------------------------- //
// ------------------------------- Overrides -------------------------------- //
// -------------------------------------------------------------------------- //

Streamy.id = function(socket) {
  return socket.__sid;
};

Streamy.userId = function(socket) {
  if(!socket)
    throw new Meteor.Error(500, 'You should provides a socket server-side');

  return Streamy._usersId[Streamy.id(socket)].get();
};

Streamy.user = function(socket) {
  if(!Meteor.users)
    throw new Meteor.Error(500, 'Could not retrieve user, is accounts-base installed?');
    
  return Meteor.users.findOne(Streamy.userId(socket));
};

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// packages/yuukan_streamy/lib/startup.js                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
/**
 * When the application starts up, register handlers!
 */
Meteor.startup(function onStartup() {
  Streamy.init();
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['yuukan:streamy'] = {}, {
  Streamy: Streamy
});

})();
