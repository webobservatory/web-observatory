(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var Log = Package.logging.Log;
var Tracker = Package.deps.Tracker;
var Deps = Package.deps.Deps;
var DDP = Package['ddp-client'].DDP;
var DDPServer = Package['ddp-server'].DDPServer;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var Blaze = Package.ui.Blaze;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var Random = Package.random.Random;
var EJSON = Package.ejson.EJSON;
var HTML = Package.htmljs.HTML;

/* Package-scope variables */
var ReactiveTemplates;

(function(){

/////////////////////////////////////////////////////////////////////////////
//                                                                         //
// packages/nicolaslopezj_reactive-templates/packages/nicolaslopezj_reacti //
//                                                                         //
/////////////////////////////////////////////////////////////////////////////
                                                                           //
(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/nicolaslopezj:reactive-templates/templates.js            //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
ReactiveTemplates = {                                                // 1
  _templates: {},                                                    // 2
  _deps: {},                                                         // 3
  _isRequestedDeps: {},                                              // 4
};                                                                   // 5
                                                                     // 6
/**                                                                  // 7
 * We will save all the templates that any component need            // 8
 */                                                                  // 9
ReactiveTemplates.request = function(identifier, defaultTemplate) {  // 10
  check(identifier, String);                                         // 11
  check(defaultTemplate, Match.Optional(String));                    // 12
                                                                     // 13
  if (!_.has(this._deps, identifier)) {                              // 14
    this._deps[identifier] = new Tracker.Dependency;                 // 15
  }                                                                  // 16
                                                                     // 17
  this._deps[identifier] = new Tracker.Dependency;                   // 18
  this._templates[identifier] = defaultTemplate;                     // 19
  if (_.has(this._isRequestedDeps, identifier)) {                    // 20
    this._isRequestedDeps[identifier].changed();                     // 21
  }                                                                  // 22
}                                                                    // 23
                                                                     // 24
/**                                                                  // 25
 * Reactively returns the identifier of the template                 // 26
 */                                                                  // 27
ReactiveTemplates.get = function(identifier) {                       // 28
  if (!_.has(this._deps, identifier)) {                              // 29
    console.warn('Template "' + identifier + '" is not requested');  // 30
    this._deps[identifier] = new Tracker.Dependency;                 // 31
  }                                                                  // 32
                                                                     // 33
  this._deps[identifier].depend();                                   // 34
  return this._templates[identifier];                                // 35
}                                                                    // 36
                                                                     // 37
/**                                                                  // 38
 * Assings a template to a template request                          // 39
 */                                                                  // 40
ReactiveTemplates.set = function(identifier, templateName) {         // 41
  var self = this;                                                   // 42
  Tracker.autorun(function () {                                      // 43
    if (self.isRequested(identifier)) {                              // 44
      self._templates[identifier] = templateName;                    // 45
      self._deps[identifier].changed();                              // 46
    }                                                                // 47
  });                                                                // 48
}                                                                    // 49
                                                                     // 50
/**                                                                  // 51
 * Returns if the template is requested                              // 52
 */                                                                  // 53
ReactiveTemplates.isRequested = function(identifier) {               // 54
  if (!_.has(this._isRequestedDeps, identifier)) {                   // 55
    this._isRequestedDeps[identifier] = new Tracker.Dependency;      // 56
  }                                                                  // 57
  this._isRequestedDeps[identifier].depend();                        // 58
  return _.has(this._deps, identifier);                              // 59
}                                                                    // 60
///////////////////////////////////////////////////////////////////////

}).call(this);

/////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['nicolaslopezj:reactive-templates'] = {}, {
  ReactiveTemplates: ReactiveTemplates
});

})();
