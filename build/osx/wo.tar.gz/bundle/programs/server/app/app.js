var require = meteorInstall({"lib":{"collections":{"declarations":{"_utils.js":["babel-runtime/helpers/typeof",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/_utils.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});                          //
/**                                                                                                                    // 1
 * Created by xgfd on 26/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
//Declare a newe EJSON type @typeName with only one instance @singular                                                 // 5
toEJSONSingularType = function toEJSONSingularType(singleton, typeName) {                                              // 6
                                                                                                                       //
    check(typeof singleton === 'undefined' ? 'undefined' : _typeof(singleton), 'object'); //check(singular, Ojbect) may give expected plain object error
    check(singleton.typeName, undefined);                                                                              // 9
    check(singleton.toJSONValue, undefined);                                                                           // 10
    check(typeName, String);                                                                                           // 11
                                                                                                                       //
    singleton.typeName = function () {                                                                                 // 13
        return typeName;                                                                                               // 14
    };                                                                                                                 // 15
                                                                                                                       //
    //the return value doesn't matter since the custom type always return one value                                    // 17
    singleton.toJSONValue = function () {                                                                              // 18
        return typeName;                                                                                               // 19
    };                                                                                                                 // 20
                                                                                                                       //
    EJSON.addType(typeName, function () {                                                                              // 22
        return singleton;                                                                                              // 23
    });                                                                                                                // 24
};                                                                                                                     // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/apps.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 19/12/2015.                                                                                      //
 */                                                                                                                    //
Apps = new orion.collection('apps', {                                                                                  // 4
    singularName: 'app', // The name of one of these items                                                             // 5
    pluralName: 'apps', // The name of more than one of these items                                                    // 6
    link: {                                                                                                            // 7
        // *                                                                                                           // 8
        //  * The text that you want to show in the sidebar.                                                           // 9
        //  * The default value is the name of the collection, so                                                      // 10
        //  * in this case it is not necessary.                                                                        // 11
                                                                                                                       //
        title: 'Apps'                                                                                                  // 13
    },                                                                                                                 // 7
    /**                                                                                                                // 15
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 18
        // here we set which data columns we want to appear on the data table                                          // 19
        // in the CMS panel                                                                                            // 20
        columns: [{                                                                                                    // 21
            data: "name",                                                                                              // 23
            title: "Name"                                                                                              // 24
        }, {                                                                                                           // 22
            data: "publisher",                                                                                         // 27
            render: function () {                                                                                      // 28
                function render(val, type, doc) {                                                                      // 28
                    var publisherId = val;                                                                             // 29
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 30
                    return publisherName;                                                                              // 31
                }                                                                                                      // 32
                                                                                                                       //
                return render;                                                                                         // 28
            }(),                                                                                                       // 28
            title: "Publisher"                                                                                         // 33
        }, {                                                                                                           // 26
            data: "github",                                                                                            // 36
            title: "Github"                                                                                            // 37
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 35
    }                                                                                                                  // 18
});                                                                                                                    // 4
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       // 44
// causes a Maximum call stack size exceeded error                                                                     // 45
toEJSONSingularType(Apps, Apps.pluralName);                                                                            // 46
                                                                                                                       //
//Apps.allow({                                                                                                         // 48
//    update: function (userId, entry, fieldNames) {                                                                   // 49
//        return ownsDocument(userId, entry) && _.difference(fieldNames, appWhitelist).length === 0;                   // 50
//    },                                                                                                               // 51
//    remove: function (userId, entry) {                                                                               // 52
//        return ownsDocument(userId, entry);                                                                          // 53
//    },                                                                                                               // 54
//});                                                                                                                  // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/clients.js                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/01/2016.                                                                                      //
 */                                                                                                                    //
Clients = new orion.collection('client', {                                                                             // 4
    singularName: 'client', // The name of one of these items                                                          // 5
    pluralName: 'clients', // The name of more than one of these items                                                 // 6
    link: {                                                                                                            // 7
        // *                                                                                                           // 8
        //  * The text that you want to show in the sidebar.                                                           // 9
        //  * The default value is the name of the collection, so                                                      // 10
        //  * in this case it is not necessary.                                                                        // 11
        title: 'Clients'                                                                                               // 12
    },                                                                                                                 // 7
    /**                                                                                                                // 14
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 17
        // here we set which data columns we want to appear on the data table                                          // 18
        // in the CMS panel                                                                                            // 19
        columns: [{                                                                                                    // 20
            data: "name",                                                                                              // 22
            title: "Name"                                                                                              // 23
        }, {                                                                                                           // 21
            data: "key",                                                                                               // 26
            title: "Client Key/ID"                                                                                     // 27
        }, {                                                                                                           // 25
            data: "secret",                                                                                            // 30
            title: "Client secret"                                                                                     // 31
        }, {                                                                                                           // 29
            data: "redirect_uris",                                                                                     // 34
            title: "Redirect/Callback URLs"                                                                            // 35
        }, {                                                                                                           // 33
            data: "user",                                                                                              // 38
            render: function () {                                                                                      // 39
                function render(val, type, doc) {                                                                      // 39
                    var publisherId = val;                                                                             // 40
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 41
                    return publisherName;                                                                              // 42
                }                                                                                                      // 43
                                                                                                                       //
                return render;                                                                                         // 39
            }(),                                                                                                       // 39
            title: "User"                                                                                              // 44
        }, orion.attributeColumn('createdAt', 'createdAt', 'Created')]                                                 // 37
    }                                                                                                                  // 17
});                                                                                                                    // 4
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       // 51
// causes a Maximum call stack size exceeded error                                                                     // 52
// toEJSONSingularType(Clients, Clients.singularName);                                                                 // 53
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/comments.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Comments = new orion.collection('comments', {                                                                          // 1
    singularName: 'comment', // The name of one of these items                                                         // 2
    pluralName: 'comments', // The name of more than one of these items                                                // 3
    link: {                                                                                                            // 4
        // *                                                                                                           // 5
        //  * The text that you want to show in the sidebar.                                                           // 6
        //  * The default value is the name of the collection, so                                                      // 7
        //  * in this case it is not necessary.                                                                        // 8
                                                                                                                       //
        title: 'Comments'                                                                                              // 10
    },                                                                                                                 // 4
    /**                                                                                                                // 12
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 15
        // here we set which data columns we want to appear on the data table                                          // 16
        // in the CMS panel                                                                                            // 17
        columns: [{                                                                                                    // 18
            data: "publisher",                                                                                         // 20
            title: "Author",                                                                                           // 21
            render: function () {                                                                                      // 22
                function render(val, type, doc) {                                                                      // 22
                    var username = Meteor.users.findOne(val).username;                                                 // 23
                    return username;                                                                                   // 24
                }                                                                                                      // 25
                                                                                                                       //
                return render;                                                                                         // 22
            }()                                                                                                        // 22
        }, {                                                                                                           // 19
            data: "entryId",                                                                                           // 27
            title: "Comment of",                                                                                       // 28
            render: function () {                                                                                      // 29
                function render(val, type, doc) {                                                                      // 29
                    var entryId = val;                                                                                 // 30
                                                                                                                       //
                    //A comment can be of either a dataset or an app                                                   // 32
                    var entryTitle = Datasets.findOne(entryId).name || Apps.findOne(entryId).name;                     // 33
                    return entryTitle;                                                                                 // 34
                }                                                                                                      // 35
                                                                                                                       //
                return render;                                                                                         // 29
            }()                                                                                                        // 29
        }, {                                                                                                           // 26
            data: "body",                                                                                              // 37
            title: "Comment",                                                                                          // 38
            tmpl: Meteor.isClient && Template.commentsIndexBlurbCell                                                   // 39
        }, orion.attributeColumn('createdAt', 'submitted', 'Submitted')]                                               // 36
    }                                                                                                                  // 15
});                                                                                                                    // 1
                                                                                                                       //
//TODO add allow & deny rules                                                                                          // 46
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/datasets.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Datasets = new orion.collection('datasets', {                                                                          // 5
    singularName: 'dataset', // The name of one of these items                                                         // 6
    pluralName: 'datasets', // The name of more than one of these items                                                // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
                                                                                                                       //
        title: 'Datasets'                                                                                              // 14
    },                                                                                                                 // 8
                                                                                                                       //
    /**                                                                                                                // 17
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 20
        // here we set which data columns we want to appear on the data table                                          // 21
        // in the CMS panel                                                                                            // 22
        columns: [{                                                                                                    // 23
            data: "_id",                                                                                               // 25
            title: "ID"                                                                                                // 26
        }, {                                                                                                           // 24
            data: "name",                                                                                              // 29
            title: "Name"                                                                                              // 30
        }, {                                                                                                           // 28
            data: "publisher",                                                                                         // 33
            render: function () {                                                                                      // 34
                function render(val, type, doc) {                                                                      // 34
                    var publisherId = val;                                                                             // 35
                    var publisherName = Meteor.users.findOne(publisherId).username;                                    // 36
                    return publisherName;                                                                              // 37
                }                                                                                                      // 38
                                                                                                                       //
                return render;                                                                                         // 34
            }(),                                                                                                       // 34
            title: "Publisher"                                                                                         // 39
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 32
    }                                                                                                                  // 20
});                                                                                                                    // 5
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       // 46
// causes a Maximum call stack size exceeded error                                                                     // 47
toEJSONSingularType(Datasets, Datasets.pluralName);                                                                    // 48
                                                                                                                       //
//Datasets.allow({                                                                                                     // 50
//    update: function (userId, entry, fieldNames) {                                                                   // 51
//        return ownsDocument(userId, entry);// && _.difference(fieldNames, datasetWhitelist).length === 0;            // 52
//    },                                                                                                               // 53
//    remove: function (userId, entry) {                                                                               // 54
//        return ownsDocument(userId, entry);                                                                          // 55
//    },                                                                                                               // 56
//});                                                                                                                  // 57
                                                                                                                       //
//Datasets.deny({                                                                                                      // 59
//    update: function (userId, entry, fieldNames) {                                                                   // 60
//        return _.difference(fieldNames, datasetWhitelist).length !== 0;                                              // 61
//    }                                                                                                                // 62
//});                                                                                                                  // 63
                                                                                                                       //
//Datasets.deny({                                                                                                      // 65
//    update: function (userId, entry, fieldNames, modifier) {                                                         // 66
//        let errors = validateDataset(modifier.$set);                                                                 // 67
//        return errors.name || errors.distribution;                                                                   // 68
//    }                                                                                                                // 69
//});                                                                                                                  // 70
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/group.js                                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Groups = new orion.collection('groups', {                                                                              // 5
    singularName: 'group', // The name of one of these items                                                           // 6
    pluralName: 'groups', // The name of more than one of these items                                                  // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
                                                                                                                       //
        title: 'Groups/Organisations'                                                                                  // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 16
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 19
        // here we set which data columns we want to appear on the data table                                          // 20
        // in the CMS panel                                                                                            // 21
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           // 23
            data: "publisher",                                                                                         // 28
            title: "Founder",                                                                                          // 29
            render: function () {                                                                                      // 30
                function render(val, type, doc) {                                                                      // 30
                    var publisherName = Meteor.users.findOne(val).username;                                            // 31
                    return publisherName;                                                                              // 32
                }                                                                                                      // 33
                                                                                                                       //
                return render;                                                                                         // 30
            }()                                                                                                        // 30
        }, {                                                                                                           // 27
            data: "members",                                                                                           // 36
            title: "Members",                                                                                          // 37
            render: function () {                                                                                      // 38
                function render(val, type, doc) {                                                                      // 38
                    if (!val) {                                                                                        // 39
                        return 'No member';                                                                            // 40
                    }                                                                                                  // 41
                                                                                                                       //
                    var memberIds = val,                                                                               // 43
                        query = { $or: [] };                                                                           // 43
                    memberIds.reduce(function (previous, id) {                                                         // 45
                        return query.$or.push({ _id: id });                                                            // 46
                    }, query);                                                                                         // 47
                                                                                                                       //
                    return Meteor.users.find(query).map(function (user) {                                              // 49
                        return user.username;                                                                          // 50
                    });                                                                                                // 51
                }                                                                                                      // 52
                                                                                                                       //
                return render;                                                                                         // 38
            }()                                                                                                        // 38
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             // 35
    }                                                                                                                  // 19
});                                                                                                                    // 5
                                                                                                                       //
// When there is a change to group name, update associated account name                                                // 59
var query = Groups.find();                                                                                             // 60
var handle = query.observeChanges({                                                                                    // 61
    changed: function () {                                                                                             // 62
        function changed(groupId, changedField) {                                                                      // 62
            if (changedField.name) {                                                                                   // 63
                var groupAccountId = Groups.findOne(groupId).publisher;                                                // 64
                Meteor.users.update({ _id: groupAccountId }, { $set: { name: changedField.name } });                   // 65
            };                                                                                                         // 66
        }                                                                                                              // 67
                                                                                                                       //
        return changed;                                                                                                // 62
    }()                                                                                                                // 62
});                                                                                                                    // 61
                                                                                                                       //
Meteor.users.after.insert(function (userId, user) {                                                                    // 70
    var profile = user.profile;                                                                                        // 71
    if (profile && profile.isgroup) {                                                                                  // 72
        var group = Groups.insert({                                                                                    // 73
            publisher: user._id,                                                                                       // 74
            name: profile.name,                                                                                        // 75
            description: profile.description,                                                                          // 76
            url: profile.url                                                                                           // 77
        });                                                                                                            // 73
        Meteor.users.update(user._id, { $set: { isGroup: group }, $unset: { 'profile.isgroup': '' } });                // 79
        Roles.removeUserFromRoles(user._id, ["individual"]);                                                           // 80
        Roles.addUserToRoles(user._id, ["group"]);                                                                     // 81
    }                                                                                                                  // 82
});                                                                                                                    // 83
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/licenses.js                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 22/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Licenses = new orion.collection('licenses', {                                                                          // 5
    singularName: 'license', // The name of one of these items                                                         // 6
    pluralName: 'licenses', // The name of more than one of these items                                                // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
                                                                                                                       //
        title: 'Licenses'                                                                                              // 14
    },                                                                                                                 // 8
    /**                                                                                                                // 16
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 19
        // here we set which data columns we want to appear on the data table                                          // 20
        // in the CMS panel                                                                                            // 21
        columns: [{                                                                                                    // 22
            data: "name",                                                                                              // 24
            title: "Name"                                                                                              // 25
        }, {                                                                                                           // 23
            data: "url",                                                                                               // 28
            title: "URL"                                                                                               // 29
        }, {                                                                                                           // 27
            data: "text",                                                                                              // 32
            title: "Content"                                                                                           // 33
        }, orion.attributeColumn('createdAt', 'datePublished', 'Created')]                                             // 31
    }                                                                                                                  // 19
});                                                                                                                    // 5
                                                                                                                       //
defaultLicenses = new Set(["afl-3.0", "agpl-3.0", "apache-2.0", "artistic-2.0", "bsd-2-clause", "bsd-3-clause-clear", "bsd-3-clause", "cc0-1.0", "epl-1.0", "gpl-2.0", "gpl-3.0", "isc", "lgpl-2.1", "lgpl-3.0", "mit", "mpl-2.0", "ms-pl", "ms-rl", "no-license", "ofl-1.1", "osl-3.0", "unlicense", "wtfpl"]);
                                                                                                                       //
Licenses.allow({                                                                                                       // 47
    insert: function () {                                                                                              // 48
        function insert(userId, entry, fieldNames) {                                                                   // 48
            return true;                                                                                               // 49
        }                                                                                                              // 50
                                                                                                                       //
        return insert;                                                                                                 // 48
    }(),                                                                                                               // 48
    update: function () {                                                                                              // 51
        function update(userId, entry, fieldNames) {                                                                   // 51
            return ownsDocument(userId, entry);                                                                        // 52
        }                                                                                                              // 53
                                                                                                                       //
        return update;                                                                                                 // 51
    }(),                                                                                                               // 51
    remove: function () {                                                                                              // 54
        function remove(userId, entry) {                                                                               // 54
            return ownsDocument(userId, entry);                                                                        // 55
        }                                                                                                              // 56
                                                                                                                       //
        return remove;                                                                                                 // 54
    }()                                                                                                                // 54
});                                                                                                                    // 47
                                                                                                                       //
// Meteor.call requires parameters to be of EJSON, passing a collection as it is                                       // 59
// causes a Maximum call stack size exceeded error                                                                     // 60
toEJSONSingularType(Licenses, Licenses.singularName);                                                                  // 61
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/notifications.js                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Notifications = new Mongo.Collection('notifications');                                                                 // 1
                                                                                                                       //
Notifications.allow({                                                                                                  // 3
    update: function () {                                                                                              // 4
        function update(userId, doc, fieldNames) {                                                                     // 4
            return doc.userId === userId && fieldNames.length === 1 && fieldNames[0] === 'read';                       // 5
        }                                                                                                              // 7
                                                                                                                       //
        return update;                                                                                                 // 4
    }()                                                                                                                // 4
});                                                                                                                    // 3
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/declarations/remote.js                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 11/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
RemoteDatasets = new orion.collection('remotedatasets', {                                                              // 5
    singularName: 'remotedataset', // The name of one of these items                                                   // 6
    pluralName: 'remotedatasets', // The name of more than one of these items                                          // 7
    link: {                                                                                                            // 8
        // *                                                                                                           // 9
        //  * The text that you want to show in the sidebar.                                                           // 10
        //  * The default value is the name of the collection, so                                                      // 11
        //  * in this case it is not necessary.                                                                        // 12
                                                                                                                       //
        title: 'Remote Datasets'                                                                                       // 14
    },                                                                                                                 // 8
                                                                                                                       //
    /**                                                                                                                // 17
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 20
        // here we set which data columns we want to appear on the data table                                          // 21
        // in the CMS panel                                                                                            // 22
        columns: [{                                                                                                    // 23
            data: "name",                                                                                              // 25
            title: "Name"                                                                                              // 26
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 24
    }                                                                                                                  // 20
});                                                                                                                    // 5
                                                                                                                       //
RemoteApps = new orion.collection('remoteapps', {                                                                      // 33
    singularName: 'remoteapp', // The name of one of these items                                                       // 34
    pluralName: 'remoteapps', // The name of more than one of these items                                              // 35
    link: {                                                                                                            // 36
        // *                                                                                                           // 37
        //  * The text that you want to show in the sidebar.                                                           // 38
        //  * The default value is the name of the collection, so                                                      // 39
        //  * in this case it is not necessary.                                                                        // 40
                                                                                                                       //
        title: 'Remote Apps'                                                                                           // 42
    },                                                                                                                 // 36
    /**                                                                                                                // 44
     * Tabular settings for this collection                                                                            //
     */                                                                                                                //
    tabular: {                                                                                                         // 47
        // here we set which data columns we want to appear on the data table                                          // 48
        // in the CMS panel                                                                                            // 49
        columns: [{                                                                                                    // 50
            data: "name",                                                                                              // 52
            title: "Name"                                                                                              // 53
        }, orion.attributeColumn('createdAt', 'datePublished', 'Published')]                                           // 51
    }                                                                                                                  // 47
});                                                                                                                    // 33
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"schemas":{"_creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/_creative_work.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
// SimpleSchema.debug = true;                                                                                          // 4
// SimpleSchema.extendOptions({                                                                                        // 5
//     //noneditable: Match.Optional(Boolean)                                                                          // 6
// });                                                                                                                 // 7
                                                                                                                       //
Thing = {                                                                                                              // 9
    name: {                                                                                                            // 10
        type: String,                                                                                                  // 11
        unique: true,                                                                                                  // 12
        label: 'Name'                                                                                                  // 13
    },                                                                                                                 // 10
                                                                                                                       //
    description: orion.attribute('summernote', {                                                                       // 16
        label: 'Description',                                                                                          // 17
        optional: true                                                                                                 // 18
    })                                                                                                                 // 16
};                                                                                                                     // 9
                                                                                                                       //
CreativeWork = {                                                                                                       // 22
    comments: orion.attribute('hasMany', {                                                                             // 23
        type: [String],                                                                                                // 24
        label: 'Comments',                                                                                             // 25
        // optional is true because you can have a post without comments                                               // 26
        optional: true                                                                                                 // 27
    }, {                                                                                                               // 23
        collection: Comments,                                                                                          // 30
        titleField: 'body',                                                                                            // 31
        publicationName: 'rel_comments'                                                                                // 32
    }),                                                                                                                // 29
                                                                                                                       //
    commentsCount: {                                                                                                   // 35
        type: Number,                                                                                                  // 36
        autoValue: function () {                                                                                       // 37
            function autoValue() {                                                                                     // 35
                var comments = this.field("comments");                                                                 // 38
                return comments ? comments.length : 0;                                                                 // 39
            }                                                                                                          // 40
                                                                                                                       //
            return autoValue;                                                                                          // 35
        }(),                                                                                                           // 35
                                                                                                                       //
        optional: true,                                                                                                // 41
        autoform: {                                                                                                    // 42
            omit: true                                                                                                 // 43
        }                                                                                                              // 42
    },                                                                                                                 // 35
                                                                                                                       //
    creator: {                                                                                                         // 48
        type: String,                                                                                                  // 49
        label: 'Creator',                                                                                              // 50
        optional: true                                                                                                 // 51
    },                                                                                                                 // 48
                                                                                                                       //
    publisher: orion.attribute('createdBy'),                                                                           // 54
                                                                                                                       //
    publisherName: {                                                                                                   // 56
        type: String,                                                                                                  // 57
        optional: true,                                                                                                // 58
        autoform: {                                                                                                    // 59
            type: 'hidden'                                                                                             // 60
            // omit: true                                                                                              // 61
        },                                                                                                             // 59
        autoValue: function () {                                                                                       // 63
            function autoValue() {                                                                                     // 56
                var publisher = this.field('publisher');                                                               // 64
                if (publisher.isSet) {                                                                                 // 65
                    var pId = publisher.value;                                                                         // 66
                    var user = Meteor.users.findOne(pId);                                                              // 67
                    if (user) {                                                                                        // 68
                        return user.username;                                                                          // 69
                    } else {                                                                                           // 70
                        this.unset();                                                                                  // 71
                    }                                                                                                  // 72
                } else {                                                                                               // 73
                    this.unset();                                                                                      // 74
                }                                                                                                      // 75
            }                                                                                                          // 76
                                                                                                                       //
            return autoValue;                                                                                          // 56
        }()                                                                                                            // 56
    },                                                                                                                 // 56
    // Force value to be current date (on server) upon insert                                                          // 78
    // and prevent updates thereafter.                                                                                 // 79
    datePublished: orion.attribute('createdAt'),                                                                       // 80
                                                                                                                       //
    // Force value to be current date (on server) upon update                                                          // 82
    // and don't allow it to be set upon insert.                                                                       // 83
    dateModified: orion.attribute('updatedAt'),                                                                        // 84
                                                                                                                       //
    isBasedOnUrl: orion.attribute('hasMany', {                                                                         // 86
        type: [String],                                                                                                // 87
        label: 'Related datasets',                                                                                     // 88
        optional: true                                                                                                 // 89
    }, {                                                                                                               // 86
        collection: Datasets,                                                                                          // 91
        titleField: 'name',                                                                                            // 92
        publicationName: 'isbasedonurl'                                                                                // 93
    }),                                                                                                                // 90
                                                                                                                       //
    keywords: {                                                                                                        // 96
        type: [String],                                                                                                // 97
        label: 'Keywords',                                                                                             // 98
        optional: true                                                                                                 // 99
    },                                                                                                                 // 96
                                                                                                                       //
    license: {                                                                                                         // 102
        type: String,                                                                                                  // 103
        label: 'License',                                                                                              // 104
        autoform: {                                                                                                    // 105
            options: function () {                                                                                     // 106
                function options() {                                                                                   // 105
                    var addedLices = Licenses.find().fetch();                                                          // 107
                                                                                                                       //
                    var options = [];                                                                                  // 109
                    defaultLicenses.forEach(function (name) {                                                          // 110
                        options.push({ label: name.toUpperCase(), value: name });                                      // 111
                    });                                                                                                // 112
                                                                                                                       //
                    addedLices.forEach(function (lice) {                                                               // 114
                        if (lice.name) {                                                                               // 115
                            var name = lice.name;                                                                      // 116
                            options.push({ label: name.toUpperCase(), value: name });                                  // 117
                        }                                                                                              // 118
                    });                                                                                                // 119
                                                                                                                       //
                    return options;                                                                                    // 121
                }                                                                                                      // 122
                                                                                                                       //
                return options;                                                                                        // 105
            }()                                                                                                        // 105
        }                                                                                                              // 105
    }                                                                                                                  // 102
};                                                                                                                     // 22
                                                                                                                       //
Mis = {                                                                                                                // 127
    upvoters: {                                                                                                        // 128
        type: [String],                                                                                                // 129
        optional: true,                                                                                                // 130
        autoform: {                                                                                                    // 131
            omit: true                                                                                                 // 132
        }                                                                                                              // 131
    },                                                                                                                 // 128
                                                                                                                       //
    votes: {                                                                                                           // 136
        type: Number,                                                                                                  // 137
        autoform: {                                                                                                    // 138
            omit: true                                                                                                 // 139
        },                                                                                                             // 138
        optional: true,                                                                                                // 141
        autoValue: function () {                                                                                       // 142
            function autoValue() {                                                                                     // 136
                var voters = this.field('upvoters');                                                                   // 143
                return voters ? voters.length : 0;                                                                     // 144
            }                                                                                                          // 145
                                                                                                                       //
            return autoValue;                                                                                          // 136
        }()                                                                                                            // 136
    },                                                                                                                 // 136
                                                                                                                       //
    downvoters: {                                                                                                      // 148
        type: [String],                                                                                                // 149
        optional: true,                                                                                                // 150
        autoform: {                                                                                                    // 151
            omit: true                                                                                                 // 152
        }                                                                                                              // 151
    },                                                                                                                 // 148
                                                                                                                       //
    downvotes: {                                                                                                       // 156
        type: Number,                                                                                                  // 157
        autoform: {                                                                                                    // 158
            omit: true                                                                                                 // 159
        },                                                                                                             // 158
        optional: true,                                                                                                // 161
        autoValue: function () {                                                                                       // 162
            function autoValue() {                                                                                     // 156
                var voters = this.field('downvoters');                                                                 // 163
                return voters ? voters.length : 0;                                                                     // 164
            }                                                                                                          // 165
                                                                                                                       //
            return autoValue;                                                                                          // 156
        }()                                                                                                            // 156
    },                                                                                                                 // 156
                                                                                                                       //
    // whether this entry is online                                                                                    // 168
    // in case of a dataset, it's offline if any of its distribution is offline                                        // 169
    online: {                                                                                                          // 170
        type: Boolean,                                                                                                 // 171
        autoform: {                                                                                                    // 172
            readonly: true,                                                                                            // 173
            type: 'hidden'                                                                                             // 174
        },                                                                                                             // 172
        optional: true,                                                                                                // 176
        defaultValue: true                                                                                             // 177
    },                                                                                                                 // 170
                                                                                                                       //
    //metadata permission i.e. visibility                                                                              // 180
    aclMeta: {                                                                                                         // 181
        type: Boolean,                                                                                                 // 182
        label: "Visible to everyone",                                                                                  // 183
        defaultValue: true                                                                                             // 184
    },                                                                                                                 // 181
                                                                                                                       //
    //content permission i.e. queryability                                                                             // 187
    aclContent: {                                                                                                      // 188
        type: Boolean,                                                                                                 // 189
        label: "Accessible to everyone",                                                                               // 190
        defaultValue: true                                                                                             // 191
    },                                                                                                                 // 188
                                                                                                                       //
    //who can see this entry disregards acl settings                                                                   // 194
    metaWhiteList: orion.attribute('hasMany', {                                                                        // 195
        type: [String],                                                                                                // 196
        label: 'Permitted to see',                                                                                     // 197
        autoform: {                                                                                                    // 198
            omit: true                                                                                                 // 199
        },                                                                                                             // 198
        optional: true                                                                                                 // 201
    }, {                                                                                                               // 195
        collection: Meteor.users,                                                                                      // 203
        titleField: 'username',                                                                                        // 204
        publicationName: 'metawhitelist'                                                                               // 205
    }),                                                                                                                // 202
                                                                                                                       //
    //who can access this entry disregards acl settings                                                                // 208
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 209
        type: [String],                                                                                                // 210
        label: 'Share to',                                                                                             // 211
        optional: true                                                                                                 // 212
    }, {                                                                                                               // 209
        collection: Meteor.users,                                                                                      // 214
        titleField: 'username',                                                                                        // 215
        publicationName: 'contentwhitelist'                                                                            // 216
    })                                                                                                                 // 213
};                                                                                                                     // 127
                                                                                                                       //
_.extend(CreativeWork, Thing);                                                                                         // 220
_.extend(CreativeWork, Mis);                                                                                           // 221
                                                                                                                       //
omitFields = "publisher, comments, commentsCount, datePublished, dateModified, upvoters, downvoters, votes, downvotes, online, distribution.$._id".split(/\s*,\s*/);
                                                                                                                       //
setAtCreation = function setAtCreation(field, val) {                                                                   // 225
    if (val instanceof Function) {                                                                                     // 226
        val = val();                                                                                                   // 227
    }                                                                                                                  // 228
    if (field.isInsert) {                                                                                              // 229
        return val;                                                                                                    // 230
    } else if (field.isUpsert) {                                                                                       // 231
        return { $setOnInsert: val };                                                                                  // 232
    } else {                                                                                                           // 233
        field.unset();                                                                                                 // 234
    }                                                                                                                  // 235
};                                                                                                                     // 236
                                                                                                                       //
setAtUpdate = function setAtUpdate(field, val) {                                                                       // 238
    if (val instanceof Function) {                                                                                     // 239
        val = val();                                                                                                   // 240
    }                                                                                                                  // 241
    if (field.isUpdate || field.isInsert) {                                                                            // 242
        return val;                                                                                                    // 243
    } else if (field.isUpsert) {                                                                                       // 244
        return { $setOnInsert: val };                                                                                  // 245
    } else {                                                                                                           // 246
        //shouldn't reach here                                                                                         // 247
        field.unset();                                                                                                 // 248
    }                                                                                                                  // 249
};                                                                                                                     // 250
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"apps.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/apps.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 19/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
AppSchema = {                                                                                                          // 5
    url: {                                                                                                             // 6
        type: String,                                                                                                  // 7
        label: "URL",                                                                                                  // 8
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 9
        autoform: {                                                                                                    // 10
            type: 'url',                                                                                               // 11
            placeholder: "Provide the URL of your web app or upload the app source below"                              // 12
        }                                                                                                              // 10
    },                                                                                                                 // 6
    file: orion.attribute('file', {                                                                                    // 15
        label: 'Upload app source as a zip file. Only support apps written in client-side JS and HTML',                // 16
        optional: true                                                                                                 // 17
    }),                                                                                                                // 15
    github: {                                                                                                          // 19
        type: String,                                                                                                  // 20
        optional: true,                                                                                                // 21
        label: "Github",                                                                                               // 22
        regEx: SimpleSchema.RegEx.Url                                                                                  // 23
    }                                                                                                                  // 19
};                                                                                                                     // 5
                                                                                                                       //
////_.extend(App, CreativeWork);                                                                                       // 27
//                                                                                                                     // 28
////important, generate whitelist before constructing simpleschema                                                     // 29
//appWhitelist = _.filter(_.keys(App), function (property) {                                                           // 30
//    return !App[property].noneditable;                                                                               // 31
//});                                                                                                                  // 32
//                                                                                                                     // 33
//_.extend(appWhitelist, Whitelist);                                                                                   // 34
//                                                                                                                     // 35
//appBlacklist = _.filter(_.keys(App), function (property) {                                                           // 36
//    return App[property].noneditable;                                                                                // 37
//});                                                                                                                  // 38
//                                                                                                                     // 39
//_.extend(appBlacklist, BlackList);                                                                                   // 40
                                                                                                                       //
Apps.attachSchema(new SimpleSchema([Thing, AppSchema, CreativeWork]));                                                 // 42
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/clients.js                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/01/2016.                                                                                      //
 */                                                                                                                    //
// import crypto from 'crypto'                                                                                         // 4
                                                                                                                       //
function keyGen(str) {                                                                                                 // 6
    return CryptoJS.MD5(str + Math.random()).toString(CryptoJS.enc.Hex);                                               // 7
}                                                                                                                      // 8
                                                                                                                       //
var ClientSchema = new SimpleSchema({                                                                                  // 10
                                                                                                                       //
    name: {                                                                                                            // 12
        type: String,                                                                                                  // 13
        label: 'Name'                                                                                                  // 14
    },                                                                                                                 // 12
                                                                                                                       //
    user: orion.attribute('createdBy'),                                                                                // 17
                                                                                                                       //
    publisher: orion.attribute('createdBy'),                                                                           // 19
                                                                                                                       //
    key: {                                                                                                             // 21
        type: String,                                                                                                  // 22
        // denyUpdate: true,                                                                                           // 23
        autoValue: function () {                                                                                       // 24
            function autoValue() {                                                                                     // 21
                if (this.isInsert) {                                                                                   // 25
                    var user = Meteor.userId();                                                                        // 26
                    return keyGen(user + '-');                                                                         // 27
                } else {                                                                                               // 28
                    this.unset(); // Prevent user from supplying their own value                                       // 29
                }                                                                                                      // 30
            }                                                                                                          // 31
                                                                                                                       //
            return autoValue;                                                                                          // 21
        }(),                                                                                                           // 21
                                                                                                                       //
        autoform: {                                                                                                    // 32
            // omit: true,                                                                                             // 33
            readonly: true                                                                                             // 34
        }                                                                                                              // 32
    },                                                                                                                 // 21
                                                                                                                       //
    secret: {                                                                                                          // 38
        type: String,                                                                                                  // 39
        // denyUpdate: true,                                                                                           // 40
        autoValue: function () {                                                                                       // 41
            function autoValue() {                                                                                     // 38
                var key = this.field("key");                                                                           // 42
                if (key.isSet) {                                                                                       // 43
                    var user = Meteor.userId();                                                                        // 44
                    return keyGen(key.value + user);                                                                   // 45
                } else {                                                                                               // 46
                    this.unset();                                                                                      // 47
                }                                                                                                      // 48
            }                                                                                                          // 49
                                                                                                                       //
            return autoValue;                                                                                          // 38
        }(),                                                                                                           // 38
                                                                                                                       //
        autoform: {                                                                                                    // 50
            // omit: true,                                                                                             // 51
            readonly: true                                                                                             // 52
        }                                                                                                              // 50
    },                                                                                                                 // 38
                                                                                                                       //
    createdAt: orion.attribute('createdAt'),                                                                           // 56
    updatedAt: orion.attribute('updatedAt'),                                                                           // 57
                                                                                                                       //
    redirect_uris: {                                                                                                   // 59
        type: [String],                                                                                                // 60
        label: 'Callback URLs',                                                                                        // 61
        optional: true                                                                                                 // 62
    }                                                                                                                  // 59
});                                                                                                                    // 10
                                                                                                                       //
Clients.attachSchema(ClientSchema);                                                                                    // 66
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/comments.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Now we will attach the schema for that collection.                                                                  //
 * Orion will automatically create the corresponding form.                                                             //
 */                                                                                                                    //
Comments.attachSchema(new SimpleSchema({                                                                               // 5
    entryId: {                                                                                                         // 6
        type: String,                                                                                                  // 7
        // the label is the text that will show up on the Update form's label                                          // 8
        label: 'Comment of',                                                                                           // 9
        // optional is false because you shouldn't have a comment without a post                                       // 10
        // associated with it                                                                                          // 11
        autoform: {                                                                                                    // 12
            type: "hidden",                                                                                            // 13
            readonly: true                                                                                             // 14
        }                                                                                                              // 12
    },                                                                                                                 // 6
    // here is where we define `a comment has one user (author)`                                                       // 17
    // Each document in Comment has a userId                                                                           // 18
    publisher: {                                                                                                       // 19
        type: String,                                                                                                  // 20
        label: 'Author',                                                                                               // 21
        autoform: {                                                                                                    // 22
            type: "hidden",                                                                                            // 23
            readonly: true                                                                                             // 24
        }                                                                                                              // 22
    },                                                                                                                 // 19
    category: {                                                                                                        // 27
        type: String,                                                                                                  // 28
        optional: true                                                                                                 // 29
    },                                                                                                                 // 27
    submitted: {                                                                                                       // 31
        type: Date,                                                                                                    // 32
        autoform: {                                                                                                    // 33
            readonly: true                                                                                             // 34
        }                                                                                                              // 33
    },                                                                                                                 // 31
    body: orion.attribute('summernote', {                                                                              // 37
        label: 'Comment body'                                                                                          // 38
    }),                                                                                                                // 37
    image: orion.attribute('image', {                                                                                  // 40
        optional: true,                                                                                                // 41
        label: 'Comment Image'                                                                                         // 42
    })                                                                                                                 // 40
}));                                                                                                                   // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"datasets.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/datasets.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * http://schema.org/Dataset                                                                                           //
 * Created by xgfd on 17/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var DistributionSchema = new SimpleSchema({                                                                            // 7
                                                                                                                       //
    _id: {                                                                                                             // 9
        type: String,                                                                                                  // 10
        denyUpdate: true,                                                                                              // 11
        optional: true,                                                                                                // 12
        regEx: SimpleSchema.RegEx.Id,                                                                                  // 13
        autoValue: function () {                                                                                       // 14
            function autoValue() {                                                                                     // 9
                // console.log('subId', this);                                                                         // 15
                if (this.isInsert) {                                                                                   // 16
                    return Random.id();                                                                                // 17
                } else if (this.isUpsert) {                                                                            // 18
                    return { $setOnInsert: Random.id() };                                                              // 19
                } else {                                                                                               // 20
                    this.unset(); // Prevent user from supplying their own value                                       // 21
                }                                                                                                      // 22
            }                                                                                                          // 23
                                                                                                                       //
            return autoValue;                                                                                          // 9
        }()                                                                                                            // 9
        // defaultValue: Random.id(),                                                                                  // 24
        // autoform: {                                                                                                 // 25
        //     type: 'hidden',                                                                                         // 26
        //     // readonly: true                                                                                       // 27
        //     // omit: true                                                                                           // 28
        // }                                                                                                           // 29
                                                                                                                       //
    },                                                                                                                 // 9
                                                                                                                       //
    fileFormat: {                                                                                                      // 32
        type: String,                                                                                                  // 33
        label: 'Dataset type',                                                                                         // 34
        allowedValues: ['MongoDB', 'MySQL', 'AMQP', 'SPARQL', 'HTML', 'File', 'GeoData'],                              // 35
        autoform: { type: 'select' }                                                                                   // 36
        //TODO custom validate                                                                                         // 37
    },                                                                                                                 // 32
                                                                                                                       //
    url: {                                                                                                             // 40
        type: String,                                                                                                  // 41
        label: 'URL',                                                                                                  // 42
        autoform: {                                                                                                    // 43
            type: 'url',                                                                                               // 44
            placeholder: "Select a format"                                                                             // 45
        }                                                                                                              // 43
    },                                                                                                                 // 40
                                                                                                                       //
    file: orion.attribute('file', {                                                                                    // 49
        label: 'Upload dataset file.',                                                                                 // 50
        optional: true                                                                                                 // 51
    }),                                                                                                                // 49
                                                                                                                       //
    //dataset dependent information                                                                                    // 54
    profile: {                                                                                                         // 55
        type: Object,                                                                                                  // 56
        optional: true,                                                                                                // 57
        label: 'Dataset credential',                                                                                   // 58
        defaultValue: {}                                                                                               // 59
    },                                                                                                                 // 55
    //dataset username                                                                                                 // 61
    'profile.username': {                                                                                              // 62
        type: String,                                                                                                  // 63
        optional: true,                                                                                                // 64
        label: 'Dataset user name'                                                                                     // 65
    },                                                                                                                 // 62
    //dataset password                                                                                                 // 67
    'profile.pass': {                                                                                                  // 68
        type: String,                                                                                                  // 69
        optional: true,                                                                                                // 70
        label: 'Dataset password'                                                                                      // 71
    },                                                                                                                 // 68
    //geo data source id in case of geo data                                                                           // 73
    'profile.geodata': {                                                                                               // 74
        type: String,                                                                                                  // 75
        autoform: {                                                                                                    // 76
            type: 'hidden'                                                                                             // 77
        },                                                                                                             // 76
        optional: true,                                                                                                // 80
        label: 'GeoData Id'                                                                                            // 81
    },                                                                                                                 // 74
                                                                                                                       //
    instruction: {                                                                                                     // 84
        type: String,                                                                                                  // 85
        optional: true,                                                                                                // 86
        label: 'How to access this dataset',                                                                           // 87
        autoform: { type: 'textarea' }                                                                                 // 88
    },                                                                                                                 // 84
                                                                                                                       //
    //whether this distribution is online                                                                              // 91
    online: {                                                                                                          // 92
        type: Boolean,                                                                                                 // 93
        autoform: {                                                                                                    // 94
            omit: true                                                                                                 // 95
        },                                                                                                             // 94
        optional: true,                                                                                                // 97
        defaultValue: true                                                                                             // 98
    }                                                                                                                  // 92
});                                                                                                                    // 7
                                                                                                                       //
DatasetSchema = {                                                                                                      // 102
                                                                                                                       //
    url: {                                                                                                             // 104
        type: String,                                                                                                  // 105
        label: "URL",                                                                                                  // 106
        regEx: SimpleSchema.RegEx.Url,                                                                                 // 107
        autoform: {                                                                                                    // 108
            type: 'hidden'                                                                                             // 109
        },                                                                                                             // 108
        optional: true,                                                                                                // 111
        autoValue: function () {                                                                                       // 112
            function autoValue() {                                                                                     // 104
                if (!this.isSet) {                                                                                     // 113
                    var distribution = this.field('distribution').value;                                               // 114
                    if (distribution && distribution.length === 1 && distribution[0].fileFormat === 'HTML') {          // 115
                        return distribution[0].url;                                                                    // 116
                    }                                                                                                  // 117
                }                                                                                                      // 118
            }                                                                                                          // 119
                                                                                                                       //
            return autoValue;                                                                                          // 104
        }()                                                                                                            // 104
    },                                                                                                                 // 104
                                                                                                                       //
    distribution: {                                                                                                    // 122
        type: [DistributionSchema],                                                                                    // 123
        autoValue: function () {                                                                                       // 124
            function autoValue() {                                                                                     // 122
                if (this.isUpdate) {                                                                                   // 125
                    this.unset();                                                                                      // 126
                }                                                                                                      // 127
                // return setAtCreation(this, undefined);                                                              // 128
            }                                                                                                          // 129
                                                                                                                       //
            return autoValue;                                                                                          // 122
        }(),                                                                                                           // 122
                                                                                                                       //
        label: "Dataset"                                                                                               // 130
    },                                                                                                                 // 122
                                                                                                                       //
    datasetTimeInterval: {                                                                                             // 133
        type: Object,                                                                                                  // 134
        label: "Time span",                                                                                            // 135
        optional: true                                                                                                 // 136
    },                                                                                                                 // 133
                                                                                                                       //
    "datasetTimeInterval.startTime": {                                                                                 // 139
        type: Date,                                                                                                    // 140
        label: "Start",                                                                                                // 141
        autoform: {                                                                                                    // 142
            type: "bootstrap-datepicker" // set to bootstrap-datepicker to work with materilize, check out https://github.com/djhi/meteor-autoform-materialize/
        }                                                                                                              // 142
    },                                                                                                                 // 139
                                                                                                                       //
    "datasetTimeInterval.endTime": {                                                                                   // 147
        type: Date,                                                                                                    // 148
        label: "End",                                                                                                  // 149
        autoform: {                                                                                                    // 150
            type: "bootstrap-datepicker"                                                                               // 151
        }                                                                                                              // 150
    },                                                                                                                 // 147
                                                                                                                       //
    spatial: {                                                                                                         // 155
        type: String,                                                                                                  // 156
        label: "Spatial coverage",                                                                                     // 157
        optional: true                                                                                                 // 158
    }                                                                                                                  // 155
};                                                                                                                     // 102
                                                                                                                       //
//_.extend(Dataset, CreativeWork);                                                                                     // 162
//important, generate whitelist before constructing simpleschema                                                       // 163
//datasetWhitelist = _.filter(_.keys(Dataset), function (property) {                                                   // 164
//    return !Dataset[property].noneditable;                                                                           // 165
//});                                                                                                                  // 166
//                                                                                                                     // 167
//_.extend(datasetWhitelist, Whitelist);                                                                               // 168
//                                                                                                                     // 169
//datasetBlackList = _.filter(_.keys(Dataset), function (property) {                                                   // 170
//    return Dataset[property].noneditable;                                                                            // 171
//});                                                                                                                  // 172
//                                                                                                                     // 173
//_.extend(datasetBlackList, BlackList);                                                                               // 174
                                                                                                                       //
/* the following will cause errors;                                                                                    // 176
 * new SimpleSchema(Dataset)) modifies Dataset and therefore modifies CreativeWork                                     //
 _.extend(Dataset, CreativeWork);                                                                                      //
 Datasets.attachSchema(new SimpleSchema(Dataset));                                                                     //
 */                                                                                                                    //
Datasets.attachSchema(new SimpleSchema([Thing, DatasetSchema, CreativeWork]));                                         // 181
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/groups.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var Group = {                                                                                                          // 5
    name: { type: String },                                                                                            // 6
                                                                                                                       //
    description: { type: String, optional: true },                                                                     // 8
                                                                                                                       //
    url: { type: String, label: 'Home page', regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },
                                                                                                                       //
    youtube: { type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },               // 12
                                                                                                                       //
    github: { type: String, regEx: SimpleSchema.RegEx.Url, optional: true, autoform: { type: 'url' } },                // 14
                                                                                                                       //
    publisher: orion.attribute('hasOne', {                                                                             // 16
        type: String,                                                                                                  // 17
        label: 'Founder'                                                                                               // 18
    }, {                                                                                                               // 16
        collection: Meteor.users,                                                                                      // 20
        titleField: 'username',                                                                                        // 21
        publicationName: 'groupfounder'                                                                                // 22
    }),                                                                                                                // 19
                                                                                                                       //
    //who can access this entry disregards acl settings                                                                // 25
    //used as Members field to reuse existing functions                                                                // 26
    contentWhiteList: orion.attribute('hasMany', {                                                                     // 27
        type: [String],                                                                                                // 28
        label: 'Members',                                                                                              // 29
        // optional is true because you can have a post without comments                                               // 30
        optional: true                                                                                                 // 31
    }, {                                                                                                               // 27
        collection: Meteor.users,                                                                                      // 33
        titleField: 'username',                                                                                        // 34
        publicationName: 'groupmembers'                                                                                // 35
    }),                                                                                                                // 32
                                                                                                                       //
    datasets: orion.attribute('hasMany', {                                                                             // 38
        type: [String],                                                                                                // 39
        label: 'Datasets',                                                                                             // 40
        // optional is true because you can have a post without comments                                               // 41
        optional: true                                                                                                 // 42
    }, {                                                                                                               // 38
        collection: Datasets,                                                                                          // 44
        titleField: 'name',                                                                                            // 45
        publicationName: 'groupdatasets'                                                                               // 46
    }),                                                                                                                // 43
                                                                                                                       //
    apps: orion.attribute('hasMany', {                                                                                 // 49
        type: [String],                                                                                                // 50
        label: 'Apps',                                                                                                 // 51
        // optional is true because you can have a post without comments                                               // 52
        optional: true                                                                                                 // 53
    }, {                                                                                                               // 49
        collection: Apps,                                                                                              // 55
        titleField: 'name',                                                                                            // 56
        publicationName: 'groupapps'                                                                                   // 57
    }),                                                                                                                // 54
                                                                                                                       //
    //publications: {type: [Object], label: "Publications", optional: true},                                           // 60
    "publications.$.name": { type: String, optional: true },                                                           // 61
    "publications.$.url": { type: String, optional: true, autoform: { type: 'url' } },                                 // 62
                                                                                                                       //
    datePublished: {                                                                                                   // 64
        type: Date,                                                                                                    // 65
        label: "Created at",                                                                                           // 66
        denyUpdate: true,                                                                                              // 67
        autoform: {                                                                                                    // 68
            readonly: true,                                                                                            // 69
            type: "bootstrap-datepicker"                                                                               // 70
        },                                                                                                             // 68
        autoValue: function () {                                                                                       // 72
            function autoValue() {                                                                                     // 72
                if (this.isInsert) {                                                                                   // 73
                    return new Date();                                                                                 // 74
                } else if (this.isUpsert) {                                                                            // 75
                    return { $setOnInsert: new Date() };                                                               // 76
                } else {                                                                                               // 77
                    this.unset(); // Prevent user from supplying their own value                                       // 78
                }                                                                                                      // 79
            }                                                                                                          // 80
                                                                                                                       //
            return autoValue;                                                                                          // 72
        }()                                                                                                            // 72
    },                                                                                                                 // 64
                                                                                                                       //
    upvoters: {                                                                                                        // 83
        type: [String],                                                                                                // 84
        optional: true,                                                                                                // 85
        autoform: {                                                                                                    // 86
            readonly: true                                                                                             // 87
        }                                                                                                              // 86
    },                                                                                                                 // 83
                                                                                                                       //
    votes: {                                                                                                           // 91
        type: Number,                                                                                                  // 92
        autoform: {                                                                                                    // 93
            readonly: true                                                                                             // 94
        },                                                                                                             // 93
        optional: true                                                                                                 // 96
    },                                                                                                                 // 91
                                                                                                                       //
    // whether this entry is online                                                                                    // 99
    // in case of a dataset, it's offline if any of its distribution is offline                                        // 100
    online: {                                                                                                          // 101
        type: Boolean,                                                                                                 // 102
        autoform: {                                                                                                    // 103
            type: 'hidden',                                                                                            // 104
            readonly: true                                                                                             // 105
        },                                                                                                             // 103
        defaultValue: true                                                                                             // 107
    },                                                                                                                 // 101
                                                                                                                       //
    //metadata permission i.e. visibility                                                                              // 110
    aclMeta: {                                                                                                         // 111
        type: Boolean,                                                                                                 // 112
        label: "Visible to everyone",                                                                                  // 113
        defaultValue: true                                                                                             // 114
    },                                                                                                                 // 111
                                                                                                                       //
    aclContent: {                                                                                                      // 117
        type: Boolean,                                                                                                 // 118
        label: "Everyone can join",                                                                                    // 119
        defaultValue: true                                                                                             // 120
    }                                                                                                                  // 117
};                                                                                                                     // 5
                                                                                                                       //
Groups.attachSchema(new SimpleSchema([Group]));                                                                        // 124
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"licenses.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/licenses.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 22/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var LicenseSchema = new SimpleSchema({                                                                                 // 5
    name: {                                                                                                            // 6
        type: String,                                                                                                  // 7
        label: 'License name'                                                                                          // 8
    },                                                                                                                 // 6
    url: {                                                                                                             // 10
        type: String,                                                                                                  // 11
        label: 'License URL',                                                                                          // 12
        autoform: {                                                                                                    // 13
            type: 'url'                                                                                                // 14
        },                                                                                                             // 13
        optional: true                                                                                                 // 16
    },                                                                                                                 // 10
    publisher: orion.attribute('hasOne', {                                                                             // 18
        type: String,                                                                                                  // 19
        label: 'publisher',                                                                                            // 20
        denyUpdate: true,                                                                                              // 21
        autoValue: function () {                                                                                       // 22
            function autoValue() {                                                                                     // 18
                if (this.isInsert || this.isUpsert) {                                                                  // 23
                    return Meteor.userId();                                                                            // 24
                } else {                                                                                               // 25
                    this.unset();                                                                                      // 26
                }                                                                                                      // 27
            }                                                                                                          // 28
                                                                                                                       //
            return autoValue;                                                                                          // 18
        }(),                                                                                                           // 18
                                                                                                                       //
        autoform: {                                                                                                    // 29
            type: 'select',                                                                                            // 30
            readonly: true,                                                                                            // 31
            omit: true                                                                                                 // 32
        }                                                                                                              // 29
    }, {                                                                                                               // 18
        collection: Meteor.users,                                                                                      // 36
        // the key whose value you want to show for each post document on the update form                              // 37
        titleField: 'username',                                                                                        // 38
        publicationName: 'licepublisher'                                                                               // 39
    }),                                                                                                                // 35
    text: {                                                                                                            // 41
        type: String,                                                                                                  // 42
        label: 'License content',                                                                                      // 43
        autoform: {                                                                                                    // 44
            type: 'textarea'                                                                                           // 45
        },                                                                                                             // 44
        optional: true                                                                                                 // 47
    },                                                                                                                 // 41
    datePublished: {                                                                                                   // 49
        type: Date,                                                                                                    // 50
        denyUpdate: true,                                                                                              // 51
        autoform: {                                                                                                    // 52
            readonly: true,                                                                                            // 53
            omit: true,                                                                                                // 54
            type: "bootstrap-datepicker"                                                                               // 55
        },                                                                                                             // 52
        autoValue: function () {                                                                                       // 57
            function autoValue() {                                                                                     // 57
                if (this.isInsert || this.isUpsert) {                                                                  // 58
                    return new Date();                                                                                 // 59
                } else {                                                                                               // 60
                    this.unset(); // Prevent user from supplying their own value                                       // 61
                }                                                                                                      // 62
            }                                                                                                          // 63
                                                                                                                       //
            return autoValue;                                                                                          // 57
        }()                                                                                                            // 57
    }                                                                                                                  // 49
});                                                                                                                    // 5
                                                                                                                       //
Licenses.attachSchema(LicenseSchema);                                                                                  // 67
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"remote.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/collections/schemas/remote.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 12/05/2016.                                                                                      //
 */                                                                                                                    //
var remoteMeta = {                                                                                                     // 4
    origin: {                                                                                                          // 5
        type: String,                                                                                                  // 6
        label: 'Origin',                                                                                               // 7
        optional: true                                                                                                 // 8
    }                                                                                                                  // 5
};                                                                                                                     // 4
                                                                                                                       //
var ReleasedCreativeWork = _.clone(CreativeWork);                                                                      // 12
                                                                                                                       //
ReleasedCreativeWork.publisher = {                                                                                     // 14
    type: String,                                                                                                      // 15
    label: 'Publisher',                                                                                                // 16
    optional: true,                                                                                                    // 17
    autoform: { type: 'hidden' }                                                                                       // 18
};                                                                                                                     // 14
                                                                                                                       //
ReleasedCreativeWork.description = {                                                                                   // 21
    type: String,                                                                                                      // 22
    label: 'Description',                                                                                              // 23
    optional: true,                                                                                                    // 24
    autoform: { type: 'textarea' }                                                                                     // 25
};                                                                                                                     // 21
                                                                                                                       //
ReleasedCreativeWork.metaWhiteList = {                                                                                 // 28
    type: [String],                                                                                                    // 29
    label: 'Permitted to see',                                                                                         // 30
    optional: true                                                                                                     // 31
};                                                                                                                     // 28
                                                                                                                       //
ReleasedCreativeWork.contentWhiteList = {                                                                              // 34
    type: [String],                                                                                                    // 35
    label: 'Permitted to access',                                                                                      // 36
    optional: true                                                                                                     // 37
};                                                                                                                     // 34
                                                                                                                       //
RemoteApps.attachSchema(new SimpleSchema([remoteMeta, AppSchema, ReleasedCreativeWork]));                              // 40
RemoteDatasets.attachSchema(new SimpleSchema([remoteMeta, DatasetSchema, ReleasedCreativeWork]));                      // 41
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"config":{"at_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/config/at_config.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
function ldapOrUserPass(error, state) {                                                                                // 1
    console.log({ error: error, state: state });                                                                       // 2
    if (error && state === 'signIn' //user/pass login failed                                                           // 3
    && orion.dictionary.get('ldap.ldap') && orion.dictionary.get('ldap.ldap').length !== 0) {                          // 3
                                                                                                                       //
        var username = document.getElementById("at-field-username_and_email").value;                                   // 7
        pass = document.getElementById("at-field-password").value;                                                     // 8
                                                                                                                       //
        Meteor.loginWithLdap(username, pass, function (err) {                                                          // 10
            if (err) {                                                                                                 // 11
                var errSpan = $('.at-form .at-error span');                                                            // 12
                errSpan.html('<i class="mdi-alert-warning"></i> ' + err.reason);                                       // 13
            }                                                                                                          // 14
        });                                                                                                            // 15
    }                                                                                                                  // 16
}                                                                                                                      // 17
// Options                                                                                                             // 18
AccountsTemplates.configure({                                                                                          // 19
    // defaultLayout: 'emptyLayout',                                                                                   // 20
    showForgotPasswordLink: true,                                                                                      // 21
    overrideLoginErrors: false,                                                                                        // 22
    enablePasswordChange: true,                                                                                        // 23
                                                                                                                       //
    sendVerificationEmail: false,                                                                                      // 25
    // enforceEmailVerification: true,                                                                                 // 26
    confirmPassword: true,                                                                                             // 27
    //continuousValidation: false,                                                                                     // 28
    //displayFormLabels: true,                                                                                         // 29
    forbidClientAccountCreation: false,                                                                                // 30
    //formValidationFeedback: true,                                                                                    // 31
    homeRoutePath: '/',                                                                                                // 32
    //showAddRemoveServices: false,                                                                                    // 33
    showPlaceholders: true,                                                                                            // 34
    lowercaseUsername: true,                                                                                           // 35
    onSubmitHook: ldapOrUserPass,                                                                                      // 36
    continuousValidation: true,                                                                                        // 37
    negativeValidation: true,                                                                                          // 38
    positiveValidation: true,                                                                                          // 39
    negativeFeedback: false,                                                                                           // 40
    positiveFeedback: true                                                                                             // 41
                                                                                                                       //
});                                                                                                                    // 19
                                                                                                                       //
var pwd = AccountsTemplates.removeField('password');                                                                   // 48
AccountsTemplates.removeField('email');                                                                                // 49
AccountsTemplates.addFields([{                                                                                         // 50
    _id: "username",                                                                                                   // 52
    type: "text",                                                                                                      // 53
    displayName: "username",                                                                                           // 54
    required: true,                                                                                                    // 55
    minLength: 4                                                                                                       // 56
}, {                                                                                                                   // 51
    _id: 'email',                                                                                                      // 59
    type: 'email',                                                                                                     // 60
    required: true,                                                                                                    // 61
    displayName: "email",                                                                                              // 62
    re: /.+@(.+){2,}\.(.+){2,}/,                                                                                       // 63
    errStr: 'Invalid email'                                                                                            // 64
}, {                                                                                                                   // 58
    _id: 'username_and_email',                                                                                         // 67
    type: 'text',                                                                                                      // 68
    required: true,                                                                                                    // 69
    displayName: "Login"                                                                                               // 70
}, pwd]);                                                                                                              // 66
                                                                                                                       //
AccountsTemplates.addField({                                                                                           // 75
    _id: "isgroup",                                                                                                    // 76
    type: "checkbox",                                                                                                  // 77
    displayName: "This is a group/organisational account"                                                              // 78
});                                                                                                                    // 75
                                                                                                                       //
AccountsTemplates.addFields([{                                                                                         // 81
    _id: "url",                                                                                                        // 82
    type: "text",                                                                                                      // 83
    displayName: "Home page"                                                                                           // 84
}, {                                                                                                                   // 81
    _id: "description",                                                                                                // 86
    type: "text",                                                                                                      // 87
    displayName: "A brief description of this account"                                                                 // 88
}]);                                                                                                                   // 85
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"roles":{"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/_utils.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
//register actions                                                                                                     // 1
Roles.registerAction("collections.entries.access", true);                                                              // 2
                                                                                                                       //
Roles.debug = true;                                                                                                    // 4
                                                                                                                       //
// check that the userId specified owns the documents                                                                  // 6
ownsDocument = function ownsDocument(userId, doc) {                                                                    // 7
    return doc && doc.publisher === userId || Roles.userHasRole(userId, "admin");                                      // 8
};                                                                                                                     // 9
                                                                                                                       //
ownsDocumentQuery = function ownsDocumentQuery() {                                                                     // 11
    return { publisher: this.userId };                                                                                 // 12
};                                                                                                                     // 13
                                                                                                                       //
viewsDocument = function (_viewsDocument) {                                                                            // 15
    function viewsDocument(_x, _x2) {                                                                                  // 15
        return _viewsDocument.apply(this, arguments);                                                                  // 15
    }                                                                                                                  // 15
                                                                                                                       //
    viewsDocument.toString = function () {                                                                             // 15
        return _viewsDocument.toString();                                                                              // 15
    };                                                                                                                 // 15
                                                                                                                       //
    return viewsDocument;                                                                                              // 15
}(function (userId, doc) {                                                                                             // 15
    if (!userId) {                                                                                                     // 16
        return doc.aclMeta;                                                                                            // 17
    }                                                                                                                  // 18
                                                                                                                       //
    if (doc) {                                                                                                         // 20
        return doc.aclMeta // publicly listed entries                                                                  // 21
        || ownsDocument(userId, doc) // own entries                                                                    // 21
        || doc.metaWhiteList && _.contains(doc.metaWhiteList, userId) // white-listed user                             // 21
        || Groups.find({ contentWhiteList: userId }).fetch().some(function (group) {                                   // 21
            return viewsDocument(group.publisher, doc);                                                                // 24
        }); // member of white-listed groups, for null userId returning true if group doesn't have contentWhhiteList property
    } else {                                                                                                           // 25
        return false;                                                                                                  // 26
    }                                                                                                                  // 27
});                                                                                                                    // 28
                                                                                                                       //
accessesDocument = function (_accessesDocument) {                                                                      // 30
    function accessesDocument(_x3, _x4) {                                                                              // 30
        return _accessesDocument.apply(this, arguments);                                                               // 30
    }                                                                                                                  // 30
                                                                                                                       //
    accessesDocument.toString = function () {                                                                          // 30
        return _accessesDocument.toString();                                                                           // 30
    };                                                                                                                 // 30
                                                                                                                       //
    return accessesDocument;                                                                                           // 30
}(function (userId, doc) {                                                                                             // 30
    if (!userId) {                                                                                                     // 31
        return doc.aclContent;                                                                                         // 32
    }                                                                                                                  // 33
                                                                                                                       //
    if (doc) {                                                                                                         // 35
        return doc.aclContent || ownsDocument(userId, doc) || doc.contentWhiteList && _.contains(doc.contentWhiteList, userId) || Groups.find({ contentWhiteList: userId }).fetch().some(function (group) {
            return accessesDocument(group.publisher, doc);                                                             // 39
        }); // member of white-listed groups                                                                           // 39
    } else {                                                                                                           // 40
        return false;                                                                                                  // 41
    }                                                                                                                  // 42
});                                                                                                                    // 43
                                                                                                                       //
viewsDocumentQuery = function viewsDocumentQuery(userId) {                                                             // 45
                                                                                                                       //
    //anonymous user default                                                                                           // 47
    var query = { $or: [{ aclMeta: true }] };                                                                          // 48
                                                                                                                       //
    //logged in user                                                                                                   // 50
    if (userId) {                                                                                                      // 51
        //admin user                                                                                                   // 52
        if (Roles.userHasRole(userId, "admin")) {                                                                      // 53
            query = { $or: [{}] };                                                                                     // 54
        } else {                                                                                                       // 55
            //individual or group user                                                                                 // 56
            query = { $or: [{ aclMeta: true }, { metaWhiteList: userId }, { publisher: userId }, { contentWhiteList: userId }] }; //individual permission
            var groups = Groups.find({ contentWhiteList: userId });                                                    // 58
            //group permission                                                                                         // 59
            groups.forEach(function (group) {                                                                          // 60
                query.$or.push({ metaWhiteList: group.publisher });                                                    // 61
            });                                                                                                        // 62
        }                                                                                                              // 63
    }                                                                                                                  // 64
                                                                                                                       //
    return query;                                                                                                      // 66
};                                                                                                                     // 67
                                                                                                                       //
isMemberQuery = function isMemberQuery() {                                                                             // 69
    return { contentWhiteList: this.userId };                                                                          // 70
};                                                                                                                     // 71
                                                                                                                       //
//set @Role's permission according to @colRules                                                                        // 73
//@colRules is of the form {collection_name: [allowed_field]}                                                          // 74
//if allowed_field is a string set permission to true                                                                  // 75
//if allowed_field is a function, compute permission using the function                                                // 76
setCollectionGrants = function setCollectionGrants(Role, colRules) {                                                   // 77
    for (var colName in meteorBabelHelpers.sanitizeForInObject(colRules)) {                                            // 78
        if (colRules.hasOwnProperty(colName)) {                                                                        // 79
            setRuleArray(Role, colName, colRules[colName]);                                                            // 80
        }                                                                                                              // 81
    }                                                                                                                  // 82
};                                                                                                                     // 83
                                                                                                                       //
function setRuleArray(Role, colName, fields) {                                                                         // 85
                                                                                                                       //
    for (var action in meteorBabelHelpers.sanitizeForInObject(fields)) {                                               // 87
        if (fields.hasOwnProperty(action)) {                                                                           // 88
            var field = fields[action];                                                                                // 89
                                                                                                                       //
            if (typeof field === 'string') {                                                                           // 91
                Role.allow('collections.' + colName + '.' + field, true);                                              // 92
            }                                                                                                          // 93
                                                                                                                       //
            if (typeof field === 'function') {                                                                         // 95
                Role.allow('collections.' + colName + '.' + action, field);                                            // 96
            }                                                                                                          // 97
        }                                                                                                              // 98
    }                                                                                                                  // 99
};                                                                                                                     // 100
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"group.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/group.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 24/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var Molecule = new Roles.Role('group'),                                                                                // 5
    grants = {                                                                                                         // 5
    entries: {                                                                                                         // 7
        access: function () {                                                                                          // 8
            function access(entry) {                                                                                   // 7
                return accessesDocument(this.userId, entry);                                                           // 9
            }                                                                                                          // 10
                                                                                                                       //
            return access;                                                                                             // 7
        }()                                                                                                            // 7
    },                                                                                                                 // 7
    groups: ['index', 'update', 'showUpdate'],                                                                         // 12
    datasets: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                     // 13
    apps: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                         // 14
    licenses: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                       // 15
    client: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove']                          // 16
};                                                                                                                     // 6
                                                                                                                       //
setCollectionGrants(Molecule, grants);                                                                                 // 19
                                                                                                                       //
Molecule.helper('collections.groups.indexFilter', ownsDocumentQuery);                                                  // 21
Molecule.helper('collections.datasets.indexFilter', ownsDocumentQuery);                                                // 22
Molecule.helper('collections.apps.indexFilter', ownsDocumentQuery);                                                    // 23
Molecule.helper('collections.client.indexFilter', ownsDocumentQuery);                                                  // 24
Molecule.helper('collections.licenses.indexFilter', ownsDocumentQuery);                                                // 25
                                                                                                                       //
//forbidden fields                                                                                                     // 27
Molecule.helper('collections.datasets.forbiddenFields', omitFields);                                                   // 28
Molecule.helper('collections.apps.forbiddenFields', omitFields);                                                       // 29
Molecule.helper('collections.licenses.forbiddenFields', ['publisher', 'datePublished']);                               // 30
Molecule.helper('collections.client.forbiddenFields', ['secret', 'user', 'dateCreated']);                              // 31
//Molecule.helper('collections.comments.forbiddenFields', ['publisher', 'entryId', 'submitted']);                      // 32
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"individual.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/roles/individual.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
Options.set('defaultRoles', ['individual']);                                                                           // 1
/*                                                                                                                     // 2
 * First you must define the role                                                                                      //
 */                                                                                                                    //
var Atom = new Roles.Role('individual'),                                                                               // 5
    grants = {                                                                                                         // 5
    entries: {                                                                                                         // 7
        access: function () {                                                                                          // 8
            function access(entry) {                                                                                   // 7
                return accessesDocument(this.userId, entry);                                                           // 9
            }                                                                                                          // 10
                                                                                                                       //
            return access;                                                                                             // 7
        }()                                                                                                            // 7
    },                                                                                                                 // 7
    datasets: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                     // 12
    apps: ['index', 'insert', 'update', 'remove', 'showUpdate', 'showRemove'],                                         // 13
    client: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                         // 14
    licenses: ['index', 'insert', 'update', 'remove', 'showCreate', 'showUpdate', 'showRemove'],                       // 15
    comments: ['index'],                                                                                               // 16
    groups: ['index']                                                                                                  // 17
};                                                                                                                     // 6
                                                                                                                       //
setCollectionGrants(Atom, grants);                                                                                     // 20
                                                                                                                       //
Atom.helper('collections.datasets.indexFilter', ownsDocumentQuery);                                                    // 22
Atom.helper('collections.apps.indexFilter', ownsDocumentQuery);                                                        // 23
Atom.helper('collections.client.indexFilter', ownsDocumentQuery);                                                      // 24
Atom.helper('collections.licenses.indexFilter', ownsDocumentQuery);                                                    // 25
Atom.helper('collections.comments.indexFilter', ownsDocumentQuery);                                                    // 26
Atom.helper('collections.groups.indexFilter', isMemberQuery);                                                          // 27
                                                                                                                       //
//forbidden fields                                                                                                     // 29
//will cause access denied issue when creating new entries                                                             // 30
// Atom.helper('collections.datasets.forbiddenFields', omitFields);                                                    // 31
// Atom.helper('collections.apps.forbiddenFields', omitFields);                                                        // 32
//Atom.helper('collections.licenses.forbiddenFields', ['publisher', 'datePublished']);                                 // 33
//Atom.helper('collections.client.forbiddenFields', ['clientSecret', 'publisher', 'datePublished']);                   // 34
//Atom.helper('collections.comments.forbiddenFields', ['publisher', 'entryId', 'submitted']);                          // 35
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/_utils.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 15/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
/*                                                                                                                     // 5
 * Extends @query with @or clause                                                                                      //
 * If @query.$or exists, replace it with $and:[{$or:query.$or}, or]                                                    //
 */                                                                                                                    //
extendOr = function extendOr(query, or) {                                                                              // 9
    check(query, Object);                                                                                              // 10
    check(or, { $or: Array });                                                                                         // 11
                                                                                                                       //
    if (query.$or) {                                                                                                   // 13
        query.$and = [{ $or: query.$or }, or];                                                                         // 14
        delete query.$or;                                                                                              // 15
    } else {                                                                                                           // 16
        _.extend(query, or);                                                                                           // 17
    }                                                                                                                  // 18
};                                                                                                                     // 19
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_config.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_config.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 20/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
orion.config.add('wo_urls', 'WO', { type: [String], label: 'WO URLs' });                                               // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_dictionary.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_dictionary.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
// orion.dictionary.addDefinition('image', 'comment',                                                                  // 1
//   orion.attribute('image', {                                                                                        // 2
//       label: 'Comment Image',                                                                                       // 3
//       optional: true                                                                                                // 4
//   })                                                                                                                // 5
// );                                                                                                                  // 6
                                                                                                                       //
orion.dictionary.addDefinition('title', 'mainPage', {                                                                  // 8
    type: String,                                                                                                      // 9
    label: 'Site Title',                                                                                               // 10
    optional: false,                                                                                                   // 11
    min: 1,                                                                                                            // 12
    max: 40                                                                                                            // 13
});                                                                                                                    // 8
                                                                                                                       //
orion.dictionary.addDefinition('description', 'mainPage', {                                                            // 16
    type: String,                                                                                                      // 17
    label: 'Site Description',                                                                                         // 18
    optional: true                                                                                                     // 19
});                                                                                                                    // 16
                                                                                                                       //
orion.dictionary.addDefinition('termsAndConditions', 'submitPostPage', {                                               // 23
    type: String,                                                                                                      // 24
    label: 'Terms and Conditions',                                                                                     // 25
    optional: true                                                                                                     // 26
});                                                                                                                    // 23
                                                                                                                       //
//ldap                                                                                                                 // 30
var ldapSchema = new SimpleSchema({                                                                                    // 31
    domain: { type: String },                                                                                          // 32
    serverDn: { type: String, label: 'Server DN' },                                                                    // 33
    serverUrl: { type: String, label: 'Server Url' },                                                                  // 34
    whiteListedFields: { type: String, label: 'Included fields' }                                                      // 35
});                                                                                                                    // 31
                                                                                                                       //
orion.dictionary.addDefinition('ldap', 'ldap', { type: [ldapSchema] });                                                // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"orion_filesystem.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/orion_filesystem.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
///**                                                                                                                  // 1
// * Official S3 Upload Provider                                                                                       // 2
// *                                                                                                                   // 3
// * Please replace this function with the                                                                             // 4
// * provider you prefer.                                                                                              // 5
// *                                                                                                                   // 6
// * If success, call success(publicUrl);                                                                              // 7
// * you can pass data and it will be saved in file.meta                                                               // 8
// * Ej: success(publicUrl, {local_path: '/user/path/to/file'})                                                        // 9
// *                                                                                                                   // 10
// * If it fails, call failure(error).                                                                                 // 11
// *                                                                                                                   // 12
// * When the progress change, call progress(newProgress)                                                              // 13
// */                                                                                                                  // 14
//orion.filesystem.providerUpload = function(options, success, failure, progress) {                                    // 15
//  S3.upload({                                                                                                        // 16
//    files: options.fileList,                                                                                         // 17
//    path: 'orionjs',                                                                                                 // 18
//  }, function(error, result) {                                                                                       // 19
//    debugger                                                                                                         // 20
//    if (error) {                                                                                                     // 21
//      failure(error);                                                                                                // 22
//    } else {                                                                                                         // 23
//      success(result.secure_url, { s3Path: result.relative_url });                                                   // 24
//      result;                                                                                                        // 25
//      debugger                                                                                                       // 26
//    }                                                                                                                // 27
//    S3.collection.remove({})                                                                                         // 28
//  });                                                                                                                // 29
//  Tracker.autorun(function () {                                                                                      // 30
//    let file = S3.collection.findOne();                                                                              // 31
//    if (file) {                                                                                                      // 32
//      progress(file.percent_uploaded);                                                                               // 33
//    }                                                                                                                // 34
//  });                                                                                                                // 35
//};                                                                                                                   // 36
//                                                                                                                     // 37
///**                                                                                                                  // 38
// * Official S3 Remove Provider                                                                                       // 39
// *                                                                                                                   // 40
// * Please replace this function with the                                                                             // 41
// * provider you prefer.                                                                                              // 42
// *                                                                                                                   // 43
// * If success, call success();                                                                                       // 44
// * If it fails, call failure(error).                                                                                 // 45
// */                                                                                                                  // 46
//orion.filesystem.providerRemove = function(file, success, failure)  {                                                // 47
//  S3.delete(file.meta.s3Path, function(error, result) {                                                              // 48
//    if (error) {                                                                                                     // 49
//      failure(error);                                                                                                // 50
//    } else {                                                                                                         // 51
//      success();                                                                                                     // 52
//    }                                                                                                                // 53
//  })                                                                                                                 // 54
//};                                                                                                                   // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"router.js":["babel-runtime/helpers/toConsumableArray",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// lib/router.js                                                                                                       //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray;module.import('babel-runtime/helpers/toConsumableArray',{"default":function(v){_toConsumableArray=v}});
Router.configure({                                                                                                     // 1
    layoutTemplate: 'layout',                                                                                          // 2
    loadingTemplate: 'loading',                                                                                        // 3
    notFoundTemplate: 'notFound',                                                                                      // 4
    subscriptions: function () {                                                                                       // 5
        function subscriptions() {                                                                                     // 1
            //using waitOn will cause entry_list to reload every time load-more is clicked                             // 5
            return [Meteor.subscribe(Notifications._name), Meteor.subscribe(Groups._name), Meteor.subscribe(Meteor.users._name), Meteor.subscribe(Licenses._name)];
        }                                                                                                              // 12
                                                                                                                       //
        return subscriptions;                                                                                          // 1
    }()                                                                                                                // 1
});                                                                                                                    // 1
                                                                                                                       //
ListController = RouteController.extend({                                                                              // 15
    template: 'entryList',                                                                                             // 16
    increment: 12,                                                                                                     // 17
    //query modifier generation helper                                                                                 // 18
    entriesLimit: function () {                                                                                        // 19
        function entriesLimit() {                                                                                      // 15
            return parseInt(this.params.entriesLimit) || this.increment;                                               // 20
        }                                                                                                              // 21
                                                                                                                       //
        return entriesLimit;                                                                                           // 15
    }(),                                                                                                               // 15
                                                                                                                       //
    //query modifier generator                                                                                         // 22
    findOptions: function () {                                                                                         // 23
        function findOptions() {                                                                                       // 15
            return { sort: this.sort, limit: this.entriesLimit() };                                                    // 24
        }                                                                                                              // 25
                                                                                                                       //
        return findOptions;                                                                                            // 15
    }(),                                                                                                               // 15
                                                                                                                       //
    //query generator                                                                                                  // 26
    findSelector: function () {                                                                                        // 27
        function findSelector() {                                                                                      // 15
            var textFilter = search(Session.get('search'));                                                            // 28
            var query = {},                                                                                            // 29
                _query = this.params.query;                                                                            // 29
                                                                                                                       //
            _.keys(_query).forEach(function (key) {                                                                    // 31
                // console.log(key);                                                                                   // 32
                switch (key) {                                                                                         // 33
                    case 'online':                                                                                     // 34
                    case 'aclMeta':                                                                                    // 35
                    case 'aclContent':                                                                                 // 36
                        query[key] = _query[key].toLowerCase() === 'true';                                             // 37
                        break;                                                                                         // 38
                    default:                                                                                           // 39
                        query[key] = _query[key];                                                                      // 40
                }                                                                                                      // 33
            });                                                                                                        // 42
                                                                                                                       //
            _.extend(query, textFilter);                                                                               // 44
                                                                                                                       //
            ////this function runs twice due to reactivity (subscriptions)                                             // 46
            ////set findSelector to return the computed query straight away                                            // 47
            ////in the second run                                                                                      // 48
            //this.findSelector = function () {                                                                        // 49
            //    return query;                                                                                        // 50
            //}                                                                                                        // 51
            return query;                                                                                              // 52
        }                                                                                                              // 53
                                                                                                                       //
        return findSelector;                                                                                           // 15
    }(),                                                                                                               // 15
                                                                                                                       //
    //collection of entries (e.g. Apps, Datasets)                                                                      // 54
    category: null, //overrided in sub controllers                                                                     // 55
    //displayed entries                                                                                                // 56
    entries: function () {                                                                                             // 57
        function entries() {                                                                                           // 15
            return this.category.find({}, { sort: this.findOptions.sort });                                            // 58
        }                                                                                                              // 59
                                                                                                                       //
        return entries;                                                                                                // 15
    }(),                                                                                                               // 15
                                                                                                                       //
    // helper to generate route names of a given category;                                                             // 60
    // a workaround since cannot dynamically concatenate variables in templates                                        // 61
    routes: function () {                                                                                              // 62
        function routes() {                                                                                            // 15
            var cat = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.category.singularName;  // 62
                                                                                                                       //
            return ['latest', 'page', 'submit', 'edit'].reduce(function (routes, action) {                             // 63
                routes[action] = cat + '.' + action;                                                                   // 64
                return routes;                                                                                         // 65
            }, {});                                                                                                    // 66
        }                                                                                                              // 67
                                                                                                                       //
        return routes;                                                                                                 // 15
    }(),                                                                                                               // 15
    data: function () {                                                                                                // 68
        function data() {                                                                                              // 15
            var self = this;                                                                                           // 69
            return {                                                                                                   // 70
                category: self.category,                                                                               // 71
                entries: self.entries(),                                                                               // 72
                //show search bar in top nav on entry list page                                                        // 73
                showSearch: true,                                                                                      // 74
                //show Add button if logged in                                                                         // 75
                showAdd: true,                                                                                         // 76
                ready: self.ready.bind(self),                                                                          // 77
                routes: self.routes(),                                                                                 // 78
                //generate path to load next page of entries                                                           // 79
                nextPath: function () {                                                                                // 80
                    function nextPath() {                                                                              // 70
                        if (self.category.find().count() === self.entriesLimit()) {                                    // 81
                            return self.nextPath();                                                                    // 82
                        }                                                                                              // 83
                    }                                                                                                  // 84
                                                                                                                       //
                    return nextPath;                                                                                   // 70
                }()                                                                                                    // 70
            };                                                                                                         // 70
        }                                                                                                              // 86
                                                                                                                       //
        return data;                                                                                                   // 15
    }()                                                                                                                // 15
});                                                                                                                    // 15
                                                                                                                       //
RegExp.prototype.toJSONValue = function () {                                                                           // 89
    var flags = '';                                                                                                    // 90
    if (this.global) {                                                                                                 // 91
        flags += 'g';                                                                                                  // 92
    }                                                                                                                  // 93
    if (this.ignoreCase) {                                                                                             // 94
        flags += 'i';                                                                                                  // 95
    }                                                                                                                  // 96
    if (this.multiline) {                                                                                              // 97
        flags += 'm';                                                                                                  // 98
    }                                                                                                                  // 99
    return [this.source, flags];                                                                                       // 100
};                                                                                                                     // 101
                                                                                                                       //
RegExp.prototype.typeName = function () {                                                                              // 103
    return "regex";                                                                                                    // 104
};                                                                                                                     // 105
                                                                                                                       //
EJSON.addType("regex", function (str) {                                                                                // 107
    return new (Function.prototype.bind.apply(RegExp, [null].concat(_toConsumableArray(str))))();                      // 108
});                                                                                                                    // 109
                                                                                                                       //
function search(searchText) {                                                                                          // 111
    var selector = void 0;                                                                                             // 112
    if (searchText) {                                                                                                  // 113
        var regExp = buildRegExp(searchText);                                                                          // 114
        selector = {                                                                                                   // 115
            $or: [{ name: regExp }, { description: regExp }, { 'distribution.fileFormat': regExp }]                    // 116
        };                                                                                                             // 115
    } else {                                                                                                           // 122
        selector = {};                                                                                                 // 123
    }                                                                                                                  // 124
                                                                                                                       //
    return selector;                                                                                                   // 126
}                                                                                                                      // 127
                                                                                                                       //
//any position                                                                                                         // 129
function buildRegExp(searchText) {                                                                                     // 130
    var parts = searchText.trim().split(/[ \-\:]+/);                                                                   // 131
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 132
}                                                                                                                      // 133
                                                                                                                       //
//type ahead                                                                                                           // 135
//function buildRegExp(searchText) {                                                                                   // 136
//    let words = searchText.trim().split(/[ \-\:]+/);                                                                 // 137
//    let exps = _.map(words, function (word) {                                                                        // 138
//        return "(?=.*" + word + ")";                                                                                 // 139
//    });                                                                                                              // 140
//    let fullExp = exps.join('') + ".+";                                                                              // 141
//    return new RegExp(fullExp, "i");                                                                                 // 142
//}                                                                                                                    // 143
/***************************                                                                                           // 144
 * entry list                                                                                                          //
 **************************/                                                                                           //
LatestController = ListController.extend({                                                                             // 147
    subscriptions: function () {                                                                                       // 148
        function subscriptions() {                                                                                     // 147
            return Meteor.subscribe(this.category._name, this.findOptions(), this.findSelector());                     // 149
        }                                                                                                              // 150
                                                                                                                       //
        return subscriptions;                                                                                          // 147
    }(),                                                                                                               // 147
                                                                                                                       //
    sort: { datePublished: -1, votes: -1, downvotes: 1, _id: -1 },                                                     // 151
    nextPath: function () {                                                                                            // 152
        function nextPath() {                                                                                          // 147
            return Router.routes[this.category.singularName + '.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });
        }                                                                                                              // 154
                                                                                                                       //
        return nextPath;                                                                                               // 147
    }()                                                                                                                // 147
});                                                                                                                    // 147
                                                                                                                       //
DatasetLatestController = LatestController.extend({                                                                    // 157
    category: Datasets                                                                                                 // 158
});                                                                                                                    // 157
                                                                                                                       //
RemotedatasetLatestController = LatestController.extend({                                                              // 161
    category: RemoteDatasets                                                                                           // 162
});                                                                                                                    // 161
                                                                                                                       //
AppLatestController = LatestController.extend({                                                                        // 165
    category: Apps                                                                                                     // 166
});                                                                                                                    // 165
                                                                                                                       //
RemoteappLatestController = LatestController.extend({                                                                  // 169
    category: RemoteApps                                                                                               // 170
});                                                                                                                    // 169
                                                                                                                       //
GroupLatestController = LatestController.extend({                                                                      // 173
    category: Groups,                                                                                                  // 174
    nextPath: function () {                                                                                            // 175
        function nextPath() {                                                                                          // 173
            return Router.routes['group.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });         // 176
        }                                                                                                              // 177
                                                                                                                       //
        return nextPath;                                                                                               // 173
    }()                                                                                                                // 173
});                                                                                                                    // 173
/***************************                                                                                           // 179
 * entry page                                                                                                          //
 **************************/                                                                                           //
PageController = ListController.extend({                                                                               // 182
    template: 'entryPage',                                                                                             // 183
    subscriptions: function () {                                                                                       // 184
        function subscriptions() {                                                                                     // 182
            return [Meteor.subscribe('comments', this.params._id), Meteor.subscribe(this.category.singularName, this.params._id)];
        }                                                                                                              // 187
                                                                                                                       //
        return subscriptions;                                                                                          // 182
    }(),                                                                                                               // 182
    data: function () {                                                                                                // 188
        function data() {                                                                                              // 182
            return {                                                                                                   // 189
                comments: Comments.find({ entryId: this.params._id }),                                                 // 190
                category: this.category,                                                                               // 191
                entry: this.category.findOne(this.params._id),                                                         // 192
                routes: this.routes(this.category.singularName)                                                        // 193
            };                                                                                                         // 189
        }                                                                                                              // 196
                                                                                                                       //
        return data;                                                                                                   // 182
    }()                                                                                                                // 182
});                                                                                                                    // 182
                                                                                                                       //
DatasetPageController = PageController.extend({                                                                        // 199
    category: Datasets                                                                                                 // 200
});                                                                                                                    // 199
                                                                                                                       //
RemotedatasetPageController = PageController.extend({                                                                  // 203
    category: RemoteDatasets                                                                                           // 204
});                                                                                                                    // 203
                                                                                                                       //
AppPageController = PageController.extend({                                                                            // 207
    category: Apps                                                                                                     // 208
});                                                                                                                    // 207
                                                                                                                       //
RemoteappPageController = PageController.extend({                                                                      // 211
    category: RemoteApps                                                                                               // 212
});                                                                                                                    // 211
                                                                                                                       //
GroupPageController = PageController.extend({                                                                          // 215
    category: Groups                                                                                                   // 216
});                                                                                                                    // 215
                                                                                                                       //
function templateData(router, col, option) {                                                                           // 219
    return {                                                                                                           // 220
        category: col,                                                                                                 // 221
        routes: router.routes(col.singularName),                                                                       // 222
        entries: router.getEntries(option, col),                                                                       // 223
        ready: router.ready.bind(router)                                                                               // 224
    };                                                                                                                 // 220
}                                                                                                                      // 226
                                                                                                                       //
HomeController = ListController.extend({                                                                               // 228
    template: 'home',                                                                                                  // 229
    increment: 8,                                                                                                      // 230
    sort: { votes: -1, downvotes: 1, datePublished: -1, _id: -1 },                                                     // 231
    subscriptions: function () {                                                                                       // 232
        function subscriptions() {                                                                                     // 228
            var _this = this;                                                                                          // 232
                                                                                                                       //
            return [Datasets, Apps, RemoteDatasets, RemoteApps].map(function (col) {                                   // 233
                return Meteor.subscribe(col._name, _this.findOptions());                                               // 234
            });                                                                                                        // 234
        }                                                                                                              // 235
                                                                                                                       //
        return subscriptions;                                                                                          // 228
    }(),                                                                                                               // 228
    getEntries: function () {                                                                                          // 236
        function getEntries(options, col) {                                                                            // 228
            if (!options) options = this.findOptions();                                                                // 237
            return col.find({}, options);                                                                              // 239
        }                                                                                                              // 240
                                                                                                                       //
        return getEntries;                                                                                             // 228
    }(),                                                                                                               // 228
    nextPath: function () {                                                                                            // 241
        function nextPath() {                                                                                          // 228
            return Router.routes['datasets.latest'].path({ entriesLimit: this.entriesLimit() + this.increment });      // 242
        }                                                                                                              // 243
                                                                                                                       //
        return nextPath;                                                                                               // 228
    }(),                                                                                                               // 228
    data: function () {                                                                                                // 244
        function data() {                                                                                              // 228
            var homeTempData = templateData.bind(null, this);                                                          // 245
            var byPubData = { sort: { datePublished: -1 }, limit: 8 },                                                 // 246
                byVote = { sort: { votes: -1 }, limit: 8 };                                                            // 246
            // let self = this;                                                                                        // 248
            return {                                                                                                   // 249
                recentDataset: homeTempData(Datasets, byPubData),                                                      // 250
                recentApp: homeTempData(Apps, byPubData),                                                              // 251
                dataset: homeTempData(Datasets, byVote),                                                               // 252
                app: homeTempData(Apps, byVote),                                                                       // 253
                remoteApp: homeTempData(RemoteApps, byPubData),                                                        // 254
                remoteDataset: homeTempData(RemoteDatasets, byPubData),                                                // 255
                _isHome: true,                                                                                         // 256
                _isTemplated: true                                                                                     // 257
            };                                                                                                         // 249
        }                                                                                                              // 259
                                                                                                                       //
        return data;                                                                                                   // 228
    }()                                                                                                                // 228
});                                                                                                                    // 228
                                                                                                                       //
/****************************************************************                                                      // 262
 * Routes                                                                                                              //
 * Route naming schema {{coll.pluralName}}.{{action}}                                                                  //
 *****************************************************************/                                                    //
                                                                                                                       //
/*                                                                                                                     // 267
 * Home                                                                                                                //
 */                                                                                                                    //
                                                                                                                       //
Router.route('/', { name: 'home' });                                                                                   // 271
                                                                                                                       //
/*                                                                                                                     // 273
 * Geo API                                                                                                             //
 */                                                                                                                    //
                                                                                                                       //
Router.route('/geodata', {                                                                                             // 277
    template: 'geoapi',                                                                                                // 278
    name: 'geoapi',                                                                                                    // 279
    subscriptions: function () {                                                                                       // 280
        function subscriptions() {                                                                                     // 277
            // returning a subscription handle or an array of subscription handles                                     // 281
            // adds them to the wait list.                                                                             // 282
            return Meteor.subscribe('datasets', {});                                                                   // 283
        }                                                                                                              // 284
                                                                                                                       //
        return subscriptions;                                                                                          // 277
    }(),                                                                                                               // 277
    data: function () {                                                                                                // 285
        function data() {                                                                                              // 277
            return {                                                                                                   // 286
                category: Datasets,                                                                                    // 287
                col: 'Datasets',                                                                                       // 288
                entries: function () {                                                                                 // 289
                    function entries() {                                                                               // 286
                        return this.category.find({ 'distribution.profile.geodata': { $exists: true } });              // 290
                    }                                                                                                  // 291
                                                                                                                       //
                    return entries;                                                                                    // 286
                }()                                                                                                    // 286
            };                                                                                                         // 286
        }                                                                                                              // 293
                                                                                                                       //
        return data;                                                                                                   // 277
    }(),                                                                                                               // 277
                                                                                                                       //
    //default action                                                                                                   // 294
    action: function () {                                                                                              // 295
        function action() {                                                                                            // 277
            this.render();                                                                                             // 296
        }                                                                                                              // 297
                                                                                                                       //
        return action;                                                                                                 // 277
    }()                                                                                                                // 277
});                                                                                                                    // 277
                                                                                                                       //
function setUpRoutes(col) {                                                                                            // 301
    var hasRemote = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;                         // 301
                                                                                                                       //
    var sn = col.singularName,                                                                                         // 302
        pn = col.pluralName;                                                                                           // 302
                                                                                                                       //
    Router.route('/new/' + pn + '/:entriesLimit?', { name: sn + '.latest' });                                          // 304
                                                                                                                       //
    Router.route('/' + pn + '/submit', {                                                                               // 306
        template: 'entrySubmit',                                                                                       // 307
        name: sn + '.submit',                                                                                          // 308
        data: function () {                                                                                            // 309
            function data() {                                                                                          // 306
                return { category: col, col: pn.substr(0, 1).toUpperCase() + pn.substr(1) };                           // 310
            }                                                                                                          // 311
                                                                                                                       //
            return data;                                                                                               // 306
        }()                                                                                                            // 306
    });                                                                                                                // 306
                                                                                                                       //
    Router.route('/' + pn + '/:_id', { name: sn + '.page' });                                                          // 314
                                                                                                                       //
    Router.route('/' + pn + '/:_id/edit', {                                                                            // 316
        name: sn + '.edit',                                                                                            // 317
        template: 'entryEdit',                                                                                         // 318
        waitOn: function () {                                                                                          // 319
            function waitOn() {                                                                                        // 316
                return Meteor.subscribe(sn, this.params._id);                                                          // 320
            }                                                                                                          // 321
                                                                                                                       //
            return waitOn;                                                                                             // 316
        }(),                                                                                                           // 316
        data: function () {                                                                                            // 322
            function data() {                                                                                          // 316
                return {                                                                                               // 323
                    category: col,                                                                                     // 324
                    entry: col.findOne()                                                                               // 325
                };                                                                                                     // 323
            }                                                                                                          // 327
                                                                                                                       //
            return data;                                                                                               // 316
        }()                                                                                                            // 316
    });                                                                                                                // 316
                                                                                                                       //
    if (hasRemote) {                                                                                                   // 330
        Router.route('/new/remote_' + pn + '/:entriesLimit?', { name: 'remote' + sn + '.latest' });                    // 331
        Router.route('/remote_' + pn + '/:_id', { name: 'remote' + sn + '.page' });                                    // 332
    }                                                                                                                  // 333
}                                                                                                                      // 334
                                                                                                                       //
/*                                                                                                                     // 336
 * Datasets routes                                                                                                     //
 */                                                                                                                    //
setUpRoutes(Datasets, true);                                                                                           // 339
                                                                                                                       //
/*                                                                                                                     // 341
 * Apps routes                                                                                                         //
 */                                                                                                                    //
setUpRoutes(Apps, true);                                                                                               // 344
                                                                                                                       //
/*                                                                                                                     // 346
 * Groups                                                                                                              //
 */                                                                                                                    //
                                                                                                                       //
setUpRoutes(Groups);                                                                                                   // 350
                                                                                                                       //
/*                                                                                                                     // 352
 * Accounts                                                                                                            //
 */                                                                                                                    //
                                                                                                                       //
AccountsTemplates.configureRoute('changePwd');                                                                         // 356
AccountsTemplates.configureRoute('enrollAccount');                                                                     // 357
AccountsTemplates.configureRoute('forgotPwd');                                                                         // 358
AccountsTemplates.configureRoute('resetPwd');                                                                          // 359
AccountsTemplates.configureRoute('signIn', {                                                                           // 360
    redirect: function () {                                                                                            // 361
        function redirect() {                                                                                          // 361
            var ref = RouterLayer.getQueryParam('return_url'),                                                         // 362
                userId = Meteor.userId();                                                                              // 362
            if (ref && userId) {                                                                                       // 364
                Cookie.set("meteor_user_id", userId);                                                                  // 365
                Cookie.set("meteor_token", localStorage.getItem("Meteor.loginToken"));                                 // 366
                window.location.replace(ref);                                                                          // 367
            }                                                                                                          // 368
        }                                                                                                              // 369
                                                                                                                       //
        return redirect;                                                                                               // 361
    }()                                                                                                                // 361
});                                                                                                                    // 360
AccountsTemplates.configureRoute('signUp');                                                                            // 371
AccountsTemplates.configureRoute('verifyEmail');                                                                       // 372
                                                                                                                       //
/*                                                                                                                     // 374
 * Helpers                                                                                                             //
 */                                                                                                                    //
function requireLogin() {                                                                                              // 377
    if (!Meteor.user()) {                                                                                              // 378
        if (Meteor.loggingIn()) {                                                                                      // 379
            this.render(this.loadingTemplate);                                                                         // 380
        } else {                                                                                                       // 381
            this.render('accessDenied', { data: 'Please sign in.' });                                                  // 382
        }                                                                                                              // 383
    } else {                                                                                                           // 384
        this.next();                                                                                                   // 385
    }                                                                                                                  // 386
}                                                                                                                      // 387
                                                                                                                       //
//Router.onBeforeAction('dataNotFound', {only: 'dataset.page'});                                                       // 389
Router.onBeforeAction(requireLogin, { only: ['dataset.submit', 'dataset.edit', 'app.submit', 'app.edit'] });           // 390
                                                                                                                       //
Router.onBeforeAction(function () {                                                                                    // 392
    var _data = this.data();                                                                                           // 392
                                                                                                                       //
    var entry = _data.entry;                                                                                           // 392
    var category = _data.category;                                                                                     // 392
                                                                                                                       //
    if (Meteor.userId() && entry //should not be necessary                                                             // 394
    && ownsDocument(Meteor.userId(), entry)) {                                                                         // 394
        this.next();                                                                                                   // 396
    } else {                                                                                                           // 397
        this.render('accessDenied', { data: "You cannot edit others' " + category.singularName });                     // 398
    }                                                                                                                  // 399
}, { only: ['dataset.edit', 'app.edit'] });                                                                            // 400
                                                                                                                       //
Router.onBeforeAction(function () {                                                                                    // 402
    //using named function causes an error                                                                             // 402
    var _data2 = this.data();                                                                                          // 402
                                                                                                                       //
    var entry = _data2.entry;                                                                                          // 402
    var category = _data2.category;                                                                                    // 402
                                                                                                                       //
    if (!entry) {                                                                                                      // 404
        this.render('loading');                                                                                        // 405
    } else {                                                                                                           // 406
        if (viewsDocument(Meteor.userId(), entry)) {                                                                   // 407
            this.next();                                                                                               // 408
        } else {                                                                                                       // 409
            this.render('accessDenied', { data: "You cannot view this " + category.singularName });                    // 410
        }                                                                                                              // 411
    }                                                                                                                  // 412
}, { only: ['dataset.page', 'app.page'] });                                                                            // 413
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"server":{"api":{"resource_server":{"middlewares":{"content.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/content.js                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({default:function(){return accessData}});/**                                                             // 1
 * Created by xgfd on 08/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
function accessData(req, res) {                                                                                        // 5
    var id = req.params.id;                                                                                            // 6
    var _req$query = req.query;                                                                                        // 5
    var query = _req$query.query;                                                                                      // 5
    var collection = _req$query.collection;                                                                            // 5
    var options = _req$query.options;                                                                                  // 5
                                                                                                                       //
                                                                                                                       //
    if (query === undefined) {                                                                                         // 9
        res.json(new Meteor.Error(400, 'Require a valid query.'));                                                     // 10
    }                                                                                                                  // 11
                                                                                                                       //
    var dist = Datasets.findOne({ 'distribution._id': id }, { fields: { distribution: { $elemMatch: { _id: id } } } }).distribution[0];
                                                                                                                       //
    if (dist) {                                                                                                        // 15
        var type = dist.fileFormat;                                                                                    // 16
        if (['MongoDB', 'MySQL', 'SPARQL'].indexOf(type) !== -1) {                                                     // 17
            type = type.toLowerCase();                                                                                 // 18
            query = parseQuery(query, type);                                                                           // 19
            var args = [id];                                                                                           // 20
                                                                                                                       //
            if (collection) {                                                                                          // 22
                args.push(collection);                                                                                 // 23
            }                                                                                                          // 24
                                                                                                                       //
            args.push(query);                                                                                          // 26
                                                                                                                       //
            if (options) {                                                                                             // 28
                args.push(options);                                                                                    // 29
            }                                                                                                          // 30
                                                                                                                       //
            Meteor.apply(type + 'Query', args, function (err, result) {                                                // 32
                res.json(err || result);                                                                               // 33
            });                                                                                                        // 34
        } else {                                                                                                       // 35
            res.json(new Meteor.Error(500, 'Distribution type not supported'));                                        // 36
        }                                                                                                              // 37
    } else {                                                                                                           // 39
        res.json(new Meteor.Error(404, 'Invalid distribution id. Record not found.'));                                 // 40
    }                                                                                                                  // 41
}                                                                                                                      // 42
                                                                                                                       //
function parseQuery(q, type) {                                                                                         // 44
    if (type === 'mongodb') {                                                                                          // 45
        return JSON.parse(q);                                                                                          // 46
    } else {                                                                                                           // 47
        return q;                                                                                                      // 48
    }                                                                                                                  // 49
}                                                                                                                      // 50
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"metadata.js":["./utils",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/metadata.js                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({getEntryLst:function(){return getEntryLst},getEntry:function(){return getEntry}});var RESTCompose,absPath;module.import('./utils',{"RESTCompose":function(v){RESTCompose=v},"absPath":function(v){absPath=v}});/**
 * Created by xgfd on 08/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       //
function toREST(url, entry) {                                                                                          // 7
    return {                                                                                                           // 8
        href: url + '/' + entry._id,                                                                                   // 9
        rel: 'item',                                                                                                   // 10
        method: 'GET',                                                                                                 // 11
        name: entry.name                                                                                               // 12
    };                                                                                                                 // 8
}                                                                                                                      // 14
                                                                                                                       //
function lstHeaders(req) {                                                                                             // 16
    var headers = {                                                                                                    // 17
        title: req.path.split('/')[1],                                                                                 // 18
        opensearch: absPath(req) + '?query={queryString}'                                                              // 19
    };                                                                                                                 // 17
    return headers;                                                                                                    // 21
}                                                                                                                      // 22
                                                                                                                       //
function lstLinks(req) {                                                                                               // 24
    var collName = req.path.split('/')[1],                                                                             // 25
        coll = Mongo.Collection.get(collName);                                                                         // 25
    var selector = {};                                                                                                 // 27
                                                                                                                       //
    try {                                                                                                              // 29
        var queryString = req.query.query || '{}';                                                                     // 30
        selector = JSON.parse(queryString);                                                                            // 31
    } catch (err) {                                                                                                    // 32
        throw new Meteor.Error(500, 'Invalid query syntax', err);                                                      // 34
    }                                                                                                                  // 35
                                                                                                                       //
    var entries = [];                                                                                                  // 37
                                                                                                                       //
    if (coll) {                                                                                                        // 39
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 40
        entries = coll.find(selector).map(toREST.bind(null, absPath(req)));                                            // 41
    }                                                                                                                  // 42
    return entries;                                                                                                    // 43
}                                                                                                                      // 44
                                                                                                                       //
function entryHeaders(req) {                                                                                           // 46
    var collName = req.path.split('/')[1],                                                                             // 47
        coll = Mongo.Collection.get(collName);                                                                         // 47
    var id = req.params.id;                                                                                            // 49
                                                                                                                       //
    var headers = {};                                                                                                  // 51
                                                                                                                       //
    if (coll && id) {                                                                                                  // 53
        (function () {                                                                                                 // 53
            var selector = { _id: id };                                                                                // 54
            extendOr(selector, viewsDocumentQuery(req.user));                                                          // 55
            var entry = coll.findOne(selector);                                                                        // 56
            var pubProperties = ['name', 'description', 'license', 'creator', 'publisherName', 'datePublished', 'dateModified', 'keywords', 'votes', 'downbvotes', 'datasetTimeInterval', 'spatial', 'github', 'url'];
                                                                                                                       //
            pubProperties.forEach(function (p) {                                                                       // 59
                if (entry[p]) {                                                                                        // 60
                    headers[p] = entry[p];                                                                             // 61
                }                                                                                                      // 62
            });                                                                                                        // 63
                                                                                                                       //
            var distributions = entry.distribution;                                                                    // 66
            if (distributions) {                                                                                       // 67
                headers.distribution = distributions.map(function (d) {                                                // 68
                    delete d.file;                                                                                     // 69
                    delete d.profile;                                                                                  // 70
                    delete d.url;                                                                                      // 71
                    return d;                                                                                          // 72
                });                                                                                                    // 73
            }                                                                                                          // 74
        })();                                                                                                          // 53
    }                                                                                                                  // 75
                                                                                                                       //
    return headers;                                                                                                    // 77
}                                                                                                                      // 78
                                                                                                                       //
function entryLinks(req) {                                                                                             // 80
    var collName = req.path.split('/')[1],                                                                             // 81
        coll = Mongo.Collection.get(collName);                                                                         // 81
    var id = req.params.id;                                                                                            // 83
    var thisUrl = absPath(req);                                                                                        // 84
                                                                                                                       //
    var links = [{ href: thisUrl.substring(0, thisUrl.lastIndexOf('/')), rel: 'collection', method: 'GET' }];          // 86
                                                                                                                       //
    if (coll && id) {                                                                                                  // 88
        var selector = { _id: id };                                                                                    // 89
        extendOr(selector, viewsDocumentQuery(req.user));                                                              // 90
        var entry = coll.findOne(selector);                                                                            // 91
        if (entry && entry.distribution) {                                                                             // 92
            var distributions = entry.distribution;                                                                    // 93
            links = links.concat(distributions.map(function (d) {                                                      // 94
                return {                                                                                               // 94
                    href: thisUrl + '/' + d._id + '?query={queryString}&collection={MongoDBCollection}&options{MongoDBQueryOptions}',
                    rel: 'distribution',                                                                               // 96
                    method: 'GET',                                                                                     // 97
                    fileFormat: d.fileFormat                                                                           // 98
                };                                                                                                     // 94
            }));                                                                                                       // 94
        }                                                                                                              // 100
    }                                                                                                                  // 101
                                                                                                                       //
    return links;                                                                                                      // 103
}                                                                                                                      // 104
                                                                                                                       //
var getEntryLst = RESTCompose(lstHeaders, lstLinks),                                                                   // 106
    getEntry = RESTCompose(entryHeaders, entryLinks);                                                                  // 106
                                                                                                                       //
                                                                                                                       // 109
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"utils.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/middlewares/utils.js                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({RESTCompose:function(){return RESTCompose},absPath:function(){return absPath}});/**                     // 1
 *                                                                                                                     //
 * Created by xgfd on 08/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
function relSelf(req) {                                                                                                // 6
    var href = absPath(req);                                                                                           // 7
    var method = req.method;                                                                                           // 8
                                                                                                                       //
    return {                                                                                                           // 10
        href: href,                                                                                                    // 11
        rel: 'self',                                                                                                   // 12
        method: method                                                                                                 // 13
    };                                                                                                                 // 10
}                                                                                                                      // 15
                                                                                                                       //
function RESTCompose(headers, links) {                                                                                 // 17
    return function (req, res) {                                                                                       // 18
        try {                                                                                                          // 19
            var apiRes = headers instanceof Function ? headers(req) : headers || {};                                   // 20
            var linksArr = links instanceof Function ? links(req) : links || [];                                       // 21
            linksArr.unshift(relSelf(req));                                                                            // 22
            apiRes.links = linksArr;                                                                                   // 23
            res.json(apiRes);                                                                                          // 24
        } catch (err) {                                                                                                // 25
            res.json(err);                                                                                             // 26
        }                                                                                                              // 27
    };                                                                                                                 // 28
}                                                                                                                      // 29
                                                                                                                       //
function absPath(req) {                                                                                                // 31
    var path = req.baseUrl + req.path;                                                                                 // 32
    if (path[0] === '/') {                                                                                             // 33
        path = path.substring(1);                                                                                      // 34
    }                                                                                                                  // 35
    return Meteor.absoluteUrl(path);                                                                                   // 36
}                                                                                                                      // 37
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"routes.js":["express","../gateway/oidc","./middlewares/utils","./middlewares/metadata","./middlewares/content",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/resource_server/routes.js                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express;module.import('express',{"default":function(v){express=v}});var oidc;module.import('../gateway/oidc',{"default":function(v){oidc=v}});var RESTCompose;module.import('./middlewares/utils',{"RESTCompose":function(v){RESTCompose=v}});var getEntryLst,getEntry;module.import('./middlewares/metadata',{"getEntryLst":function(v){getEntryLst=v},"getEntry":function(v){getEntry=v}});var accessData;module.import('./middlewares/content',{"default":function(v){accessData=v}});/**
 * Created by xgfd on 04/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       //
var router = express.Router();                                                                                         // 12
                                                                                                                       //
/**                                                                                                                    // 14
 * General API information                                                                                             //
 */                                                                                                                    //
router.get('/', RESTCompose({ version: '0.1', auth: 'OAuth2.0' }));                                                    // 17
                                                                                                                       //
/**                                                                                                                    // 19
 * Datasets routes                                                                                                     //
 */                                                                                                                    //
router.get('/datasets', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryLst));                    // 22
                                                                                                                       //
router.get('/datasets/:id', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntry));                   // 24
                                                                                                                       //
router.get('/datasets/:_/:id', oidc.checkAndSetUser('content'), Meteor.bindEnvironment(accessData));                   // 26
                                                                                                                       //
/**                                                                                                                    // 28
 * Apps routes                                                                                                         //
 */                                                                                                                    //
router.get('/apps', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntryLst));                        // 31
                                                                                                                       //
router.get('/apps/:id', oidc.checkAndSetUser(/meta|content/), Meteor.bindEnvironment(getEntry));                       // 33
                                                                                                                       //
/**                                                                                                                    // 35
 * User profile for OIDC                                                                                               //
 */                                                                                                                    //
router.get('/userInfo', oidc.userInfo());                                                                              // 38
                                                                                                                       //
/**                                                                                                                    // 40
 * Testing routes                                                                                                      //
 */                                                                                                                    //
router.get('/test/meta', oidc.checkAndSetUser(/meta|content/), function (req, res) {                                   // 43
  res.send('ok. ' + req.user);                                                                                         // 44
});                                                                                                                    // 45
                                                                                                                       //
router.get('/test/content', oidc.check('content'), function (req, res) {                                               // 47
  res.send('ok. ' + req.user);                                                                                         // 48
});                                                                                                                    // 49
                                                                                                                       //
module.export("default",exports.default=(router));                                                                     // 51
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"gateway":{"client_routes.js":["express","./oidc","crypto",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/client_routes.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express;module.import('express',{"default":function(v){express=v}});var oidc;module.import('./oidc',{"default":function(v){oidc=v}});var crypto;module.import('crypto',{"default":function(v){crypto=v}});/**
 * Created by xgfd on 03/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       //
var router = express.Router();                                                                                         // 9
                                                                                                                       //
//Routes for testing only                                                                                              // 11
//Client register form                                                                                                 // 12
router.get('/register', oidc.use('client'), function (req, res, next) {                                                // 13
                                                                                                                       //
    var mkId = function mkId() {                                                                                       // 15
        var key = crypto.createHash('md5').update(req.session.user + '-' + Math.random()).digest('hex');               // 16
        req.model.client.findOne({ key: key }, function (err, client) {                                                // 17
            if (!err && !client) {                                                                                     // 18
                var secret = crypto.createHash('md5').update(key + req.session.user + Math.random()).digest('hex');    // 19
                req.session.register_client = {};                                                                      // 20
                req.session.register_client.key = key;                                                                 // 21
                req.session.register_client.secret = secret;                                                           // 22
                var head = '<head><title>Register Client</title></head>';                                              // 23
                var inputs = '';                                                                                       // 24
                var fields = {                                                                                         // 25
                    name: {                                                                                            // 26
                        label: 'Client Name',                                                                          // 27
                        html: '<input type="text" id="name" name="name" placeholder="Client Name"/>'                   // 28
                    },                                                                                                 // 26
                    redirect_uris: {                                                                                   // 30
                        label: 'Redirect Uri',                                                                         // 31
                        html: '<input type="text" id="redirect_uris" name="redirect_uris" placeholder="Redirect Uri"/>'
                    },                                                                                                 // 30
                    key: {                                                                                             // 34
                        label: 'Client Key',                                                                           // 35
                        html: '<span>' + key + '</span>'                                                               // 36
                    },                                                                                                 // 34
                    secret: {                                                                                          // 38
                        label: 'Client Secret',                                                                        // 39
                        html: '<span>' + secret + '</span>'                                                            // 40
                    }                                                                                                  // 38
                };                                                                                                     // 25
                for (var i in meteorBabelHelpers.sanitizeForInObject(fields)) {                                        // 43
                    inputs += '<div><label for="' + i + '">' + fields[i].label + '</label> ' + fields[i].html + '</div>';
                }                                                                                                      // 45
                var error = req.session.error ? '<div>' + req.session.error + '</div>' : '';                           // 46
                var body = '<body><h1>Register Client</h1><form method="POST">' + inputs + '<input type="submit"/></form>' + error;
                res.send('<html>' + head + body + '</html>');                                                          // 48
            } else if (!err) {                                                                                         // 49
                mkId();                                                                                                // 50
            } else {                                                                                                   // 51
                next(err);                                                                                             // 52
            }                                                                                                          // 53
        });                                                                                                            // 54
    };                                                                                                                 // 55
    mkId();                                                                                                            // 56
});                                                                                                                    // 57
                                                                                                                       //
//process client register                                                                                              // 59
router.post('/register', oidc.use('client'), function (req, res, next) {                                               // 60
    delete req.session.error;                                                                                          // 61
    req.body.key = req.session.register_client.key;                                                                    // 62
    req.body.secret = req.session.register_client.secret;                                                              // 63
    req.body.user = req.session.user;                                                                                  // 64
    req.body.redirect_uris = req.body.redirect_uris.split(/[, ]+/);                                                    // 65
    req.model.client.create(req.body, function (err, client) {                                                         // 66
        if (!err && client) {                                                                                          // 67
            res.redirect('/client/' + client.id);                                                                      // 68
        } else {                                                                                                       // 69
            next(err);                                                                                                 // 70
        }                                                                                                              // 71
    });                                                                                                                // 72
});                                                                                                                    // 73
                                                                                                                       //
router.get('/', oidc.use('client'), function (req, res, next) {                                                        // 75
    var head = '<h1>Clients Page</h1><div><a href="/client/register"/>Register new client</a></div>';                  // 76
    req.model.client.find({ user: req.session.user }, function (err, clients) {                                        // 77
        var body = ["<ul>"];                                                                                           // 78
        clients.forEach(function (client) {                                                                            // 79
            body.push('<li><a href="/client/' + client.id + '">' + client.name + '</li>');                             // 80
        });                                                                                                            // 81
        body.push('</ul>');                                                                                            // 82
        res.send(head + body.join(''));                                                                                // 83
    });                                                                                                                // 84
});                                                                                                                    // 85
                                                                                                                       //
router.get('/:id', oidc.use('client'), function (req, res, next) {                                                     // 87
    req.model.client.findOne({ user: req.session.user, id: req.params.id }, function (err, client) {                   // 88
        if (err) {                                                                                                     // 89
            next(err);                                                                                                 // 90
        } else if (client) {                                                                                           // 91
            var html = '<h1>Client ' + client.name + ' Page</h1><div><a href="/client">Go back</a></div><ul><li>Key: ' + client.key + '</li><li>Secret: ' + client.secret + '</li><li>Redirect Uris: <ul>';
            client.redirect_uris.forEach(function (uri) {                                                              // 93
                html += '<li>' + uri + '</li>';                                                                        // 94
            });                                                                                                        // 95
            html += '</ul></li></ul>';                                                                                 // 96
            res.send(html);                                                                                            // 97
        } else {                                                                                                       // 98
            res.send('<h1>No Client Found!</h1><div><a href="/client">Go back</a></div>');                             // 99
        }                                                                                                              // 100
    });                                                                                                                // 101
});                                                                                                                    // 102
                                                                                                                       //
module.export("default",exports.default=(router));                                                                     // 104
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"models.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/models.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 *                                                                                                                     //
 * Created by xgfd on 02/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var models = {                                                                                                         // 6
    user: {                                                                                                            // 7
        identity: 'user',                                                                                              // 8
        tableName: 'users',                                                                                            // 9
        connection: 'def',                                                                                             // 10
        schema: true,                                                                                                  // 11
        policies: 'loggedIn',                                                                                          // 12
        attributes: {                                                                                                  // 13
            username: {                                                                                                // 14
                type: 'string',                                                                                        // 15
                required: true                                                                                         // 16
            },                                                                                                         // 14
            emails: {                                                                                                  // 18
                type: 'array'                                                                                          // 19
            }                                                                                                          // 18
        }                                                                                                              // 13
    }                                                                                                                  // 7
};                                                                                                                     // 6
                                                                                                                       //
module.export("default",exports.default=(models));                                                                     // 25
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"oidc.js":["babel-runtime/helpers/toConsumableArray","sails-mongo","openid-connect-wo","./models",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/oidc.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _toConsumableArray;module.import('babel-runtime/helpers/toConsumableArray',{"default":function(v){_toConsumableArray=v}});var mongo;module.import('sails-mongo',{"default":function(v){mongo=v}});var OpenIDConnect;module.import('openid-connect-wo',{"default":function(v){OpenIDConnect=v}});var models;module.import('./models',{"default":function(v){models=v}});
/**                                                                                                                    // 1
 * Created by xgfd on 03/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       //
var oidcOpts = {                                                                                                       // 10
    login_url: '/sign-in',                                                                                             // 11
    consent_url: '/oauth/decision',                                                                                    // 12
    iss: Meteor.absoluteUrl(),                                                                                         // 13
    scopes: {                                                                                                          // 14
        meta: 'Access to the metadata of your apps and datasets',                                                      // 15
        content: 'Access to  your apps and datasets'                                                                   // 16
    },                                                                                                                 // 14
    adapters: {                                                                                                        // 18
        mongo: mongo                                                                                                   // 19
    },                                                                                                                 // 18
    connections: {                                                                                                     // 21
        def: {                                                                                                         // 22
            adapter: 'mongo',                                                                                          // 23
            url: process.env.MONGO_URL || 'mongodb://127.0.0.1:3001/meteor'                                            // 24
        }                                                                                                              // 22
    },                                                                                                                 // 21
    defaults: {                                                                                                        // 27
        migrate: 'safe'                                                                                                // 28
    },                                                                                                                 // 27
    models: models                                                                                                     // 30
};                                                                                                                     // 10
                                                                                                                       //
var oidc = OpenIDConnect.oidc(oidcOpts);                                                                               // 33
                                                                                                                       //
oidc.userInfo = function () {                                                                                          // 35
    var self = this;                                                                                                   // 36
    return [self.check('openid', /profile|email/), self.use({ policies: { loggedIn: false }, models: ['access', 'user'] }), function (req, res) {
        req.model.access.findOne({ token: req.parsedParams.access_token }).exec(function (err, access) {               // 41
            if (!err && access) {                                                                                      // 43
                req.model.user.findOne({ id: access.user }, function (err, user) {                                     // 44
                    if (req.check.scopes.indexOf('profile') != -1) {                                                   // 45
                        user.sub = req.session.sub || req.session.user;                                                // 46
                        // delete user.id;                                                                             // 47
                        delete user.services;                                                                          // 48
                        res.json(user);                                                                                // 49
                    } else {                                                                                           // 50
                        //console.log(user);                                                                           // 51
                        res.json({ email: user.emails && user.emails[0].address, id: user.id });                       // 52
                    }                                                                                                  // 53
                });                                                                                                    // 54
            } else {                                                                                                   // 55
                self.errorHandle(res, null, 'unauthorized_client', 'Access token is not valid.');                      // 56
            }                                                                                                          // 57
        });                                                                                                            // 58
    }];                                                                                                                // 59
};                                                                                                                     // 60
                                                                                                                       //
function hasATK(req) {                                                                                                 // 62
    var atk = req.query.access_token || req.body.access_token;                                                         // 63
    return !!atk;                                                                                                      // 64
}                                                                                                                      // 65
/**                                                                                                                    // 66
 * Return a middleware that acts differently depending on the value of a predicate                                     //
 * @param {function(req, res, next)} left - Called when the predicate evaluates to false.                              //
 * @param {function(req, res, next)} right - Called when the predicate                                                 //
 * @param {function(req)} pred - A predicate function                                                                  //
 * @returns {function()} - A middleware that acts as left if pred is false, or as right if pred is true;               //
 */                                                                                                                    //
function either(left, right) {                                                                                         // 73
    var pred = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : hasATK;                             // 73
                                                                                                                       //
    return function (req, res, next) {                                                                                 // 74
        if (pred(req)) {                                                                                               // 75
            right(req, res, next);                                                                                     // 76
        } else {                                                                                                       // 77
            left(req, res, next);                                                                                      // 78
        }                                                                                                              // 79
    };                                                                                                                 // 80
};                                                                                                                     // 81
                                                                                                                       //
function doNothing(_, __, next) {                                                                                      // 83
    next();                                                                                                            // 84
}                                                                                                                      // 85
                                                                                                                       //
function setUser(req, res, next) {                                                                                     // 87
    var token = req.query.access_token || req.body.access_token;                                                       // 88
                                                                                                                       //
    if (token) {                                                                                                       // 90
        req.model.access.findOne({ token: token }).exec(function (err, access) {                                       // 91
            if (!err && access) {                                                                                      // 93
                req.user = access.user;                                                                                // 94
                next();                                                                                                // 95
            } else {                                                                                                   // 96
                self.errorHandle(res, null, 'unauthorized_client', 'Invalid access token.');                           // 97
            }                                                                                                          // 98
        });                                                                                                            // 99
    } else {                                                                                                           // 100
        req.user = null;                                                                                               // 101
        next();                                                                                                        // 102
    }                                                                                                                  // 103
}                                                                                                                      // 104
                                                                                                                       //
oidc.checkAndSetUser = function () {                                                                                   // 106
    var self = this;                                                                                                   // 107
    var scopes = arguments;                                                                                            // 108
    return [either(doNothing, self.check.apply(self, _toConsumableArray(scopes))), either(doNothing, self.use({ policies: { loggedIn: false }, models: ['access'] })), setUser];
};                                                                                                                     // 114
                                                                                                                       //
module.export("default",exports.default=(Object.create(oidc)));                                                        // 116
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"routes.js":["express","./oidc",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/gateway/routes.js                                                                                        //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express;module.import('express',{"default":function(v){express=v}});var oidc;module.import('./oidc',{"default":function(v){oidc=v}});/**
 * Created by xgfd on 03/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       //
var router = express.Router();                                                                                         // 8
                                                                                                                       //
router.get('/oauth/authorise', oidc.auth());                                                                           // 10
router.post('/oauth/token', oidc.token());                                                                             // 11
router.post('/oauth/decision', oidc.consent());                                                                        // 12
                                                                                                                       //
//user consent form                                                                                                    // 14
router.get('/oauth/decision', function (req, res, next) {                                                              // 15
    var head = '<head><title>Consent</title></head>';                                                                  // 16
    var lis = [];                                                                                                      // 17
    for (var i in meteorBabelHelpers.sanitizeForInObject(req.session.scopes)) {                                        // 18
        lis.push('<li><b>' + i + '</b>: ' + req.session.scopes[i].explain + '</li>');                                  // 19
    }                                                                                                                  // 20
    var ul = '<ul>' + lis.join('') + '</ul>';                                                                          // 21
    var error = req.session.error ? '<div>' + req.session.error + '</div>' : '';                                       // 22
    var body = '<body><h1>Consent</h1><form method="POST">' + ul + '<input type="submit" name="accept" value="Accept"/><input type="submit" name="cancel" value="Cancel"/></form>' + error;
    res.send('<html>' + head + body + '</html>');                                                                      // 24
});                                                                                                                    // 25
                                                                                                                       //
module.export("default",exports.default=(router));                                                                     // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"app.js":["express","body-parser","express-session","./gateway/routes","./resource_server/routes","./gateway/client_routes","cookies",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/api/app.js                                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var express;module.import('express',{"default":function(v){express=v}});var bodyParser;module.import('body-parser',{"default":function(v){bodyParser=v}});var session;module.import('express-session',{"default":function(v){session=v}});var oauth_routes;module.import('./gateway/routes',{"default":function(v){oauth_routes=v}});var api_routes;module.import('./resource_server/routes',{"default":function(v){api_routes=v}});var client_routes;module.import('./gateway/client_routes',{"default":function(v){client_routes=v}});var Cookies;module.import('cookies',{"default":function(v){Cookies=v}});/**
 * Created by xgfd on 02/06/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       // 11
                                                                                                                       //
var app = express();                                                                                                   // 13
WebApp.connectHandlers.use(Meteor.bindEnvironment(app));                                                               // 14
                                                                                                                       //
app.use(session({ secret: 'webobservatory', resave: false, saveUninitialized: false }));                               // 16
app.use(Meteor.bindEnvironment(function (req, res, next) {                                                             // 17
    //Check the values in the cookies                                                                                  // 18
    var cookies = new Cookies(req),                                                                                    // 19
        userId = cookies.get("meteor_user_id") || "",                                                                  // 19
        token = cookies.get("meteor_token") || "";                                                                     // 19
                                                                                                                       //
    //Check a valid user with this token exists                                                                        // 23
    var user = Meteor.users.findOne({                                                                                  // 24
        _id: userId,                                                                                                   // 25
        'services.resume.loginTokens.hashedToken': Accounts._hashLoginToken(token)                                     // 26
    });                                                                                                                // 24
    req.session.user = user && user._id;                                                                               // 28
    next();                                                                                                            // 29
}));                                                                                                                   // 30
app.use(bodyParser.json());                                                                                            // 31
app.use(bodyParser.urlencoded({ extended: true }));                                                                    // 32
                                                                                                                       //
//setting up routes                                                                                                    // 34
app.use('/', oauth_routes);                                                                                            // 35
app.use('/api', api_routes);                                                                                           // 36
// client routes are for testing only                                                                                  // 37
// app.use('/client', client_routes);                                                                                  // 38
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"cronjobs":{"connectionTest.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/cronjobs/connectionTest.js                                                                                   //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 21/10/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
checkCon = function checkCon() {                                                                                       // 5
    var apps = Apps.find().fetch(),                                                                                    // 6
        datasets = Datasets.find().fetch();                                                                            // 6
                                                                                                                       //
    var dists = datasets.map(function (ds) {                                                                           // 9
        return ds.distribution;                                                                                        // 9
    });                                                                                                                // 9
    dists = _.flatten(dists);                                                                                          // 10
                                                                                                                       //
    apps.forEach(function (app) {                                                                                      // 12
        return appConnTest(app._id);                                                                                   // 12
    });                                                                                                                // 12
    dists.forEach(function (dist) {                                                                                    // 13
        return dbConnTest(dist._id, dist.fileFormat);                                                                  // 13
    });                                                                                                                // 13
};                                                                                                                     // 14
                                                                                                                       //
function dbConnTest(id, format) {                                                                                      // 16
    var supported = ['MongoDB', 'MySQL', 'AMQP', 'SPARQL', 'HTML'];                                                    // 17
    if (_.contains(supported, format)) {                                                                               // 18
        var method = format.toLowerCase() + 'Connect';                                                                 // 19
        Meteor.call(method, id);                                                                                       // 20
    }                                                                                                                  // 21
}                                                                                                                      // 22
                                                                                                                       //
function appConnTest(id) {                                                                                             // 24
    Meteor.call('appConnect', id);                                                                                     // 25
}                                                                                                                      // 26
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"get_remote_colls.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/cronjobs/get_remote_colls.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 10/05/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
function normaliseUrl(url) {                                                                                           // 5
    //prepend http:// if abscent                                                                                       // 6
    if (url.indexOf('http') !== 0) {                                                                                   // 7
        url = 'http://' + url;                                                                                         // 8
    }                                                                                                                  // 9
                                                                                                                       //
    //append / if abscent                                                                                              // 11
    if (url[url.length - 1] !== '/') {                                                                                 // 12
        url += '/';                                                                                                    // 13
    }                                                                                                                  // 14
    return url;                                                                                                        // 15
}                                                                                                                      // 16
                                                                                                                       //
function origin(url, name, doc) {                                                                                      // 18
    return '' + url + name + '/' + doc._id;                                                                            // 19
}                                                                                                                      // 20
                                                                                                                       //
function linkToRemote(url, name, local) {                                                                              // 22
    var remote = DDP.connect(url),                                                                                     // 23
        col = new Mongo.Collection(name, { connection: remote });                                                      // 23
                                                                                                                       //
    col.find().observe({                                                                                               // 26
        added: function () {                                                                                           // 27
            function added(doc) {                                                                                      // 26
                doc.origin = origin(url, name, doc);                                                                   // 28
                //TODO rewrite id refs using url as prefix                                                             // 29
                delete doc._id;                                                                                        // 30
                delete doc.isBasedOnUrl;                                                                               // 31
                delete doc.comments;                                                                                   // 32
                local.insert(doc);                                                                                     // 33
            }                                                                                                          // 34
                                                                                                                       //
            return added;                                                                                              // 26
        }(),                                                                                                           // 26
        removed: function () {                                                                                         // 35
            function removed(doc) {                                                                                    // 26
                var origin = origin(url, name, doc);                                                                   // 36
                local.remove({ origin: origin });                                                                      // 37
            }                                                                                                          // 38
                                                                                                                       //
            return removed;                                                                                            // 26
        }(),                                                                                                           // 26
        changed: function () {                                                                                         // 39
            function changed(doc, oldDoc) {                                                                            // 26
                var origin = origin(url, name, oldDoc);                                                                // 40
                local.remove({ origin: origin });                                                                      // 41
                                                                                                                       //
                doc.origin = origin(url, name, doc);                                                                   // 43
                delete doc._id;                                                                                        // 44
                delete doc.isBasedOnUrl;                                                                               // 45
                local.insert(doc);                                                                                     // 46
            }                                                                                                          // 47
                                                                                                                       //
            return changed;                                                                                            // 26
        }()                                                                                                            // 26
    });                                                                                                                // 26
    return col;                                                                                                        // 49
}                                                                                                                      // 50
                                                                                                                       //
function regRemoteColls(remote_name, urls, local) {                                                                    // 52
    return urls.reduce(function (map, url) {                                                                           // 53
        url = normaliseUrl(url);                                                                                       // 54
        if (!map[url]) {                                                                                               // 55
            map[url] = linkToRemote(url, remote_name, local);                                                          // 56
        }                                                                                                              // 57
        return map;                                                                                                    // 58
    }, {});                                                                                                            // 59
}                                                                                                                      // 60
                                                                                                                       //
function updateSub(remoteColls) {                                                                                      // 62
    if (remoteColls) {                                                                                                 // 63
        Object.keys(remoteColls).map(function (url) {                                                                  // 64
            return remoteColls[normaliseUrl(url)];                                                                     // 65
        }).forEach(function (col) {                                                                                    // 65
            if (col) {                                                                                                 // 67
                var name = col._name,                                                                                  // 68
                    remote = col._connection;                                                                          // 68
                remote.subscribe(name);                                                                                // 70
            }                                                                                                          // 71
        });                                                                                                            // 72
    }                                                                                                                  // 73
}                                                                                                                      // 74
                                                                                                                       //
var woUrls = orion.config.get('wo_urls');                                                                              // 76
var remoteColls = {};                                                                                                  // 77
                                                                                                                       //
if (woUrls) {                                                                                                          // 79
    RemoteApps.remove({});                                                                                             // 80
    RemoteDatasets.remove({});                                                                                         // 81
                                                                                                                       //
    remoteColls[RemoteDatasets.pluralName] = regRemoteColls('datasets', woUrls, RemoteDatasets);                       // 83
    remoteColls[RemoteApps.pluralName] = regRemoteColls('apps', woUrls, RemoteApps);                                   // 84
}                                                                                                                      // 85
                                                                                                                       //
pullRemoteColls = function pullRemoteColls() {                                                                         // 87
    [RemoteApps, RemoteDatasets].map(function (coll) {                                                                 // 88
        return remoteColls[coll.pluralName];                                                                           // 89
    }).forEach(updateSub);                                                                                             // 89
};                                                                                                                     // 91
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"methods":{"accounts.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/accounts.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
//Accounts.onCreateUser(function (options, user) {                                                                     // 4
//    let profile = options.profile;                                                                                   // 5
//    if (profile) {                                                                                                   // 6
//        if (profile.isgroup) {                                                                                       // 7
//            delete profile.isgroup;                                                                                  // 8
//            user.isGroup = Groups.insert({publisher: user._id, name: profile.name});                                 // 9
//            Roles.removeUserFromRoles( user._id, ["individual"] );                                                   // 10
//            Roles.addUserToRoles( user._id ,  ["group"] );                                                           // 11
//        }                                                                                                            // 12
//        user.profile = options.profile;                                                                              // 13
//    }                                                                                                                // 14
//    return user;                                                                                                     // 15
//});                                                                                                                  // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"comments.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/comments.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 13/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    commentInsert: function () {                                                                                       // 6
        function commentInsert(commentAttributes, category) {                                                          // 6
            check(this.userId, String);                                                                                // 7
            check(category, Mongo.Collection);                                                                         // 8
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 9
            check(commentAttributes, {                                                                                 // 10
                entryId: String,                                                                                       // 11
                body: String                                                                                           // 12
            });                                                                                                        // 10
                                                                                                                       //
            entry = category.findOne(commentAttributes.entryId);                                                       // 15
                                                                                                                       //
            if (!entry) throw new Meteor.Error('invalid-comment', 'You must comment on ' + category);                  // 17
                                                                                                                       //
            comment = _.extend(commentAttributes, {                                                                    // 20
                publisher: this.userId,                                                                                // 21
                category: category.singularName,                                                                       // 22
                //author: user.username,                                                                               // 23
                submitted: new Date()                                                                                  // 24
            });                                                                                                        // 20
                                                                                                                       //
            // update the post with the number of comments                                                             // 27
            category.update(comment.entryId, { $inc: { commentsCount: 1 } });                                          // 28
                                                                                                                       //
            // create the comment, save the id                                                                         // 30
            comment._id = Comments.insert(comment);                                                                    // 31
                                                                                                                       //
            // now create a notification, informing the user that there's been a comment                               // 33
            createCommentNotification(comment, category);                                                              // 34
                                                                                                                       //
            return comment._id;                                                                                        // 36
        }                                                                                                              // 37
                                                                                                                       //
        return commentInsert;                                                                                          // 6
    }()                                                                                                                // 6
});                                                                                                                    // 5
                                                                                                                       //
function createCommentNotification(comment, category) {                                                                // 40
    check(comment, Object);                                                                                            // 41
    check(category, Mongo.Collection);                                                                                 // 42
    check(category.singularName, Match.OneOf('dataset', 'app'));                                                       // 43
                                                                                                                       //
    var entryId = comment.entryId,                                                                                     // 45
        entry = category.findOne(entryId),                                                                             // 45
        initiatorId = comment.publisher;                                                                               // 45
                                                                                                                       //
    var path = Router.routes[category.singularName + '.page'].path({ _id: entryId });                                  // 49
    var message = '<a href="' + path + '"> <strong>' + Meteor.users.findOne(initiatorId).username + '</strong> commented on your post </a>';
                                                                                                                       //
    if (initiatorId !== entry.publisher) {                                                                             // 52
        createNotification(initiatorId, entryId, entry.name, entry.publisher, category.singularName, message);         // 53
    }                                                                                                                  // 54
};                                                                                                                     // 55
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"creative_work.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/creative_work.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 26/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    //datasetInsert: function (datasetAttributes) {                                                                    // 6
    //    check(this.userId, String);                                                                                  // 7
    //    check(datasetAttributes, {                                                                                   // 8
    //        name: String,                                                                                            // 9
    //        //url: String                                                                                            // 10
    //    });                                                                                                          // 11
    //                                                                                                                 // 12
    //    let errors = validateDataset(datasetAttributes);                                                             // 13
    //    if (errors.name || errors.distribution)                                                                      // 14
    //        throw new Meteor.Error('invalid-dataset', "You must set a name and distribution for your dataset");      // 15
    //                                                                                                                 // 16
    //    //let datasetWithSameLink = Datasets.findOne({"distribution.url": datasetAttributes.distribution.url});      // 17
    //    //if (datasetWithSameLink) {                                                                                 // 18
    //    //    return {                                                                                               // 19
    //    //        postExists: true,                                                                                  // 20
    //    //        _id: datasetWithSameLink._id                                                                       // 21
    //    //    }                                                                                                      // 22
    //    //}                                                                                                          // 23
    //                                                                                                                 // 24
    //    let user = Meteor.user();                                                                                    // 25
    //    let dataset = _.extend(datasetAttributes, {                                                                  // 26
    //        publisher: user._id,                                                                                     // 27
    //        commentsCount: 0,                                                                                        // 28
    //        upvoters: [],                                                                                            // 29
    //        votes: 0                                                                                                 // 30
    //    });                                                                                                          // 31
    //                                                                                                                 // 32
    //    let datasetId = Datasets.insert(dataset);                                                                    // 33
    //                                                                                                                 // 34
    //    return {                                                                                                     // 35
    //        _id: datasetId                                                                                           // 36
    //    };                                                                                                           // 37
    //},                                                                                                               // 38
                                                                                                                       //
    upvote: function () {                                                                                              // 40
        function upvote(entryId, category) {                                                                           // 5
            check(this.userId, String);                                                                                // 41
            check(entryId, String);                                                                                    // 42
            check(category, Mongo.Collection);                                                                         // 43
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 44
                                                                                                                       //
            var affected = category.update({                                                                           // 46
                _id: entryId,                                                                                          // 47
                upvoters: { $ne: this.userId }                                                                         // 48
            }, {                                                                                                       // 46
                $addToSet: { upvoters: this.userId },                                                                  // 50
                $inc: { votes: 1 }                                                                                     // 51
            });                                                                                                        // 49
                                                                                                                       //
            if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                 // 54
        }                                                                                                              // 56
                                                                                                                       //
        return upvote;                                                                                                 // 5
    }(),                                                                                                               // 5
    downvote: function () {                                                                                            // 57
        function downvote(entryId, category) {                                                                         // 5
            check(this.userId, String);                                                                                // 58
            check(entryId, String);                                                                                    // 59
            check(category, Mongo.Collection);                                                                         // 60
            check(category.singularName, Match.OneOf('dataset', 'app'));                                               // 61
                                                                                                                       //
            var affected = category.update({                                                                           // 63
                _id: entryId,                                                                                          // 64
                downvoters: { $ne: this.userId }                                                                       // 65
            }, {                                                                                                       // 63
                $addToSet: { downvoters: this.userId },                                                                // 67
                $inc: { downvotes: 1 }                                                                                 // 68
            });                                                                                                        // 66
                                                                                                                       //
            if (!affected) throw new Meteor.Error('invalid', "You weren't able to upvote that entry");                 // 71
        }                                                                                                              // 73
                                                                                                                       //
        return downvote;                                                                                               // 5
    }()                                                                                                                // 5
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"distributions.js":["babel-runtime/helpers/typeof",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/distributions.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});                          //
/**                                                                                                                    // 1
 * Created by xgfd on 02/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
var connPool = {};                                                                                                     // 5
                                                                                                                       //
function idToURL(distId) {                                                                                             // 7
    var url = void 0,                                                                                                  // 8
        username = void 0,                                                                                             // 8
        pass = void 0;                                                                                                 // 8
                                                                                                                       //
    var dist = Datasets.findOne({ 'distribution._id': distId }, { fields: { distribution: { $elemMatch: { _id: distId } } } }).distribution[0];
                                                                                                                       //
    if (dist) {                                                                                                        // 12
        url = dist.url;                                                                                                // 13
        if (dist.profile) {                                                                                            // 14
            var _dist$profile = dist.profile;                                                                          // 14
            username = _dist$profile.username;                                                                         // 15
            pass = _dist$profile.pass;                                                                                 // 15
        }                                                                                                              // 16
    } else {                                                                                                           // 17
        console.log(new Meteor.Error('not-found', 'Distribution ' + distId + ' not found'));                           // 18
    }                                                                                                                  // 19
                                                                                                                       //
    return { url: url, username: username, pass: pass };                                                               // 21
}                                                                                                                      // 22
                                                                                                                       //
function connectorSyncWrap(connect) {                                                                                  // 24
    return function (id) {                                                                                             // 25
        var _idToURL = idToURL(id);                                                                                    // 25
                                                                                                                       //
        url = _idToURL.url;                                                                                            // 27
        username = _idToURL.username;                                                                                  // 27
        pass = _idToURL.pass;                                                                                          // 27
                                                                                                                       //
        var _Async$runSync = Async.runSync(function (done) {                                                           // 25
            connect(url, username, pass, done);                                                                        // 30
        });                                                                                                            // 31
                                                                                                                       //
        var error = _Async$runSync.error;                                                                              // 25
        var result = _Async$runSync.result;                                                                            // 25
                                                                                                                       //
                                                                                                                       //
        if (error) {                                                                                                   // 33
            Datasets.update({ "distribution._id": id }, { $set: { 'distribution.$.online': false } });                 // 34
            console.log(new Meteor.Error('connection-failed', 'Distribution ' + id + ': ' + error.message));           // 35
        } else {                                                                                                       // 36
            Datasets.update({ "distribution._id": id }, { $set: { 'distribution.$.online': true } });                  // 37
            //add connection to pool                                                                                   // 38
            connPool[id] = result;                                                                                     // 39
            //remove connection after a while                                                                          // 40
            Meteor.setTimeout(function () {                                                                            // 41
                // console.log('close', id);                                                                           // 42
                var conn = connPool[id];                                                                               // 43
                                                                                                                       //
                if (conn) {                                                                                            // 45
                    if (conn.close) {                                                                                  // 46
                        conn.close();                                                                                  // 47
                    }                                                                                                  // 48
                                                                                                                       //
                    if (conn.disconnect) {                                                                             // 50
                        conn.disconnect();                                                                             // 51
                    }                                                                                                  // 52
                                                                                                                       //
                    delete connPool[id];                                                                               // 54
                }                                                                                                      // 55
            }, 30000);                                                                                                 // 56
            return true;                                                                                               // 57
        }                                                                                                              // 58
    };                                                                                                                 // 59
}                                                                                                                      // 60
                                                                                                                       //
/*                                                                                                                     // 62
 * @connector(distId) create an db connection and save it to dbPool                                                    //
 * @queryExec(db, done, ...args) query execution function. result is passed to done(error, result)                     //
 * */                                                                                                                  //
function queryExecFactory(connector, queryExec) {                                                                      // 66
    return function (distId) {                                                                                         // 67
        for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {      // 67
            args[_key - 1] = arguments[_key];                                                                          // 67
        }                                                                                                              // 67
                                                                                                                       //
        var conn = connPool[distId];                                                                                   // 68
                                                                                                                       //
        try {                                                                                                          // 70
            connector(distId);                                                                                         // 71
            conn = connPool[distId];                                                                                   // 72
                                                                                                                       //
            var _Async$runSync2 = Async.runSync(function (done) {                                                      // 70
                queryExec.apply(undefined, [conn, done].concat(args));                                                 // 75
            });                                                                                                        // 76
                                                                                                                       //
            var error = _Async$runSync2.error;                                                                         // 70
            var result = _Async$runSync2.result;                                                                       // 70
                                                                                                                       //
                                                                                                                       //
            if (error) {                                                                                               // 78
                throw new Meteor.Error(error.name, error.message);                                                     // 79
            } else {                                                                                                   // 80
                Datasets.update({ "distribution._id": distId }, { $set: { 'distribution.$.online': true } });          // 81
                return result;                                                                                         // 82
            }                                                                                                          // 83
        } catch (e) {                                                                                                  // 84
            Datasets.update({ "distribution._id": distId }, { $set: { 'distribution.$.online': false } });             // 86
            throw e;                                                                                                   // 87
        }                                                                                                              // 88
    };                                                                                                                 // 90
}                                                                                                                      // 91
                                                                                                                       //
/*                                                                                                                     // 93
 * check whether credentials are included in the url                                                                   //
 */                                                                                                                    //
function hasCredential(url) {                                                                                          // 96
    var match = url.match(/(.*?:\/\/)?(.*:.*@).*/);                                                                    // 97
    return match && match[2];                                                                                          // 98
}                                                                                                                      // 99
                                                                                                                       //
/*MongoDB*/                                                                                                            // 101
var mongoclient = Npm.require("mongodb").MongoClient;                                                                  // 102
                                                                                                                       //
/*                                                                                                                     // 104
 call with one parameter @distId or three parameters @url @username @pass                                              //
 */                                                                                                                    //
var mongodbConnect = connectorSyncWrap(function (url, username, pass, done) {                                          // 107
    if (!hasCredential(url) && username) {                                                                             // 108
        url = 'mongodb://' + username + ':' + pass + '@' + url.slice('mongodb://'.length);                             // 109
    }                                                                                                                  // 110
    mongoclient.connect(url, done);                                                                                    // 111
});                                                                                                                    // 112
                                                                                                                       //
var mongodbQuery = queryExecFactory(mongodbConnect, function (conn, done, collection) {                                // 114
    var selector = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};                             // 114
    var options = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : { limit: 1000 };                 // 114
                                                                                                                       //
    conn.collection(collection, function (error, col) {                                                                // 115
        if (error) {                                                                                                   // 116
            throw new Meteor.Error(error.name, error.message);                                                         // 117
        }                                                                                                              // 118
        var query = col.find(selector);                                                                                // 119
                                                                                                                       //
        for (var key in meteorBabelHelpers.sanitizeForInObject(options)) {                                             // 121
            if (options.hasOwnProperty(key)) {                                                                         // 122
                query = query[key](options[key]);                                                                      // 123
            }                                                                                                          // 124
        }                                                                                                              // 125
        query.toArray(done);                                                                                           // 126
    });                                                                                                                // 127
});                                                                                                                    // 128
                                                                                                                       //
/* MySQL */                                                                                                            // 130
var mysql = Npm.require('mysql');                                                                                      // 131
                                                                                                                       //
function parseMySQL(url) {                                                                                             // 133
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://                                                      // 134
    var pathSepIndx = url.indexOf('/');                                                                                // 135
    var host = void 0,                                                                                                 // 136
        database = void 0;                                                                                             // 136
    if (pathSepIndx !== -1) {                                                                                          // 137
        host = url.substring(0, pathSepIndx), database = url.substring(pathSepIndx + 1);                               // 138
    } else {                                                                                                           // 140
        host = url;                                                                                                    // 141
    }                                                                                                                  // 142
                                                                                                                       //
    return { host: host, database: database };                                                                         // 144
}                                                                                                                      // 145
                                                                                                                       //
var mysqlConnect = connectorSyncWrap(function (url, username, pass, done) {                                            // 147
    url = url.match(/(mysql:\/\/)?(.*)/)[2]; //strip off mysql://                                                      // 148
                                                                                                                       //
    var _parseMySQL = parseMySQL(url);                                                                                 // 147
                                                                                                                       //
    var host = _parseMySQL.host;                                                                                       // 147
    var database = _parseMySQL.database;                                                                               // 147
                                                                                                                       //
                                                                                                                       //
    var options = {                                                                                                    // 151
        connectionLimit: 20,                                                                                           // 152
        host: host,                                                                                                    // 153
        database: database                                                                                             // 154
    };                                                                                                                 // 151
                                                                                                                       //
    if (username) {                                                                                                    // 157
        options.user = username;                                                                                       // 158
    }                                                                                                                  // 159
                                                                                                                       //
    if (pass) {                                                                                                        // 161
        options.password = pass;                                                                                       // 162
    }                                                                                                                  // 163
                                                                                                                       //
    var pool = mysql.createPool(options);                                                                              // 165
                                                                                                                       //
    done(null, pool);                                                                                                  // 167
});                                                                                                                    // 168
                                                                                                                       //
var mysqlQuery = queryExecFactory(mysqlConnect, function (conn, done, query) {                                         // 170
    conn.query(query, done); // db.query returns a third argument @fields which is discarded                           // 171
});                                                                                                                    // 172
                                                                                                                       //
// SPARQL                                                                                                              // 174
                                                                                                                       //
var sparqlConnect = connectorSyncWrap(function (url, _, __, done) {                                                    // 176
    HTTP.get(url, {}, function (error, _) {                                                                            // 177
        done(error, url);                                                                                              // 178
    });                                                                                                                // 179
});                                                                                                                    // 180
                                                                                                                       //
var sparqlQuery = queryExecFactory(sparqlConnect, function (url, done, query) {                                        // 182
    HTTP.get(url, {                                                                                                    // 183
        params: { query: query },                                                                                      // 184
        timeout: 30000,                                                                                                // 185
        headers: {                                                                                                     // 186
            'Content-Type': 'application/x-www-form-urlencoded',                                                       // 187
            'Accept': 'application/sparql-results+json'                                                                // 188
        }                                                                                                              // 186
    }, function (error, result) {                                                                                      // 183
        if ((typeof result === 'undefined' ? 'undefined' : _typeof(result)) === 'object' && result.content) {          // 192
            result = result.content;                                                                                   // 193
        }                                                                                                              // 194
        done(error, result);                                                                                           // 195
    });                                                                                                                // 196
});                                                                                                                    // 197
                                                                                                                       //
/*RabbitMQ*/                                                                                                           // 199
var amqp = Npm.require('amqplib/callback_api');                                                                        // 200
var amqpConnect = connectorSyncWrap(function (url, username, pass, done) {                                             // 201
    var parts = url.match(/(amqps?:\/\/)?([^\?]*)\??(\S*)/),                                                           // 202
        query = parts[3],                                                                                              // 202
        params = query.split(/[=,&]/),                                                                                 // 202
        exchanges = params[params.indexOf('exchange') + 1].split(','); //value of query exchange can be a comma separate list
                                                                                                                       //
    if (username) {                                                                                                    // 207
        url = parts[1] + (username + ':' + pass + '@') + parts[2] + (query ? '?' + query : '');                        // 208
    }                                                                                                                  // 209
                                                                                                                       //
    amqp.connect(url, function (error, conn) {                                                                         // 211
        if (conn) {                                                                                                    // 212
            conn.exchanges = exchanges;                                                                                // 213
        }                                                                                                              // 214
        done(error, conn);                                                                                             // 215
    });                                                                                                                // 216
});                                                                                                                    // 217
                                                                                                                       //
var amqpQuery = queryExecFactory(amqpConnect, function (conn, done, ex, sId) {                                         // 219
    var exchanges = conn.exchanges;                                                                                    // 220
    if (_.contains(exchanges, ex)) {                                                                                   // 221
        conn.createChannel(function (err, ch) {                                                                        // 222
            var socket = Streamy.sockets(sId);                                                                         // 223
            if (channels[sId]) {                                                                                       // 224
                closeCh(channels[sId], sId);                                                                           // 225
            }                                                                                                          // 226
            //keep the channel associate with a client (socket) to close it later                                      // 227
            channels[sId] = ch;                                                                                        // 228
            ch.assertExchange(ex, 'fanout', { durable: false });                                                       // 229
            ch.assertQueue('', { exclusive: true }, function (err, q) {                                                // 230
                ch.on('close', function () {                                                                           // 231
                    console.log(sId + ' channel closed');                                                              // 232
                    Streamy.emit('msg', { content: sId + ' channel closed' }, socket);                                 // 233
                });                                                                                                    // 234
                done(err, q.queue);                                                                                    // 235
                Streamy.emit('msg', { content: " [*] Waiting for messages" }, socket);                                 // 236
                ch.bindQueue(q.queue, ex, '');                                                                         // 237
                ch.consume(q.queue, function (msg) {                                                                   // 238
                    console.log(" [x] %s", msg.content.toString());                                                    // 239
                    var content = msg.content.toString();                                                              // 240
                    Streamy.emit('msg', { content: content }, socket);                                                 // 241
                }, { noAck: true });                                                                                   // 242
            });                                                                                                        // 243
        });                                                                                                            // 244
    } else {                                                                                                           // 245
        return done(new Error('Unrecognised exchange'));                                                               // 246
    }                                                                                                                  // 247
});                                                                                                                    // 248
                                                                                                                       //
Meteor.methods({                                                                                                       // 250
    //db connectors                                                                                                    // 251
    mongodbConnect: mongodbConnect,                                                                                    // 252
    mysqlConnect: mysqlConnect,                                                                                        // 253
    amqpConnect: amqpConnect,                                                                                          // 254
    sparqlConnect: sparqlConnect,                                                                                      // 255
    htmlConnect: sparqlConnect,                                                                                        // 256
    appConnect: function () {                                                                                          // 257
        function appConnect(id) {                                                                                      // 250
            var url = Apps.findOne(id).url;                                                                            // 258
            if (url) {                                                                                                 // 259
                HTTP.get(url, {                                                                                        // 260
                    timeout: 30000                                                                                     // 261
                }, function (error) {                                                                                  // 260
                    if (error) {                                                                                       // 264
                        Apps.update({ _id: id }, { $set: { 'online': false } });                                       // 265
                    } else {                                                                                           // 266
                        Apps.update({ _id: id }, { $set: { 'online': true } });                                        // 267
                    }                                                                                                  // 268
                });                                                                                                    // 269
            } else {                                                                                                   // 270
                Apps.update({ _id: id }, { $set: { 'online': false } });                                               // 271
            }                                                                                                          // 272
        }                                                                                                              // 273
                                                                                                                       //
        return appConnect;                                                                                             // 250
    }(),                                                                                                               // 250
                                                                                                                       //
                                                                                                                       //
    //query executors                                                                                                  // 275
    mongodbQuery: mongodbQuery,                                                                                        // 276
    mysqlQuery: mysqlQuery,                                                                                            // 277
    sparqlQuery: sparqlQuery,                                                                                          // 278
    amqpQuery: amqpQuery,                                                                                              // 279
                                                                                                                       //
    //utils                                                                                                            // 281
    mongodbCollectionNames: function () {                                                                              // 282
        function mongodbCollectionNames(distId) {                                                                      // 250
            var db = connPool[distId];                                                                                 // 283
                                                                                                                       //
            if (!db) {                                                                                                 // 285
                mongodbConnect(distId);                                                                                // 286
            }                                                                                                          // 287
                                                                                                                       //
            db = connPool[distId];                                                                                     // 289
                                                                                                                       //
            if (!db) {                                                                                                 // 291
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');                    // 292
            }                                                                                                          // 293
                                                                                                                       //
            var _Async$runSync3 = Async.runSync(function (done) {                                                      // 282
                db.listCollections().toArray(done);                                                                    // 296
            });                                                                                                        // 297
                                                                                                                       //
            var error = _Async$runSync3.error;                                                                         // 282
            var result = _Async$runSync3.result;                                                                       // 282
                                                                                                                       //
                                                                                                                       //
            if (error) {                                                                                               // 299
                throw new Meteor.Error(error.name, error.message);                                                     // 300
            } else {                                                                                                   // 301
                result = result.filter(function (x) {                                                                  // 302
                    return x.name !== 'system.indexes';                                                                // 303
                });                                                                                                    // 304
                //console.log(result);                                                                                 // 305
                return result;                                                                                         // 306
            }                                                                                                          // 307
        }                                                                                                              // 308
                                                                                                                       //
        return mongodbCollectionNames;                                                                                 // 250
    }(),                                                                                                               // 250
    amqpCollectionNames: function () {                                                                                 // 310
        function amqpCollectionNames(distId) {                                                                         // 250
            var conn = connPool[distId];                                                                               // 311
                                                                                                                       //
            if (!conn) {                                                                                               // 313
                amqpConnect(distId);                                                                                   // 314
            }                                                                                                          // 315
                                                                                                                       //
            conn = connPool[distId];                                                                                   // 317
                                                                                                                       //
            if (!conn) {                                                                                               // 319
                throw new Meteor.Error('not-found', 'Distribution ' + distId + ' not initialised');                    // 320
            }                                                                                                          // 321
                                                                                                                       //
            return conn.exchanges;                                                                                     // 323
        }                                                                                                              // 324
                                                                                                                       //
        return amqpCollectionNames;                                                                                    // 250
    }()                                                                                                                // 250
});                                                                                                                    // 250
                                                                                                                       //
var channels = {}; //socketId:channel, each socket only grants for one channels                                        // 327
function closeCh(ch, sId) {                                                                                            // 328
    if (ch) {                                                                                                          // 329
        try {                                                                                                          // 330
            ch.close();                                                                                                // 331
        } catch (e) {                                                                                                  // 332
            console.log(e.stackAtStateChange);                                                                         // 334
        } finally {                                                                                                    // 335
            delete channels[sId];                                                                                      // 337
        }                                                                                                              // 338
    }                                                                                                                  // 339
}                                                                                                                      // 340
/**                                                                                                                    // 341
 * Upon disconnect, clear the client database                                                                          //
 */                                                                                                                    //
Streamy.onDisconnect(function (socket) {                                                                               // 344
    var sId = Streamy.id(socket),                                                                                      // 345
        ch = channels[sId];                                                                                            // 345
                                                                                                                       //
    closeCh(ch, sId);                                                                                                  // 348
    Streamy.broadcast('__leave__', {                                                                                   // 349
        'sid': Streamy.id(socket)                                                                                      // 350
    });                                                                                                                // 349
});                                                                                                                    // 352
                                                                                                                       //
Streamy.on('amqp_end', function (socket) {                                                                             // 354
    var sId = Streamy.id(socket),                                                                                      // 355
        ch = channels[sId];                                                                                            // 355
                                                                                                                       //
    closeCh(ch, sId);                                                                                                  // 358
    Streamy.broadcast('__leave__', {                                                                                   // 359
        'sid': Streamy.id(socket)                                                                                      // 360
    });                                                                                                                // 359
});                                                                                                                    // 362
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"groups.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/groups.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
Meteor.methods({                                                                                                       // 5
    addToGroup: function () {                                                                                          // 6
        function addToGroup(userId, groupId) {                                                                         // 6
            check(userId, String);                                                                                     // 7
            check(groupId, String);                                                                                    // 8
            return Groups.update(groupId, { $addToSet: { contentWhiteList: userId } });                                // 9
        }                                                                                                              // 10
                                                                                                                       //
        return addToGroup;                                                                                             // 6
    }(),                                                                                                               // 6
    removeFromGroup: function () {                                                                                     // 11
        function removeFromGroup(userId, groupId) {                                                                    // 11
            check(userId, String);                                                                                     // 12
            check(groupId, String);                                                                                    // 13
            Groups.update(groupId, { $pull: { contentWhiteList: userId } });                                           // 14
        }                                                                                                              // 15
                                                                                                                       //
        return removeFromGroup;                                                                                        // 11
    }()                                                                                                                // 11
});                                                                                                                    // 5
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"notifications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/methods/notifications.js                                                                                     //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 13/01/2016.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
createNotification = function createNotification(initiatorId, entryId, entryName, userId, category, message) {         // 5
    var actions = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : false;                           // 5
                                                                                                                       //
    check(initiatorId, String);                                                                                        // 6
    check(entryId, String);                                                                                            // 7
    check(entryName, String);                                                                                          // 8
    check(userId, String);                                                                                             // 9
    check(category, String);                                                                                           // 10
    check(message, String);                                                                                            // 11
    check(actions, Match.Any);                                                                                         // 12
                                                                                                                       //
    if (initiatorId !== userId) {                                                                                      // 14
        Notifications.update({                                                                                         // 15
            userId: userId,                                                                                            // 16
            initiatorId: initiatorId,                                                                                  // 17
            category: category,                                                                                        // 18
            entryId: entryId,                                                                                          // 19
            entryName: entryName,                                                                                      // 20
            message: message,                                                                                          // 21
            actions: actions,                                                                                          // 22
            read: false                                                                                                // 23
        }, {                                                                                                           // 15
            $set: {                                                                                                    // 25
                userId: userId,                                                                                        // 26
                initiatorId: initiatorId,                                                                              // 27
                category: category,                                                                                    // 28
                entryId: entryId,                                                                                      // 29
                entryName: entryName,                                                                                  // 30
                message: message,                                                                                      // 31
                actions: actions,                                                                                      // 32
                read: false                                                                                            // 33
            }                                                                                                          // 25
        }, { upsert: true });                                                                                          // 24
    }                                                                                                                  // 36
};                                                                                                                     // 37
                                                                                                                       //
Meteor.methods({                                                                                                       // 39
    createNotification: createNotification,                                                                            // 40
    createRequestNotification: function () {                                                                           // 41
        function createRequestNotification(username, organisation, initiatorId, entry, category, note) {               // 39
            check(username, String);                                                                                   // 42
            check(organisation, String);                                                                               // 43
            check(initiatorId, String);                                                                                // 44
            check(entry, Object);                                                                                      // 45
            check(category, String);                                                                                   // 46
                                                                                                                       //
            var path = Router.routes[category + '.page'].path({ _id: entry._id });                                     // 48
                                                                                                                       //
            var message = '<strong>' + username + '</strong>' + (organisation ? ' of ' + '<strong>' + organisation + '</strong>' : '') + ' requested access to ' + (category + ' <a class="blue-text" href="' + path + '">' + entry.name + '</a><br>') + (note ? '"' + note + '"' : ""),
                actions = ['Allow', 'Deny'];                                                                           // 50
                                                                                                                       //
            createNotification(initiatorId, entry._id, entry.name, entry.publisher, category, message, actions);       // 57
        }                                                                                                              // 58
                                                                                                                       //
        return createRequestNotification;                                                                              // 39
    }()                                                                                                                // 39
});                                                                                                                    // 39
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"_utils.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/_utils.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 25/12/2015.                                                                                      //
 */                                                                                                                    //
                                                                                                                       //
/**                                                                                                                    // 5
 *                                                                                                                     //
 * @param coll A collection                                                                                            //
 * @param pubCBFactry A factory function that returns the publish callback                                             //
 * @param pubAs Maps a collection to publishing name                                                                   //
 */                                                                                                                    //
publish = function publish(coll, pubCBFactry) {                                                                        // 11
  var pubAs = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function (coll) {                    // 11
    return coll._name;                                                                                                 // 11
  };                                                                                                                   // 11
                                                                                                                       //
  var name = pubAs(coll);                                                                                              // 12
  Meteor.publish(name, pubCBFactry(coll, name));                                                                       // 13
};                                                                                                                     // 14
                                                                                                                       //
//import JSONStream from 'JSONStream';                                                                                 // 16
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fixtures.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/fixtures.js                                                                                                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (Meteor.settings["public"].environment === 'dev' && !Meteor.settings["public"].migrate) {                           // 1
    /* testing cases                                                                                                   // 2
     *               ds1 (all)     ds2 (none)     ds3 (group)                                                          //
     * admin           own             y            own                                                                //
     * individual      y               own          n                                                                  //
     * member          y               n            y                                                                  //
     * group           y               n            y                                                                  //
     * */                                                                                                              //
                                                                                                                       //
    var addAdmin = function addAdmin(name) {                                                                           // 1
                                                                                                                       //
        var xgfdId = Accounts.createUser({                                                                             // 12
            profile: {                                                                                                 // 13
                name: name                                                                                             // 14
            },                                                                                                         // 13
            username: name,                                                                                            // 16
            email: name + "@example.com",                                                                              // 17
            password: "123456"                                                                                         // 18
        });                                                                                                            // 12
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 21
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 22
                                                                                                                       //
        return xgfdId;                                                                                                 // 24
    };                                                                                                                 // 25
                                                                                                                       //
    var addIndividual = function addIndividual(name) {                                                                 // 1
        return Accounts.createUser({                                                                                   // 28
            profile: {                                                                                                 // 29
                name: name                                                                                             // 30
            },                                                                                                         // 29
            username: name,                                                                                            // 32
            email: name + "@example.com",                                                                              // 33
            password: "123456"                                                                                         // 34
        });                                                                                                            // 28
    };                                                                                                                 // 36
                                                                                                                       //
    var addGroup = function addGroup(name) {                                                                           // 1
        var xgfdId = Accounts.createUser({                                                                             // 39
            profile: {                                                                                                 // 40
                name: name,                                                                                            // 41
                isgroup: true,                                                                                         // 42
                description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
                url: "https://www.google.co.uk"                                                                        // 44
            },                                                                                                         // 40
            username: name,                                                                                            // 46
            email: name + "@example.com",                                                                              // 47
            password: "123456"                                                                                         // 48
        });                                                                                                            // 39
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 51
        Roles.addUserToRoles(xgfdId, ["group"]);                                                                       // 52
                                                                                                                       //
        return xgfdId;                                                                                                 // 54
    };                                                                                                                 // 55
                                                                                                                       //
    var xgfdId = void 0,                                                                                               // 57
        individualId = void 0,                                                                                         // 57
        groupId = void 0,                                                                                              // 57
        memberId = void 0;                                                                                             // 57
    if (Meteor.users.find().count() === 0) {                                                                           // 58
        xgfdId = addAdmin('xgfd');                                                                                     // 59
        individualId = addIndividual('individual');                                                                    // 60
        groupId = addGroup('group');                                                                                   // 61
        memberId = addIndividual('member');                                                                            // 62
        var tmp = Meteor.call('addToGroup', memberId, Groups.findOne({ publisher: groupId })._id);                     // 63
    }                                                                                                                  // 64
    // Fixture data                                                                                                    // 65
    var telescopeId = void 0;                                                                                          // 66
    if (Datasets.find().count() === 0) {                                                                               // 67
        var now = new Date().getTime();                                                                                // 68
                                                                                                                       //
        telescopeId = Datasets.insert({                                                                                // 70
            name: 'Introducing Telescope',                                                                             // 71
            publisher: xgfdId,                                                                                         // 72
            distribution: [{                                                                                           // 73
                url: 'mongodb://localhost:3001/meteor',                                                                // 74
                fileFormat: "MongoDB",                                                                                 // 75
                online: true                                                                                           // 76
            }, {                                                                                                       // 73
                url: 'amqp://wsi-h1.soton.ac.uk?exchange=logs',                                                        // 78
                fileFormat: "AMQP",                                                                                    // 79
                online: true                                                                                           // 80
            }],                                                                                                        // 77
            license: "MIT",                                                                                            // 82
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 2,                                                                                          // 84
            aclContent: false,                                                                                         // 85
            online: true,                                                                                              // 86
            upvoters: [], votes: 0                                                                                     // 87
        });                                                                                                            // 70
                                                                                                                       //
        Comments.insert({                                                                                              // 90
            entryId: telescopeId,                                                                                      // 91
            publisher: individualId,                                                                                   // 92
            submitted: new Date(now - 5 * 3600 * 1000),                                                                // 93
            body: 'Interesting project Sacha, can I get involved?'                                                     // 94
        });                                                                                                            // 90
                                                                                                                       //
        Comments.insert({                                                                                              // 97
            entryId: telescopeId,                                                                                      // 98
            publisher: xgfdId,                                                                                         // 99
            submitted: new Date(now - 3 * 3600 * 1000),                                                                // 100
            body: "<p><span style=\"font-family: 'Comic Sans MS';\"><span style=\"font-size: 18px; background-color: rgb(255, 0, 0);\">You</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 156, 0);\">sure</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(255, 255, 0);\">can</span><span style=\"font-size: 18px;\"> </span><span style=\"font-size: 18px; background-color: rgb(0, 255, 0);\">Tom</span><span style=\"font-size: 18px; background-color: rgb(0, 0, 255);\">!!!</span></span></p>"
        });                                                                                                            // 97
                                                                                                                       //
        Datasets.insert({                                                                                              // 104
            name: 'The Meteor Book',                                                                                   // 105
            publisher: individualId,                                                                                   // 106
            distribution: [{                                                                                           // 107
                url: 'http://themeteorbook.com',                                                                       // 108
                fileFormat: "MySQL",                                                                                   // 109
                online: false                                                                                          // 110
            }, {                                                                                                       // 107
                url: 'http://dbpedia.org/sparql',                                                                      // 112
                fileFormat: "SPARQL",                                                                                  // 113
                online: true                                                                                           // 114
            }],                                                                                                        // 111
            license: "MIT",                                                                                            // 116
            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi pharetra augue eget hendrerit bibendum. Vivamus quis laoreet magna. Quisque eu mi sit amet lorem vestibulum rhoncus. Donec lacus est, sodales convallis urna nec, condimentum accumsan ligula. Nullam maximus a sem ac laoreet. In hac habitasse platea dictumst. Pellentesque porttitor ex orci, sed suscipit ante pretium eget. Nam vestibulum metus a libero ultricies molestie sed vel est. Maecenas porta tempus purus, sed pharetra nibh sodales vitae. Nullam in erat tristique, posuere enim laoreet, suscipit erat. Sed quis efficitur enim. 2",
            commentsCount: 0,                                                                                          // 118
            online: false,                                                                                             // 119
            aclMeta: false,                                                                                            // 120
            upvoters: [], votes: 0                                                                                     // 121
        });                                                                                                            // 104
                                                                                                                       //
        Datasets.insert({                                                                                              // 124
            name: 'Group visible dataset',                                                                             // 125
            publisher: xgfdId,                                                                                         // 126
            distribution: [{                                                                                           // 127
                url: 'http://sachagreif.com/introducing-telescope/',                                                   // 128
                fileFormat: "HTML",                                                                                    // 129
                online: true                                                                                           // 130
            }],                                                                                                        // 127
            license: "MIT",                                                                                            // 132
            description: "Vestibulum scelerisque auctor massa. In lectus arcu, eleifend quis faucibus malesuada, vulputate in lectus. Curabitur ut venenatis ligula, sit amet lacinia velit. Ut euismod libero sed odio efficitur tincidunt. Vestibulum a lacinia erat. Nulla pretium ante id fringilla pharetra. Aliquam varius, purus sed euismod ullamcorper, eros elit maximus magna, eu dignissim turpis leo in arcu. Nullam magna leo, blandit eu sollicitudin et, efficitur eget nibh. Etiam tempus mi eleifend commodo molestie.",
            commentsCount: 0,                                                                                          // 134
            aclMeta: false,                                                                                            // 135
            aclContent: false,                                                                                         // 136
            metaWhiteList: [groupId],                                                                                  // 137
            contentWhiteList: [groupId],                                                                               // 138
            online: true,                                                                                              // 139
            upvoters: [], votes: 0                                                                                     // 140
        });                                                                                                            // 124
                                                                                                                       //
        for (var i = 0; i < 50; i++) {                                                                                 // 143
            Apps.insert({                                                                                              // 144
                name: 'Test app #' + i,                                                                                // 145
                url: 'http://sachagreif.com/introducing-telescope/#' + i,                                              // 146
                publisher: groupId,                                                                                    // 147
                license: "MIT",                                                                                        // 148
                aclContent: !!(i % 2),                                                                                 // 149
                description: "Etiam porttitor purus et mollis malesuada. Nulla tempor orci id ex tincidunt consectetur. Praesent et dignissim lectus, in posuere ante. Curabitur nunc dolor, interdum a ornare eget, laoreet eu metus. Ut tempor lacinia eros nec finibus. Maecenas quis felis non mi euismod consectetur quis at leo. Nullam porta tempus ullamcorper. Phasellus et nibh feugiat, iaculis massa eget, blandit quam. Aliquam dolor justo, feugiat et sem ut, fermentum elementum arcu. Aliquam quis tincidunt tortor. Suspendisse potenti. Duis congue sapien ac purus iaculis pharetra. Donec hendrerit lacus leo, non ultricies purus accumsan nec. Nulla vel suscipit quam. Interdum et malesuada fames ac ante ipsum primis in faucibus.",
                commentsCount: 0,                                                                                      // 151
                upvoters: [], votes: 0                                                                                 // 152
            });                                                                                                        // 144
        }                                                                                                              // 154
    }                                                                                                                  // 155
}                                                                                                                      // 156
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"init.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/init.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by xgfd on 11/01/2016.                                                                                      //
 */                                                                                                                    //
SyncedCron.add({                                                                                                       // 4
    name: 'Pull remote collections',                                                                                   // 5
    schedule: function () {                                                                                            // 6
        function schedule(parser) {                                                                                    // 6
            // parser is a later.parse object                                                                          // 7
            return parser.text('every 1 hour');                                                                        // 8
        }                                                                                                              // 9
                                                                                                                       //
        return schedule;                                                                                               // 6
    }(),                                                                                                               // 6
    job: pullRemoteColls                                                                                               // 10
});                                                                                                                    // 4
                                                                                                                       //
SyncedCron.add({                                                                                                       // 13
    name: 'Datasets/Apps connection test',                                                                             // 14
    schedule: function () {                                                                                            // 15
        function schedule(parser) {                                                                                    // 15
            // parser is a later.parse object                                                                          // 16
            return parser.text('every 12 hour');                                                                       // 17
        }                                                                                                              // 18
                                                                                                                       //
        return schedule;                                                                                               // 15
    }(),                                                                                                               // 15
    job: checkCon                                                                                                      // 19
});                                                                                                                    // 13
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 22
    var settings = Meteor.settings;                                                                                    // 23
                                                                                                                       //
    //create admin                                                                                                     // 25
    if (!settings.admin) {                                                                                             // 26
        settings.admin = { name: 'admin', username: 'admin', email: 'admin@webobservatory.org', password: 'admin' };   // 27
    }                                                                                                                  // 28
                                                                                                                       //
    if (!Accounts.findUserByUsername(settings.admin.username)) {                                                       // 30
        var xgfdId = Accounts.createUser({                                                                             // 31
            profile: {                                                                                                 // 32
                name: settings.admin.name                                                                              // 33
            },                                                                                                         // 32
            username: settings.admin.username,                                                                         // 35
            email: settings.admin.email,                                                                               // 36
            password: settings.admin.password                                                                          // 37
        });                                                                                                            // 31
                                                                                                                       //
        Roles.removeUserFromRoles(xgfdId, ["individual"]);                                                             // 40
        Roles.addUserToRoles(xgfdId, ["admin"]);                                                                       // 41
    }                                                                                                                  // 42
                                                                                                                       //
    Meteor.call('nicolaslopezj_roles_migrate');                                                                        // 44
                                                                                                                       //
    // 1. Set up stmp                                                                                                  // 46
    //   your_server would be something like 'smtp.gmail.com'                                                          // 47
    //   and your_port would be a number like 25                                                                       // 48
                                                                                                                       //
    if (settings.smtp) {                                                                                               // 50
        process.env.MAIL_URL = encodeURIComponent(settings.smtp);                                                      // 51
    }                                                                                                                  // 52
                                                                                                                       //
    // Add Facebook configuration entry                                                                                // 54
                                                                                                                       //
    if (settings.facebook) {                                                                                           // 56
        ServiceConfiguration.configurations.update({ "service": "facebook" }, {                                        // 57
            $set: {                                                                                                    // 60
                "appId": settings.facebook.appId,                                                                      // 61
                "secret": settings.facebook.secret                                                                     // 62
            }                                                                                                          // 60
        }, { upsert: true });                                                                                          // 59
    }                                                                                                                  // 67
                                                                                                                       //
    // Add GitHub configuration entry                                                                                  // 69
    if (settings.github) {                                                                                             // 70
        ServiceConfiguration.configurations.update({ "service": "github" }, {                                          // 71
            $set: {                                                                                                    // 74
                "clientId": settings.github.clientId,                                                                  // 75
                "secret": settings.github.secret                                                                       // 76
            }                                                                                                          // 74
        }, { upsert: true });                                                                                          // 73
    }                                                                                                                  // 81
                                                                                                                       //
    // Set up LDAP.                                                                                                    // 83
    // Overwrite this function to produce settings based on the incoming request                                       // 84
    LDAP.generateSettings = function (request) {                                                                       // 85
        var username = request.username,                                                                               // 86
            domain = username.split('@')[1];                                                                           // 86
                                                                                                                       //
        var ldaps = orion.dictionary.get('ldap.ldap'),                                                                 // 89
            ldapConfig = void 0;                                                                                       // 89
                                                                                                                       //
        if (ldaps) {                                                                                                   // 92
            ldapConfig = ldaps.filter(function (v) {                                                                   // 93
                return v.domain === domain;                                                                            // 93
            })[0];                                                                                                     // 93
            ldapConfig.whiteListedFields = ldapConfig.whiteListedFields.split(/,\s*/);                                 // 94
            ldapConfig.autopublishFields = ldapConfig.autopublishFields ? ldapConfig.autopublishFields.split(/,\s*/) : ldapConfig.whiteListedFields;
            delete ldapConfig.domain;                                                                                  // 96
        }                                                                                                              // 97
                                                                                                                       //
        return ldapConfig;                                                                                             // 99
    };                                                                                                                 // 100
                                                                                                                       //
    LDAP.bindValue = function (username, isEmailAddress, serverDn) {                                                   // 102
        return (isEmailAddress ? username.split('@')[0] : username) + '@' + serverDn;                                  // 103
    };                                                                                                                 // 104
                                                                                                                       //
    LDAP.filter = function (isEmailAddress, usernameOrEmail) {                                                         // 106
        return '(&(cn=' + (isEmailAddress ? usernameOrEmail.split('@')[0] : usernameOrEmail) + ')(objectClass=user))';
    };                                                                                                                 // 108
                                                                                                                       //
    LDAP.logging = false;                                                                                              // 110
                                                                                                                       //
    Accounts.onCreateUser(function (options, user) {                                                                   // 112
        console.log(options);                                                                                          // 113
        var profile = options.profile || {};                                                                           // 114
        profile.name = profile.displayName || options.username;                                                        // 115
        user.profile = profile;                                                                                        // 116
        console.log(user);                                                                                             // 117
        return user;                                                                                                   // 118
    });                                                                                                                // 119
                                                                                                                       //
    // Get remote apps and datasets                                                                                    // 121
    pullRemoteColls();                                                                                                 // 122
    checkCon();                                                                                                        // 123
    SyncedCron.start();                                                                                                // 124
});                                                                                                                    // 125
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/publications.js                                                                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/*collection publication*/                                                                                             // 1
function pubSingle(coll) {                                                                                             // 2
    function cbFactry(coll) {                                                                                          // 3
        return function (id) {                                                                                         // 4
            var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};                      // 4
                                                                                                                       //
            check(id, String);                                                                                         // 5
                                                                                                                       //
            var selector = { _id: id },                                                                                // 7
                userId = this.userId;                                                                                  // 7
                                                                                                                       //
            extendOr(selector, viewsDocumentQuery(userId));                                                            // 10
            options.fields = {                                                                                         // 11
                //'distribution.url': 0,                                                                               // 12
                'distribution.file': 0,                                                                                // 13
                'distribution.profile.username': 0,                                                                    // 14
                'distribution.profile.pass': 0                                                                         // 15
            };                                                                                                         // 11
                                                                                                                       //
            return coll.find(selector, options);                                                                       // 18
        };                                                                                                             // 19
    }                                                                                                                  // 20
                                                                                                                       //
    publish(coll, cbFactry, function (coll) {                                                                          // 22
        return coll.singularName;                                                                                      // 22
    });                                                                                                                // 22
}                                                                                                                      // 23
                                                                                                                       //
function pubPlural(coll) {                                                                                             // 25
    function cbFactry(coll) {                                                                                          // 26
        return function () {                                                                                           // 27
            var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};                      // 27
            var selector = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};                     // 27
                                                                                                                       //
            //check(options, {                                                                                         // 28
            //    fields: Match.Optional(Object),                                                                      // 29
            //    skip: Match.Optional(Object),                                                                        // 30
            //    sort: Match.Optional(Object),                                                                        // 31
            //    limit: Match.Optional(Number)                                                                        // 32
            //});                                                                                                      // 33
            if (!selector) {                                                                                           // 34
                selector = {};                                                                                         // 35
            }                                                                                                          // 36
                                                                                                                       //
            if (!options) {                                                                                            // 38
                options = {};                                                                                          // 39
            }                                                                                                          // 40
                                                                                                                       //
            check(selector, Object);                                                                                   // 42
                                                                                                                       //
            switch (coll) {                                                                                            // 44
                case Meteor.users:                                                                                     // 45
                    options.fields = { username: 1 };                                                                  // 46
                    break;                                                                                             // 47
                                                                                                                       //
                case Datasets:                                                                                         // 49
                    var userId = this.userId;                                                                          // 50
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 51
                    options.fields = {                                                                                 // 52
                        //'distribution.url': 0,                                                                       // 53
                        'distribution.file': 0,                                                                        // 54
                        'distribution.profile.username': 0,                                                            // 55
                        'distribution.profile.pass': 0                                                                 // 56
                    };                                                                                                 // 52
                    Counts.publish(this, coll.singularName, coll.find(), { nonReactive: true });                       // 58
                    break;                                                                                             // 59
                                                                                                                       //
                case Apps:                                                                                             // 61
                    userId = this.userId;                                                                              // 62
                    extendOr(selector, viewsDocumentQuery(userId));                                                    // 63
                    Counts.publish(this, coll.singularName, coll.find(), { nonReactive: true });                       // 64
                    break;                                                                                             // 65
            }                                                                                                          // 44
                                                                                                                       //
            return coll.find(selector, options);                                                                       // 68
        };                                                                                                             // 69
    }                                                                                                                  // 70
                                                                                                                       //
    publish(coll, cbFactry);                                                                                           // 72
}                                                                                                                      // 73
                                                                                                                       //
[Datasets, Apps, RemoteApps, RemoteDatasets, Groups].forEach(pubSingle);                                               // 75
                                                                                                                       //
[Datasets, Apps, Groups, Licenses, Meteor.users, RemoteApps, RemoteDatasets].forEach(pubPlural);                       // 77
                                                                                                                       //
Meteor.publish('comments', function (entryId) {                                                                        // 79
    check(entryId, String);                                                                                            // 80
    return Comments.find({ entryId: entryId });                                                                        // 81
});                                                                                                                    // 82
                                                                                                                       //
//publish({                                                                                                            // 84
//        countDatasets: Datasets,                                                                                     // 85
//        countApps: Apps,                                                                                             // 86
//        countGroups: Groups,                                                                                         // 87
//}, Meteor.publish, function (collection) {                                                                           // 88
//    return function () {                                                                                             // 89
//        Counts.publish(this, collection.singularName, collection.find());                                            // 90
//        //return collection.find();                                                                                  // 91
//    }                                                                                                                // 92
//});                                                                                                                  // 93
                                                                                                                       //
Meteor.publish('notifications', function () {                                                                          // 95
    return Notifications.find({ userId: this.userId, read: false });                                                   // 96
});                                                                                                                    // 97
                                                                                                                       //
Meteor.publish('images', function () {                                                                                 // 99
    return Images.find();                                                                                              // 100
});                                                                                                                    // 101
                                                                                                                       //
//Meteor.publish("datasetsAndApps", function () {                                                                      // 103
//    return [                                                                                                         // 104
//        Datasets.find(),                                                                                             // 105
//        Apps.find()                                                                                                  // 106
//    ];                                                                                                               // 107
//});                                                                                                                  // 108
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"search.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/search.js                                                                                                    //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
/**                                                                                                                    // 1
 * Created by eugene on 11/02/2016.                                                                                    //
 */                                                                                                                    //
                                                                                                                       //
function buildRegExp(keywords) {                                                                                       // 5
    // this is a dumb implementation                                                                                   // 6
    var parts = keywords.trim().split(/[ \-\:]+/);                                                                     // 7
    return new RegExp("(" + parts.join('|') + ")", "ig");                                                              // 8
}                                                                                                                      // 9
                                                                                                                       //
//function containAny(keywords) {                                                                                      // 11
//    return keywords ? {$or: [{name: buildRegExp(keywords)}]} : {};                                                   // 12
//}                                                                                                                    // 13
                                                                                                                       //
//function fedSearch(colls, keywords, options) {                                                                       // 15
//    options = options || {limit: 10};                                                                                // 16
//                                                                                                                     // 17
//    let fedResult = colls                                                                                            // 18
//        .map(col=> col.find(containAny(keywords), options).fetch())//fetch collection                                // 19
//        .reduce((a, b)=>a.concat(b));//concat results                                                                // 20
//    return fedResult;                                                                                                // 21
//}                                                                                                                    // 22
//                                                                                                                     // 23
//let searchDatasets = fedSearch.bind(null, [Datasets, RemoteDatasets]),                                               // 24
//    searchApps = fedSearch.bind(null, [Apps, RemoteApps]);                                                           // 25
                                                                                                                       //
SearchSource.defineSource('apps', function (keywords, options) {                                                       // 27
    var options = { limit: 10 };                                                                                       // 28
                                                                                                                       //
    if (keywords) {                                                                                                    // 30
        var regExp = buildRegExp(keywords);                                                                            // 31
        var selector = {                                                                                               // 32
            $or: [{ name: regExp }]                                                                                    // 33
        };                                                                                                             // 32
                                                                                                                       //
        return Apps.find(selector, options).fetch();                                                                   // 38
    } else {                                                                                                           // 39
        return Apps.find({}, options).fetch();                                                                         // 40
    }                                                                                                                  // 41
});                                                                                                                    // 42
                                                                                                                       //
SearchSource.defineSource('datasets', function (keywords, options) {                                                   // 44
    var options = { limit: 10 };                                                                                       // 45
                                                                                                                       //
    if (keywords) {                                                                                                    // 47
        var regExp = buildRegExp(keywords);                                                                            // 48
        var selector = {                                                                                               // 49
            $or: [{ name: regExp }]                                                                                    // 50
        };                                                                                                             // 49
                                                                                                                       //
        return Datasets.find(selector, options).fetch();                                                               // 55
    } else {                                                                                                           // 56
        return Datasets.find({}, options).fetch();                                                                     // 57
    }                                                                                                                  // 58
});                                                                                                                    // 59
                                                                                                                       //
SearchSource.defineSource('remoteDatasets', function (keywords, options) {                                             // 61
    var options = { limit: 10 };                                                                                       // 62
                                                                                                                       //
    if (keywords) {                                                                                                    // 64
        var regExp = buildRegExp(keywords);                                                                            // 65
        var selector = {                                                                                               // 66
            $or: [{ name: regExp }]                                                                                    // 67
        };                                                                                                             // 66
                                                                                                                       //
        return RemoteDatasets.find(selector, options).fetch();                                                         // 72
    } else {                                                                                                           // 73
        return RemoteDatasets.find({}, options).fetch();                                                               // 74
    }                                                                                                                  // 75
});                                                                                                                    // 76
                                                                                                                       //
SearchSource.defineSource('remoteApps', function (keywords, options) {                                                 // 78
    var options = { limit: 10 };                                                                                       // 79
                                                                                                                       //
    if (keywords) {                                                                                                    // 81
        var regExp = buildRegExp(keywords);                                                                            // 82
        var selector = {                                                                                               // 83
            $or: [{ name: regExp }]                                                                                    // 84
        };                                                                                                             // 83
                                                                                                                       //
        return RemoteApps.find(selector, options).fetch();                                                             // 89
    } else {                                                                                                           // 90
        return RemoteApps.find({}, options).fetch();                                                                   // 91
    }                                                                                                                  // 92
});                                                                                                                    // 93
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{"extensions":[".js",".json"]});
require("./lib/collections/declarations/_utils.js");
require("./lib/collections/declarations/apps.js");
require("./lib/collections/declarations/clients.js");
require("./lib/collections/declarations/comments.js");
require("./lib/collections/declarations/datasets.js");
require("./lib/collections/declarations/group.js");
require("./lib/collections/declarations/licenses.js");
require("./lib/collections/declarations/notifications.js");
require("./lib/collections/declarations/remote.js");
require("./lib/collections/schemas/_creative_work.js");
require("./lib/collections/schemas/apps.js");
require("./lib/collections/schemas/clients.js");
require("./lib/collections/schemas/comments.js");
require("./lib/collections/schemas/datasets.js");
require("./lib/collections/schemas/groups.js");
require("./lib/collections/schemas/licenses.js");
require("./lib/collections/schemas/remote.js");
require("./lib/config/at_config.js");
require("./lib/roles/_utils.js");
require("./lib/roles/group.js");
require("./lib/roles/individual.js");
require("./lib/_utils.js");
require("./lib/orion_config.js");
require("./lib/orion_dictionary.js");
require("./lib/orion_filesystem.js");
require("./lib/router.js");
require("./server/api/resource_server/middlewares/content.js");
require("./server/api/resource_server/middlewares/metadata.js");
require("./server/api/resource_server/middlewares/utils.js");
require("./server/api/gateway/client_routes.js");
require("./server/api/gateway/models.js");
require("./server/api/gateway/oidc.js");
require("./server/api/gateway/routes.js");
require("./server/api/resource_server/routes.js");
require("./server/api/app.js");
require("./server/cronjobs/connectionTest.js");
require("./server/cronjobs/get_remote_colls.js");
require("./server/methods/accounts.js");
require("./server/methods/comments.js");
require("./server/methods/creative_work.js");
require("./server/methods/distributions.js");
require("./server/methods/groups.js");
require("./server/methods/notifications.js");
require("./server/_utils.js");
require("./server/fixtures.js");
require("./server/init.js");
require("./server/publications.js");
require("./server/search.js");
//# sourceMappingURL=app.js.map
